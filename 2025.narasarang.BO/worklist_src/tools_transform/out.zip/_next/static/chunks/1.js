(typeof self !== "object" ? self : this["webpackJsonp_N_E"] = typeof self !== "object" ? self : this["webpackJsonp_N_E"] || []).push([[1],{

/***/ "./components/Monaco.tsx":
/*!*******************************!*\
  !*** ./components/Monaco.tsx ***!
  \*******************************/
/*! exports provided: processSize, Monaco, default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* WEBPACK VAR INJECTION */(function(module) {/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "processSize", function() { return processSize; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "Monaco", function() { return Monaco; });
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ "./node_modules/react/jsx-dev-runtime.js");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _monaco_editor_react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @monaco-editor/react */ "./node_modules/@monaco-editor/react/lib/es/index.js");
/* harmony import */ var evergreen_ui__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! evergreen-ui */ "./node_modules/evergreen-ui/esm/index.js");


var _jsxFileName = "C:\\00.Project\\01.Netive\\2025.narasarang\\03.Project_example\\20250602_BD002_transform\\transform\\components\\Monaco.tsx",
    _this = undefined;




function processSize(size) {
  return !/^\d+$/.test(size) ? size : "".concat(size, "px");
}
var Monaco = function Monaco(_ref) {
  var language = _ref.language,
      value = _ref.value,
      defaultValue = _ref.defaultValue,
      height = _ref.height,
      width = _ref.width,
      options = _ref.options,
      onChange = _ref.onChange;
  return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_monaco_editor_react__WEBPACK_IMPORTED_MODULE_2__["default"], {
    defaultLanguage: language,
    defaultValue: defaultValue,
    value: value,
    height: height,
    width: width,
    options: options,
    onChange: onChange,
    loading: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(evergreen_ui__WEBPACK_IMPORTED_MODULE_3__["Pane"], {
      display: "flex",
      alignItems: "center",
      justifyContent: "center",
      height: 400,
      flex: 1,
      children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(evergreen_ui__WEBPACK_IMPORTED_MODULE_3__["Spinner"], {}, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 46,
        columnNumber: 11
      }, _this)
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 39,
      columnNumber: 9
    }, _this)
  }, void 0, false, {
    fileName: _jsxFileName,
    lineNumber: 30,
    columnNumber: 5
  }, _this);
};
_c = Monaco;
/* harmony default export */ __webpack_exports__["default"] = (Monaco);

var _c;

$RefreshReg$(_c, "Monaco");

;
    var _a, _b;
    // Legacy CSS implementations will `eval` browser code in a Node.js context
    // to extract CSS. For backwards compatibility, we need to check we're in a
    // browser context before continuing.
    if (typeof self !== 'undefined' &&
        // AMP / No-JS mode does not inject these helpers:
        '$RefreshHelpers$' in self) {
        var currentExports = module.__proto__.exports;
        var prevExports = (_b = (_a = module.hot.data) === null || _a === void 0 ? void 0 : _a.prevExports) !== null && _b !== void 0 ? _b : null;
        // This cannot happen in MainTemplate because the exports mismatch between
        // templating and execution.
        self.$RefreshHelpers$.registerExportsForReactRefresh(currentExports, module.i);
        // A module can be accepted automatically based on its exports, e.g. when
        // it is a Refresh Boundary.
        if (self.$RefreshHelpers$.isReactRefreshBoundary(currentExports)) {
            // Save the previous exports on update so we can compare the boundary
            // signatures.
            module.hot.dispose(function (data) {
                data.prevExports = currentExports;
            });
            // Unconditionally accept an update to this module, we'll check if it's
            // still a Refresh Boundary later.
            module.hot.accept();
            // This field is set when the previous version of this module was a
            // Refresh Boundary, letting us know we need to check for invalidation or
            // enqueue an update.
            if (prevExports !== null) {
                // A boundary can become ineligible if its exports are incompatible
                // with the previous exports.
                //
                // For example, if you add/remove/change exports, we'll want to
                // re-execute the importing modules, and force those components to
                // re-render. Similarly, if you convert a class component to a
                // function, we want to invalidate the boundary.
                if (self.$RefreshHelpers$.shouldInvalidateReactRefreshBoundary(prevExports, currentExports)) {
                    module.hot.invalidate();
                }
                else {
                    self.$RefreshHelpers$.scheduleUpdate();
                }
            }
        }
        else {
            // Since we just executed the code for the module, it's possible that the
            // new exports made it ineligible for being a boundary.
            // We only care about the case when we were _previously_ a boundary,
            // because we already accepted this update (accidental side effect).
            var isNoLongerABoundary = prevExports !== null;
            if (isNoLongerABoundary) {
                module.hot.invalidate();
            }
        }
    }

/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(/*! ./../node_modules/next/dist/compiled/webpack/harmony-module.js */ "./node_modules/next/dist/compiled/webpack/harmony-module.js")(module)))

/***/ }),

/***/ "./node_modules/@monaco-editor/loader/lib/es/_virtual/_rollupPluginBabelHelpers.js":
/*!*****************************************************************************************!*\
  !*** ./node_modules/@monaco-editor/loader/lib/es/_virtual/_rollupPluginBabelHelpers.js ***!
  \*****************************************************************************************/
/*! exports provided: arrayLikeToArray, arrayWithHoles, defineProperty, iterableToArrayLimit, nonIterableRest, objectSpread2, slicedToArray, unsupportedIterableToArray */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "arrayLikeToArray", function() { return _arrayLikeToArray; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "arrayWithHoles", function() { return _arrayWithHoles; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "defineProperty", function() { return _defineProperty; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "iterableToArrayLimit", function() { return _iterableToArrayLimit; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "nonIterableRest", function() { return _nonIterableRest; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "objectSpread2", function() { return _objectSpread2; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "slicedToArray", function() { return _slicedToArray; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "unsupportedIterableToArray", function() { return _unsupportedIterableToArray; });
function _defineProperty(obj, key, value) {
  if (key in obj) {
    Object.defineProperty(obj, key, {
      value: value,
      enumerable: true,
      configurable: true,
      writable: true
    });
  } else {
    obj[key] = value;
  }

  return obj;
}

function ownKeys(object, enumerableOnly) {
  var keys = Object.keys(object);

  if (Object.getOwnPropertySymbols) {
    var symbols = Object.getOwnPropertySymbols(object);
    if (enumerableOnly) symbols = symbols.filter(function (sym) {
      return Object.getOwnPropertyDescriptor(object, sym).enumerable;
    });
    keys.push.apply(keys, symbols);
  }

  return keys;
}

function _objectSpread2(target) {
  for (var i = 1; i < arguments.length; i++) {
    var source = arguments[i] != null ? arguments[i] : {};

    if (i % 2) {
      ownKeys(Object(source), true).forEach(function (key) {
        _defineProperty(target, key, source[key]);
      });
    } else if (Object.getOwnPropertyDescriptors) {
      Object.defineProperties(target, Object.getOwnPropertyDescriptors(source));
    } else {
      ownKeys(Object(source)).forEach(function (key) {
        Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key));
      });
    }
  }

  return target;
}

function _slicedToArray(arr, i) {
  return _arrayWithHoles(arr) || _iterableToArrayLimit(arr, i) || _unsupportedIterableToArray(arr, i) || _nonIterableRest();
}

function _arrayWithHoles(arr) {
  if (Array.isArray(arr)) return arr;
}

function _iterableToArrayLimit(arr, i) {
  if (typeof Symbol === "undefined" || !(Symbol.iterator in Object(arr))) return;
  var _arr = [];
  var _n = true;
  var _d = false;
  var _e = undefined;

  try {
    for (var _i = arr[Symbol.iterator](), _s; !(_n = (_s = _i.next()).done); _n = true) {
      _arr.push(_s.value);

      if (i && _arr.length === i) break;
    }
  } catch (err) {
    _d = true;
    _e = err;
  } finally {
    try {
      if (!_n && _i["return"] != null) _i["return"]();
    } finally {
      if (_d) throw _e;
    }
  }

  return _arr;
}

function _unsupportedIterableToArray(o, minLen) {
  if (!o) return;
  if (typeof o === "string") return _arrayLikeToArray(o, minLen);
  var n = Object.prototype.toString.call(o).slice(8, -1);
  if (n === "Object" && o.constructor) n = o.constructor.name;
  if (n === "Map" || n === "Set") return Array.from(o);
  if (n === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return _arrayLikeToArray(o, minLen);
}

function _arrayLikeToArray(arr, len) {
  if (len == null || len > arr.length) len = arr.length;

  for (var i = 0, arr2 = new Array(len); i < len; i++) arr2[i] = arr[i];

  return arr2;
}

function _nonIterableRest() {
  throw new TypeError("Invalid attempt to destructure non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.");
}




/***/ }),

/***/ "./node_modules/@monaco-editor/loader/lib/es/config/index.js":
/*!*******************************************************************!*\
  !*** ./node_modules/@monaco-editor/loader/lib/es/config/index.js ***!
  \*******************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
var config = {
  paths: {
    vs: 'https://cdn.jsdelivr.net/npm/monaco-editor@0.25.2/min/vs'
  }
};

/* harmony default export */ __webpack_exports__["default"] = (config);


/***/ }),

/***/ "./node_modules/@monaco-editor/loader/lib/es/index.js":
/*!************************************************************!*\
  !*** ./node_modules/@monaco-editor/loader/lib/es/index.js ***!
  \************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _loader_index_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./loader/index.js */ "./node_modules/@monaco-editor/loader/lib/es/loader/index.js");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "default", function() { return _loader_index_js__WEBPACK_IMPORTED_MODULE_0__["default"]; });





/***/ }),

/***/ "./node_modules/@monaco-editor/loader/lib/es/loader/index.js":
/*!*******************************************************************!*\
  !*** ./node_modules/@monaco-editor/loader/lib/es/loader/index.js ***!
  \*******************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _virtual_rollupPluginBabelHelpers_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../_virtual/_rollupPluginBabelHelpers.js */ "./node_modules/@monaco-editor/loader/lib/es/_virtual/_rollupPluginBabelHelpers.js");
/* harmony import */ var state_local__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! state-local */ "./node_modules/state-local/lib/es/state-local.js");
/* harmony import */ var _config_index_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../config/index.js */ "./node_modules/@monaco-editor/loader/lib/es/config/index.js");
/* harmony import */ var _validators_index_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../validators/index.js */ "./node_modules/@monaco-editor/loader/lib/es/validators/index.js");
/* harmony import */ var _utils_compose_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../utils/compose.js */ "./node_modules/@monaco-editor/loader/lib/es/utils/compose.js");
/* harmony import */ var _utils_deepMerge_js__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../utils/deepMerge.js */ "./node_modules/@monaco-editor/loader/lib/es/utils/deepMerge.js");
/* harmony import */ var _utils_makeCancelable_js__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../utils/makeCancelable.js */ "./node_modules/@monaco-editor/loader/lib/es/utils/makeCancelable.js");








/** the local state of the module */

var _state$create = state_local__WEBPACK_IMPORTED_MODULE_1__["default"].create({
  config: _config_index_js__WEBPACK_IMPORTED_MODULE_2__["default"],
  isInitialized: false,
  resolve: null,
  reject: null,
  monaco: null
}),
    _state$create2 = Object(_virtual_rollupPluginBabelHelpers_js__WEBPACK_IMPORTED_MODULE_0__["slicedToArray"])(_state$create, 2),
    getState = _state$create2[0],
    setState = _state$create2[1];
/**
 * set the loader configuration
 * @param {Object} config - the configuration object
 */


function config(config) {
  setState(function (state) {
    return {
      config: Object(_utils_deepMerge_js__WEBPACK_IMPORTED_MODULE_5__["default"])(state.config, _validators_index_js__WEBPACK_IMPORTED_MODULE_3__["default"].config(config))
    };
  });
}
/**
 * handles the initialization of the monaco-editor
 * @return {Promise} - returns an instance of monaco (with a cancelable promise)
 */


function init() {
  var state = getState(function (_ref) {
    var isInitialized = _ref.isInitialized;
    return {
      isInitialized: isInitialized
    };
  });

  if (!state.isInitialized) {
    if (window.monaco && window.monaco.editor) {
      storeMonacoInstance(window.monaco);
      return Object(_utils_makeCancelable_js__WEBPACK_IMPORTED_MODULE_6__["default"])(Promise.resolve(window.monaco));
    }

    Object(_utils_compose_js__WEBPACK_IMPORTED_MODULE_4__["default"])(injectScripts, getMonacoLoaderScript)(configureLoader);
    setState({
      isInitialized: true
    });
  }

  return Object(_utils_makeCancelable_js__WEBPACK_IMPORTED_MODULE_6__["default"])(wrapperPromise);
}
/**
 * injects provided scripts into the document.body
 * @param {Object} script - an HTML script element
 * @return {Object} - the injected HTML script element
 */


function injectScripts(script) {
  return document.body.appendChild(script);
}
/**
 * creates an HTML script element with/without provided src
 * @param {string} [src] - the source path of the script
 * @return {Object} - the created HTML script element
 */


function createScript(src) {
  var script = document.createElement('script');
  return src && (script.src = src), script;
}
/**
 * creates an HTML script element with the monaco loader src
 * @return {Object} - the created HTML script element
 */


function getMonacoLoaderScript(configureLoader) {
  var state = getState(function (_ref2) {
    var config = _ref2.config,
        reject = _ref2.reject;
    return {
      config: config,
      reject: reject
    };
  });
  var loaderScript = createScript("".concat(state.config.paths.vs, "/loader.js"));

  loaderScript.onload = function () {
    return configureLoader();
  };

  loaderScript.onerror = state.reject;
  return loaderScript;
}
/**
 * configures the monaco loader
 */


function configureLoader() {
  var state = getState(function (_ref3) {
    var config = _ref3.config,
        resolve = _ref3.resolve,
        reject = _ref3.reject;
    return {
      config: config,
      resolve: resolve,
      reject: reject
    };
  });
  var require = window.require;

  require.config(state.config);

  require(['vs/editor/editor.main'], function (monaco) {
    storeMonacoInstance(monaco);
    state.resolve(monaco);
  }, function (error) {
    state.reject(error);
  });
}
/**
 * store monaco instance in local state
 */


function storeMonacoInstance(monaco) {
  if (!getState().monaco) {
    setState({
      monaco: monaco
    });
  }
}
/**
 * internal helper function
 * extracts stored monaco instance
 * @return {Object|null} - the monaco instance
 */


function __getMonacoInstance() {
  return getState(function (_ref4) {
    var monaco = _ref4.monaco;
    return monaco;
  });
}

var wrapperPromise = new Promise(function (resolve, reject) {
  return setState({
    resolve: resolve,
    reject: reject
  });
});
var loader = {
  config: config,
  init: init,
  __getMonacoInstance: __getMonacoInstance
};

/* harmony default export */ __webpack_exports__["default"] = (loader);


/***/ }),

/***/ "./node_modules/@monaco-editor/loader/lib/es/utils/compose.js":
/*!********************************************************************!*\
  !*** ./node_modules/@monaco-editor/loader/lib/es/utils/compose.js ***!
  \********************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
var compose = function compose() {
  for (var _len = arguments.length, fns = new Array(_len), _key = 0; _key < _len; _key++) {
    fns[_key] = arguments[_key];
  }

  return function (x) {
    return fns.reduceRight(function (y, f) {
      return f(y);
    }, x);
  };
};

/* harmony default export */ __webpack_exports__["default"] = (compose);


/***/ }),

/***/ "./node_modules/@monaco-editor/loader/lib/es/utils/curry.js":
/*!******************************************************************!*\
  !*** ./node_modules/@monaco-editor/loader/lib/es/utils/curry.js ***!
  \******************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
function curry(fn) {
  return function curried() {
    var _this = this;

    for (var _len = arguments.length, args = new Array(_len), _key = 0; _key < _len; _key++) {
      args[_key] = arguments[_key];
    }

    return args.length >= fn.length ? fn.apply(this, args) : function () {
      for (var _len2 = arguments.length, nextArgs = new Array(_len2), _key2 = 0; _key2 < _len2; _key2++) {
        nextArgs[_key2] = arguments[_key2];
      }

      return curried.apply(_this, [].concat(args, nextArgs));
    };
  };
}

/* harmony default export */ __webpack_exports__["default"] = (curry);


/***/ }),

/***/ "./node_modules/@monaco-editor/loader/lib/es/utils/deepMerge.js":
/*!**********************************************************************!*\
  !*** ./node_modules/@monaco-editor/loader/lib/es/utils/deepMerge.js ***!
  \**********************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _virtual_rollupPluginBabelHelpers_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../_virtual/_rollupPluginBabelHelpers.js */ "./node_modules/@monaco-editor/loader/lib/es/_virtual/_rollupPluginBabelHelpers.js");


function merge(target, source) {
  Object.keys(source).forEach(function (key) {
    if (source[key] instanceof Object) {
      if (target[key]) {
        Object.assign(source[key], merge(target[key], source[key]));
      }
    }
  });
  return Object(_virtual_rollupPluginBabelHelpers_js__WEBPACK_IMPORTED_MODULE_0__["objectSpread2"])(Object(_virtual_rollupPluginBabelHelpers_js__WEBPACK_IMPORTED_MODULE_0__["objectSpread2"])({}, target), source);
}

/* harmony default export */ __webpack_exports__["default"] = (merge);


/***/ }),

/***/ "./node_modules/@monaco-editor/loader/lib/es/utils/isObject.js":
/*!*********************************************************************!*\
  !*** ./node_modules/@monaco-editor/loader/lib/es/utils/isObject.js ***!
  \*********************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
function isObject(value) {
  return {}.toString.call(value).includes('Object');
}

/* harmony default export */ __webpack_exports__["default"] = (isObject);


/***/ }),

/***/ "./node_modules/@monaco-editor/loader/lib/es/utils/makeCancelable.js":
/*!***************************************************************************!*\
  !*** ./node_modules/@monaco-editor/loader/lib/es/utils/makeCancelable.js ***!
  \***************************************************************************/
/*! exports provided: default, CANCELATION_MESSAGE */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "CANCELATION_MESSAGE", function() { return CANCELATION_MESSAGE; });
// The source (has been changed) is https://github.com/facebook/react/issues/5465#issuecomment-157888325
var CANCELATION_MESSAGE = {
  type: 'cancelation',
  msg: 'operation is manually canceled'
};

function makeCancelable(promise) {
  var hasCanceled_ = false;
  var wrappedPromise = new Promise(function (resolve, reject) {
    promise.then(function (val) {
      return hasCanceled_ ? reject(CANCELATION_MESSAGE) : resolve(val);
    });
    promise["catch"](reject);
  });
  return wrappedPromise.cancel = function () {
    return hasCanceled_ = true;
  }, wrappedPromise;
}

/* harmony default export */ __webpack_exports__["default"] = (makeCancelable);



/***/ }),

/***/ "./node_modules/@monaco-editor/loader/lib/es/validators/index.js":
/*!***********************************************************************!*\
  !*** ./node_modules/@monaco-editor/loader/lib/es/validators/index.js ***!
  \***********************************************************************/
/*! exports provided: default, errorHandler, errorMessages */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "errorHandler", function() { return errorHandler; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "errorMessages", function() { return errorMessages; });
/* harmony import */ var _utils_curry_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../utils/curry.js */ "./node_modules/@monaco-editor/loader/lib/es/utils/curry.js");
/* harmony import */ var _utils_isObject_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../utils/isObject.js */ "./node_modules/@monaco-editor/loader/lib/es/utils/isObject.js");



/**
 * validates the configuration object and informs about deprecation
 * @param {Object} config - the configuration object 
 * @return {Object} config - the validated configuration object
 */

function validateConfig(config) {
  if (!config) errorHandler('configIsRequired');
  if (!Object(_utils_isObject_js__WEBPACK_IMPORTED_MODULE_1__["default"])(config)) errorHandler('configType');

  if (config.urls) {
    informAboutDeprecation();
    return {
      paths: {
        vs: config.urls.monacoBase
      }
    };
  }

  return config;
}
/**
 * logs deprecation message
 */


function informAboutDeprecation() {
  console.warn(errorMessages.deprecation);
}

function throwError(errorMessages, type) {
  throw new Error(errorMessages[type] || errorMessages["default"]);
}

var errorMessages = {
  configIsRequired: 'the configuration object is required',
  configType: 'the configuration object should be an object',
  "default": 'an unknown error accured in `@monaco-editor/loader` package',
  deprecation: "Deprecation warning!\n    You are using deprecated way of configuration.\n\n    Instead of using\n      monaco.config({ urls: { monacoBase: '...' } })\n    use\n      monaco.config({ paths: { vs: '...' } })\n\n    For more please check the link https://github.com/suren-atoyan/monaco-loader#config\n  "
};
var errorHandler = Object(_utils_curry_js__WEBPACK_IMPORTED_MODULE_0__["default"])(throwError)(errorMessages);
var validators = {
  config: validateConfig
};

/* harmony default export */ __webpack_exports__["default"] = (validators);



/***/ }),

/***/ "./node_modules/@monaco-editor/react/lib/es/DiffEditor/DiffEditor.js":
/*!***************************************************************************!*\
  !*** ./node_modules/@monaco-editor/react/lib/es/DiffEditor/DiffEditor.js ***!
  \***************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _monaco_editor_loader__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @monaco-editor/loader */ "./node_modules/@monaco-editor/loader/lib/es/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! prop-types */ "./node_modules/prop-types/index.js");
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(prop_types__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _MonacoContainer_index_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../MonacoContainer/index.js */ "./node_modules/@monaco-editor/react/lib/es/MonacoContainer/index.js");
/* harmony import */ var _hooks_useMount_index_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../hooks/useMount/index.js */ "./node_modules/@monaco-editor/react/lib/es/hooks/useMount/index.js");
/* harmony import */ var _hooks_useUpdate_index_js__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../hooks/useUpdate/index.js */ "./node_modules/@monaco-editor/react/lib/es/hooks/useUpdate/index.js");
/* harmony import */ var _utils_index_js__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../utils/index.js */ "./node_modules/@monaco-editor/react/lib/es/utils/index.js");








function DiffEditor({
  original,
  modified,
  language,
  originalLanguage,
  modifiedLanguage,

  /* === */
  originalModelPath,
  modifiedModelPath,
  keepCurrentOriginalModel,
  keepCurrentModifiedModel,
  theme,
  loading,
  options,

  /* === */
  height,
  width,
  className,
  wrapperClassName,

  /* === */
  beforeMount,
  onMount
}) {
  const [isEditorReady, setIsEditorReady] = Object(react__WEBPACK_IMPORTED_MODULE_1__["useState"])(false);
  const [isMonacoMounting, setIsMonacoMounting] = Object(react__WEBPACK_IMPORTED_MODULE_1__["useState"])(true);
  const editorRef = Object(react__WEBPACK_IMPORTED_MODULE_1__["useRef"])(null);
  const monacoRef = Object(react__WEBPACK_IMPORTED_MODULE_1__["useRef"])(null);
  const containerRef = Object(react__WEBPACK_IMPORTED_MODULE_1__["useRef"])(null);
  const onMountRef = Object(react__WEBPACK_IMPORTED_MODULE_1__["useRef"])(onMount);
  const beforeMountRef = Object(react__WEBPACK_IMPORTED_MODULE_1__["useRef"])(beforeMount);
  Object(_hooks_useMount_index_js__WEBPACK_IMPORTED_MODULE_4__["default"])(() => {
    const cancelable = _monaco_editor_loader__WEBPACK_IMPORTED_MODULE_0__["default"].init();
    cancelable.then(monaco => (monacoRef.current = monaco) && setIsMonacoMounting(false)).catch(error => (error === null || error === void 0 ? void 0 : error.type) !== 'cancelation' && console.error('Monaco initialization: error:', error));
    return () => editorRef.current ? disposeEditor() : cancelable.cancel();
  });
  Object(_hooks_useUpdate_index_js__WEBPACK_IMPORTED_MODULE_5__["default"])(() => {
    const modifiedEditor = editorRef.current.getModifiedEditor();

    if (modifiedEditor.getOption(monacoRef.current.editor.EditorOption.readOnly)) {
      modifiedEditor.setValue(modified);
    } else {
      if (modified !== modifiedEditor.getValue()) {
        modifiedEditor.executeEdits('', [{
          range: modifiedEditor.getModel().getFullModelRange(),
          text: modified,
          forceMoveMarkers: true
        }]);
        modifiedEditor.pushUndoStop();
      }
    }
  }, [modified], isEditorReady);
  Object(_hooks_useUpdate_index_js__WEBPACK_IMPORTED_MODULE_5__["default"])(() => {
    editorRef.current.getModel().original.setValue(original);
  }, [original], isEditorReady);
  Object(_hooks_useUpdate_index_js__WEBPACK_IMPORTED_MODULE_5__["default"])(() => {
    const {
      original,
      modified
    } = editorRef.current.getModel();
    monacoRef.current.editor.setModelLanguage(original, originalLanguage || language);
    monacoRef.current.editor.setModelLanguage(modified, modifiedLanguage || language);
  }, [language, originalLanguage, modifiedLanguage], isEditorReady);
  Object(_hooks_useUpdate_index_js__WEBPACK_IMPORTED_MODULE_5__["default"])(() => {
    monacoRef.current.editor.setTheme(theme);
  }, [theme], isEditorReady);
  Object(_hooks_useUpdate_index_js__WEBPACK_IMPORTED_MODULE_5__["default"])(() => {
    editorRef.current.updateOptions(options);
  }, [options], isEditorReady);
  const setModels = Object(react__WEBPACK_IMPORTED_MODULE_1__["useCallback"])(() => {
    beforeMountRef.current(monacoRef.current);
    const originalModel = monacoRef.current.editor.createModel(original, originalLanguage || language, originalModelPath && monacoRef.current.Uri.parse(originalModelPath));
    const modifiedModel = monacoRef.current.editor.createModel(modified, modifiedLanguage || language, modifiedModelPath && monacoRef.current.Uri.parse(modifiedModelPath));
    editorRef.current.setModel({
      original: originalModel,
      modified: modifiedModel
    });
  }, [language, modified, modifiedLanguage, original, originalLanguage, originalModelPath, modifiedModelPath]);
  const createEditor = Object(react__WEBPACK_IMPORTED_MODULE_1__["useCallback"])(() => {
    editorRef.current = monacoRef.current.editor.createDiffEditor(containerRef.current, {
      automaticLayout: true,
      ...options
    });
    setModels();
    monacoRef.current.editor.setTheme(theme);
    setIsEditorReady(true);
  }, [options, theme, setModels]);
  Object(react__WEBPACK_IMPORTED_MODULE_1__["useEffect"])(() => {
    if (isEditorReady) {
      onMountRef.current(editorRef.current, monacoRef.current);
    }
  }, [isEditorReady]);
  Object(react__WEBPACK_IMPORTED_MODULE_1__["useEffect"])(() => {
    !isMonacoMounting && !isEditorReady && createEditor();
  }, [isMonacoMounting, isEditorReady, createEditor]);

  function disposeEditor() {
    const models = editorRef.current.getModel();

    if (!keepCurrentOriginalModel) {
      var _models$original;

      (_models$original = models.original) === null || _models$original === void 0 ? void 0 : _models$original.dispose();
    }

    if (!keepCurrentModifiedModel) {
      var _models$modified;

      (_models$modified = models.modified) === null || _models$modified === void 0 ? void 0 : _models$modified.dispose();
    }

    editorRef.current.dispose();
  }

  return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(_MonacoContainer_index_js__WEBPACK_IMPORTED_MODULE_3__["default"], {
    width: width,
    height: height,
    isEditorReady: isEditorReady,
    loading: loading,
    _ref: containerRef,
    className: className,
    wrapperClassName: wrapperClassName
  });
}

DiffEditor.propTypes = {
  original: prop_types__WEBPACK_IMPORTED_MODULE_2___default.a.string,
  modified: prop_types__WEBPACK_IMPORTED_MODULE_2___default.a.string,
  language: prop_types__WEBPACK_IMPORTED_MODULE_2___default.a.string,
  originalLanguage: prop_types__WEBPACK_IMPORTED_MODULE_2___default.a.string,
  modifiedLanguage: prop_types__WEBPACK_IMPORTED_MODULE_2___default.a.string,

  /* === */
  originalModelPath: prop_types__WEBPACK_IMPORTED_MODULE_2___default.a.string,
  modifiedModelPath: prop_types__WEBPACK_IMPORTED_MODULE_2___default.a.string,
  keepCurrentOriginalModel: prop_types__WEBPACK_IMPORTED_MODULE_2___default.a.bool,
  keepCurrentModifiedModel: prop_types__WEBPACK_IMPORTED_MODULE_2___default.a.bool,
  theme: prop_types__WEBPACK_IMPORTED_MODULE_2___default.a.string,
  loading: prop_types__WEBPACK_IMPORTED_MODULE_2___default.a.oneOfType([prop_types__WEBPACK_IMPORTED_MODULE_2___default.a.element, prop_types__WEBPACK_IMPORTED_MODULE_2___default.a.string]),
  options: prop_types__WEBPACK_IMPORTED_MODULE_2___default.a.object,

  /* === */
  width: prop_types__WEBPACK_IMPORTED_MODULE_2___default.a.oneOfType([prop_types__WEBPACK_IMPORTED_MODULE_2___default.a.number, prop_types__WEBPACK_IMPORTED_MODULE_2___default.a.string]),
  height: prop_types__WEBPACK_IMPORTED_MODULE_2___default.a.oneOfType([prop_types__WEBPACK_IMPORTED_MODULE_2___default.a.number, prop_types__WEBPACK_IMPORTED_MODULE_2___default.a.string]),
  className: prop_types__WEBPACK_IMPORTED_MODULE_2___default.a.string,
  wrapperClassName: prop_types__WEBPACK_IMPORTED_MODULE_2___default.a.string,

  /* === */
  beforeMount: prop_types__WEBPACK_IMPORTED_MODULE_2___default.a.func,
  onMount: prop_types__WEBPACK_IMPORTED_MODULE_2___default.a.func
};
DiffEditor.defaultProps = {
  theme: 'light',
  loading: 'Loading...',
  options: {},
  keepCurrentOriginalModel: false,
  keepCurrentModifiedModel: false,

  /* === */
  width: '100%',
  height: '100%',

  /* === */
  beforeMount: _utils_index_js__WEBPACK_IMPORTED_MODULE_6__["noop"],
  onMount: _utils_index_js__WEBPACK_IMPORTED_MODULE_6__["noop"]
};

/* harmony default export */ __webpack_exports__["default"] = (DiffEditor);


/***/ }),

/***/ "./node_modules/@monaco-editor/react/lib/es/DiffEditor/index.js":
/*!**********************************************************************!*\
  !*** ./node_modules/@monaco-editor/react/lib/es/DiffEditor/index.js ***!
  \**********************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _DiffEditor_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./DiffEditor.js */ "./node_modules/@monaco-editor/react/lib/es/DiffEditor/DiffEditor.js");



var index = /*#__PURE__*/Object(react__WEBPACK_IMPORTED_MODULE_0__["memo"])(_DiffEditor_js__WEBPACK_IMPORTED_MODULE_1__["default"]);

/* harmony default export */ __webpack_exports__["default"] = (index);


/***/ }),

/***/ "./node_modules/@monaco-editor/react/lib/es/Editor/Editor.js":
/*!*******************************************************************!*\
  !*** ./node_modules/@monaco-editor/react/lib/es/Editor/Editor.js ***!
  \*******************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _monaco_editor_loader__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @monaco-editor/loader */ "./node_modules/@monaco-editor/loader/lib/es/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! prop-types */ "./node_modules/prop-types/index.js");
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(prop_types__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _MonacoContainer_index_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../MonacoContainer/index.js */ "./node_modules/@monaco-editor/react/lib/es/MonacoContainer/index.js");
/* harmony import */ var _hooks_useMount_index_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../hooks/useMount/index.js */ "./node_modules/@monaco-editor/react/lib/es/hooks/useMount/index.js");
/* harmony import */ var _hooks_useUpdate_index_js__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../hooks/useUpdate/index.js */ "./node_modules/@monaco-editor/react/lib/es/hooks/useUpdate/index.js");
/* harmony import */ var _utils_index_js__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../utils/index.js */ "./node_modules/@monaco-editor/react/lib/es/utils/index.js");
/* harmony import */ var state_local__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! state-local */ "./node_modules/state-local/lib/es/state-local.js");
/* harmony import */ var _hooks_usePrevious_index_js__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ../hooks/usePrevious/index.js */ "./node_modules/@monaco-editor/react/lib/es/hooks/usePrevious/index.js");










const [getModelMarkersSetter, setModelMarkersSetter] = state_local__WEBPACK_IMPORTED_MODULE_7__["default"].create({
  backup: null
});
const viewStates = new Map();

function Editor({
  defaultValue,
  defaultLanguage,
  defaultPath,
  value,
  language,
  path,

  /* === */
  theme,
  line,
  loading,
  options,
  overrideServices,
  saveViewState,
  keepCurrentModel,

  /* === */
  width,
  height,
  className,
  wrapperClassName,

  /* === */
  beforeMount,
  onMount,
  onChange,
  onValidate
}) {
  const [isEditorReady, setIsEditorReady] = Object(react__WEBPACK_IMPORTED_MODULE_1__["useState"])(false);
  const [isMonacoMounting, setIsMonacoMounting] = Object(react__WEBPACK_IMPORTED_MODULE_1__["useState"])(true);
  const monacoRef = Object(react__WEBPACK_IMPORTED_MODULE_1__["useRef"])(null);
  const editorRef = Object(react__WEBPACK_IMPORTED_MODULE_1__["useRef"])(null);
  const containerRef = Object(react__WEBPACK_IMPORTED_MODULE_1__["useRef"])(null);
  const onMountRef = Object(react__WEBPACK_IMPORTED_MODULE_1__["useRef"])(onMount);
  const beforeMountRef = Object(react__WEBPACK_IMPORTED_MODULE_1__["useRef"])(beforeMount);
  const subscriptionRef = Object(react__WEBPACK_IMPORTED_MODULE_1__["useRef"])(null);
  const valueRef = Object(react__WEBPACK_IMPORTED_MODULE_1__["useRef"])(value);
  const previousPath = Object(_hooks_usePrevious_index_js__WEBPACK_IMPORTED_MODULE_8__["default"])(path);
  Object(_hooks_useMount_index_js__WEBPACK_IMPORTED_MODULE_4__["default"])(() => {
    const cancelable = _monaco_editor_loader__WEBPACK_IMPORTED_MODULE_0__["default"].init();
    cancelable.then(monaco => (monacoRef.current = monaco) && setIsMonacoMounting(false)).catch(error => (error === null || error === void 0 ? void 0 : error.type) !== 'cancelation' && console.error('Monaco initialization: error:', error));
    return () => editorRef.current ? disposeEditor() : cancelable.cancel();
  });
  Object(_hooks_useUpdate_index_js__WEBPACK_IMPORTED_MODULE_5__["default"])(() => {
    const model = Object(_utils_index_js__WEBPACK_IMPORTED_MODULE_6__["getOrCreateModel"])(monacoRef.current, defaultValue || value, defaultLanguage || language, path);

    if (model !== editorRef.current.getModel()) {
      saveViewState && viewStates.set(previousPath, editorRef.current.saveViewState());
      editorRef.current.setModel(model);
      saveViewState && editorRef.current.restoreViewState(viewStates.get(path));
    }
  }, [path], isEditorReady);
  Object(_hooks_useUpdate_index_js__WEBPACK_IMPORTED_MODULE_5__["default"])(() => {
    editorRef.current.updateOptions(options);
  }, [options], isEditorReady);
  Object(_hooks_useUpdate_index_js__WEBPACK_IMPORTED_MODULE_5__["default"])(() => {
    if (editorRef.current.getOption(monacoRef.current.editor.EditorOption.readOnly)) {
      editorRef.current.setValue(value);
    } else {
      if (value !== editorRef.current.getValue()) {
        editorRef.current.executeEdits('', [{
          range: editorRef.current.getModel().getFullModelRange(),
          text: value,
          forceMoveMarkers: true
        }]);
        editorRef.current.pushUndoStop();
      }
    }
  }, [value], isEditorReady);
  Object(_hooks_useUpdate_index_js__WEBPACK_IMPORTED_MODULE_5__["default"])(() => {
    monacoRef.current.editor.setModelLanguage(editorRef.current.getModel(), language);
  }, [language], isEditorReady);
  Object(_hooks_useUpdate_index_js__WEBPACK_IMPORTED_MODULE_5__["default"])(() => {
    // reason for undefined check: https://github.com/suren-atoyan/monaco-react/pull/188
    if (!Object(_utils_index_js__WEBPACK_IMPORTED_MODULE_6__["isUndefined"])(line)) {
      editorRef.current.revealLine(line);
    }
  }, [line], isEditorReady);
  Object(_hooks_useUpdate_index_js__WEBPACK_IMPORTED_MODULE_5__["default"])(() => {
    monacoRef.current.editor.setTheme(theme);
  }, [theme], isEditorReady);
  const createEditor = Object(react__WEBPACK_IMPORTED_MODULE_1__["useCallback"])(() => {
    beforeMountRef.current(monacoRef.current);
    const autoCreatedModelPath = path || defaultPath;
    const defaultModel = Object(_utils_index_js__WEBPACK_IMPORTED_MODULE_6__["getOrCreateModel"])(monacoRef.current, value || defaultValue, defaultLanguage || language, autoCreatedModelPath);
    editorRef.current = monacoRef.current.editor.create(containerRef.current, {
      model: defaultModel,
      automaticLayout: true,
      ...options
    }, overrideServices);
    saveViewState && editorRef.current.restoreViewState(viewStates.get(autoCreatedModelPath));
    monacoRef.current.editor.setTheme(theme);

    if (!getModelMarkersSetter().backup) {
      setModelMarkersSetter({
        backup: monacoRef.current.editor.setModelMarkers
      });
    }

    setIsEditorReady(true);
  }, [defaultValue, defaultLanguage, defaultPath, value, language, path, options, overrideServices, saveViewState, theme]);
  Object(react__WEBPACK_IMPORTED_MODULE_1__["useEffect"])(() => {
    if (isEditorReady) {
      onMountRef.current(editorRef.current, monacoRef.current);
    }
  }, [isEditorReady]);
  Object(react__WEBPACK_IMPORTED_MODULE_1__["useEffect"])(() => {
    !isMonacoMounting && !isEditorReady && createEditor();
  }, [isMonacoMounting, isEditorReady, createEditor]); // subscription
  // to avoid unnecessary updates (attach - dispose listener) in subscription

  valueRef.current = value;
  Object(react__WEBPACK_IMPORTED_MODULE_1__["useEffect"])(() => {
    if (isEditorReady && onChange) {
      var _subscriptionRef$curr, _editorRef$current;

      (_subscriptionRef$curr = subscriptionRef.current) === null || _subscriptionRef$curr === void 0 ? void 0 : _subscriptionRef$curr.dispose();
      subscriptionRef.current = (_editorRef$current = editorRef.current) === null || _editorRef$current === void 0 ? void 0 : _editorRef$current.onDidChangeModelContent(event => {
        const editorValue = editorRef.current.getValue();

        if (valueRef.current !== editorValue) {
          onChange(editorValue, event);
        }
      });
    }
  }, [isEditorReady, onChange]); // onValidate

  Object(react__WEBPACK_IMPORTED_MODULE_1__["useEffect"])(() => {
    if (isEditorReady) {
      monacoRef.current.editor.setModelMarkers = function (model, owner, markers) {
        var _getModelMarkersSette;

        (_getModelMarkersSette = getModelMarkersSetter().backup) === null || _getModelMarkersSette === void 0 ? void 0 : _getModelMarkersSette.call(monacoRef.current.editor, model, owner, markers);
        onValidate === null || onValidate === void 0 ? void 0 : onValidate(markers);
      };
    }
  }, [isEditorReady, onValidate]);

  function disposeEditor() {
    var _subscriptionRef$curr2;

    (_subscriptionRef$curr2 = subscriptionRef.current) === null || _subscriptionRef$curr2 === void 0 ? void 0 : _subscriptionRef$curr2.dispose();

    if (keepCurrentModel) {
      saveViewState && viewStates.set(path, editorRef.current.saveViewState());
    } else {
      var _editorRef$current$ge;

      (_editorRef$current$ge = editorRef.current.getModel()) === null || _editorRef$current$ge === void 0 ? void 0 : _editorRef$current$ge.dispose();
    }

    editorRef.current.dispose();
  }

  return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(_MonacoContainer_index_js__WEBPACK_IMPORTED_MODULE_3__["default"], {
    width: width,
    height: height,
    isEditorReady: isEditorReady,
    loading: loading,
    _ref: containerRef,
    className: className,
    wrapperClassName: wrapperClassName
  });
}

Editor.propTypes = {
  defaultValue: prop_types__WEBPACK_IMPORTED_MODULE_2___default.a.string,
  defaultPath: prop_types__WEBPACK_IMPORTED_MODULE_2___default.a.string,
  defaultLanguage: prop_types__WEBPACK_IMPORTED_MODULE_2___default.a.string,
  value: prop_types__WEBPACK_IMPORTED_MODULE_2___default.a.string,
  language: prop_types__WEBPACK_IMPORTED_MODULE_2___default.a.string,
  path: prop_types__WEBPACK_IMPORTED_MODULE_2___default.a.string,

  /* === */
  theme: prop_types__WEBPACK_IMPORTED_MODULE_2___default.a.string,
  line: prop_types__WEBPACK_IMPORTED_MODULE_2___default.a.number,
  loading: prop_types__WEBPACK_IMPORTED_MODULE_2___default.a.oneOfType([prop_types__WEBPACK_IMPORTED_MODULE_2___default.a.element, prop_types__WEBPACK_IMPORTED_MODULE_2___default.a.string]),
  options: prop_types__WEBPACK_IMPORTED_MODULE_2___default.a.object,
  overrideServices: prop_types__WEBPACK_IMPORTED_MODULE_2___default.a.object,
  saveViewState: prop_types__WEBPACK_IMPORTED_MODULE_2___default.a.bool,
  keepCurrentModel: prop_types__WEBPACK_IMPORTED_MODULE_2___default.a.bool,

  /* === */
  width: prop_types__WEBPACK_IMPORTED_MODULE_2___default.a.oneOfType([prop_types__WEBPACK_IMPORTED_MODULE_2___default.a.number, prop_types__WEBPACK_IMPORTED_MODULE_2___default.a.string]),
  height: prop_types__WEBPACK_IMPORTED_MODULE_2___default.a.oneOfType([prop_types__WEBPACK_IMPORTED_MODULE_2___default.a.number, prop_types__WEBPACK_IMPORTED_MODULE_2___default.a.string]),
  className: prop_types__WEBPACK_IMPORTED_MODULE_2___default.a.string,
  wrapperClassName: prop_types__WEBPACK_IMPORTED_MODULE_2___default.a.string,

  /* === */
  beforeMount: prop_types__WEBPACK_IMPORTED_MODULE_2___default.a.func,
  onMount: prop_types__WEBPACK_IMPORTED_MODULE_2___default.a.func,
  onChange: prop_types__WEBPACK_IMPORTED_MODULE_2___default.a.func,
  onValidate: prop_types__WEBPACK_IMPORTED_MODULE_2___default.a.func
};
Editor.defaultProps = {
  theme: 'light',
  loading: 'Loading...',
  options: {},
  overrideServices: {},
  saveViewState: true,
  keepCurrentModel: false,

  /* === */
  width: '100%',
  height: '100%',

  /* === */
  beforeMount: _utils_index_js__WEBPACK_IMPORTED_MODULE_6__["noop"],
  onMount: _utils_index_js__WEBPACK_IMPORTED_MODULE_6__["noop"],
  onValidate: _utils_index_js__WEBPACK_IMPORTED_MODULE_6__["noop"]
};

/* harmony default export */ __webpack_exports__["default"] = (Editor);


/***/ }),

/***/ "./node_modules/@monaco-editor/react/lib/es/Editor/index.js":
/*!******************************************************************!*\
  !*** ./node_modules/@monaco-editor/react/lib/es/Editor/index.js ***!
  \******************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _Editor_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./Editor.js */ "./node_modules/@monaco-editor/react/lib/es/Editor/Editor.js");



var index = /*#__PURE__*/Object(react__WEBPACK_IMPORTED_MODULE_0__["memo"])(_Editor_js__WEBPACK_IMPORTED_MODULE_1__["default"]);

/* harmony default export */ __webpack_exports__["default"] = (index);


/***/ }),

/***/ "./node_modules/@monaco-editor/react/lib/es/Loading/Loading.js":
/*!*********************************************************************!*\
  !*** ./node_modules/@monaco-editor/react/lib/es/Loading/Loading.js ***!
  \*********************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);


const loadingStyles = {
  display: 'flex',
  height: '100%',
  width: '100%',
  justifyContent: 'center',
  alignItems: 'center'
};

function Loading({
  content
}) {
  return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", {
    style: loadingStyles
  }, content);
}

/* harmony default export */ __webpack_exports__["default"] = (Loading);


/***/ }),

/***/ "./node_modules/@monaco-editor/react/lib/es/MonacoContainer/MonacoContainer.js":
/*!*************************************************************************************!*\
  !*** ./node_modules/@monaco-editor/react/lib/es/MonacoContainer/MonacoContainer.js ***!
  \*************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! prop-types */ "./node_modules/prop-types/index.js");
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(prop_types__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _Loading_Loading_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../Loading/Loading.js */ "./node_modules/@monaco-editor/react/lib/es/Loading/Loading.js");
/* harmony import */ var _styles_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./styles.js */ "./node_modules/@monaco-editor/react/lib/es/MonacoContainer/styles.js");





// one of the reasons why we use a separate prop for passing ref instead of using forwardref

function MonacoContainer({
  width,
  height,
  isEditorReady,
  loading,
  _ref,
  className,
  wrapperClassName
}) {
  return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("section", {
    style: { ..._styles_js__WEBPACK_IMPORTED_MODULE_3__["default"].wrapper,
      width,
      height
    },
    className: wrapperClassName
  }, !isEditorReady && /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_Loading_Loading_js__WEBPACK_IMPORTED_MODULE_2__["default"], {
    content: loading
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", {
    ref: _ref,
    style: { ..._styles_js__WEBPACK_IMPORTED_MODULE_3__["default"].fullWidth,
      ...(!isEditorReady && _styles_js__WEBPACK_IMPORTED_MODULE_3__["default"].hide)
    },
    className: className
  }));
}

MonacoContainer.propTypes = {
  width: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.oneOfType([prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.number, prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.string]).isRequired,
  height: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.oneOfType([prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.number, prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.string]).isRequired,
  loading: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.oneOfType([prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.element, prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.string]).isRequired,
  isEditorReady: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.bool.isRequired,
  className: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.string,
  wrapperClassName: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.string
};

/* harmony default export */ __webpack_exports__["default"] = (MonacoContainer);


/***/ }),

/***/ "./node_modules/@monaco-editor/react/lib/es/MonacoContainer/index.js":
/*!***************************************************************************!*\
  !*** ./node_modules/@monaco-editor/react/lib/es/MonacoContainer/index.js ***!
  \***************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _MonacoContainer_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./MonacoContainer.js */ "./node_modules/@monaco-editor/react/lib/es/MonacoContainer/MonacoContainer.js");



var MonacoContainer = /*#__PURE__*/Object(react__WEBPACK_IMPORTED_MODULE_0__["memo"])(_MonacoContainer_js__WEBPACK_IMPORTED_MODULE_1__["default"]);

/* harmony default export */ __webpack_exports__["default"] = (MonacoContainer);


/***/ }),

/***/ "./node_modules/@monaco-editor/react/lib/es/MonacoContainer/styles.js":
/*!****************************************************************************!*\
  !*** ./node_modules/@monaco-editor/react/lib/es/MonacoContainer/styles.js ***!
  \****************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
const styles = {
  wrapper: {
    display: 'flex',
    position: 'relative',
    textAlign: 'initial'
  },
  fullWidth: {
    width: '100%'
  },
  hide: {
    display: 'none'
  }
};

/* harmony default export */ __webpack_exports__["default"] = (styles);


/***/ }),

/***/ "./node_modules/@monaco-editor/react/lib/es/hooks/useMonaco/index.js":
/*!***************************************************************************!*\
  !*** ./node_modules/@monaco-editor/react/lib/es/hooks/useMonaco/index.js ***!
  \***************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _monaco_editor_loader__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @monaco-editor/loader */ "./node_modules/@monaco-editor/loader/lib/es/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _useMount_index_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../useMount/index.js */ "./node_modules/@monaco-editor/react/lib/es/hooks/useMount/index.js");




function useMonaco() {
  const [monaco, setMonaco] = Object(react__WEBPACK_IMPORTED_MODULE_1__["useState"])(_monaco_editor_loader__WEBPACK_IMPORTED_MODULE_0__["default"].__getMonacoInstance());
  Object(_useMount_index_js__WEBPACK_IMPORTED_MODULE_2__["default"])(() => {
    let cancelable;

    if (!monaco) {
      cancelable = _monaco_editor_loader__WEBPACK_IMPORTED_MODULE_0__["default"].init();
      cancelable.then(monaco => {
        setMonaco(monaco);
      });
    }

    return () => {
      var _cancelable;

      return (_cancelable = cancelable) === null || _cancelable === void 0 ? void 0 : _cancelable.cancel();
    };
  });
  return monaco;
}

/* harmony default export */ __webpack_exports__["default"] = (useMonaco);


/***/ }),

/***/ "./node_modules/@monaco-editor/react/lib/es/hooks/useMount/index.js":
/*!**************************************************************************!*\
  !*** ./node_modules/@monaco-editor/react/lib/es/hooks/useMount/index.js ***!
  \**************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);


function useMount(effect) {
  Object(react__WEBPACK_IMPORTED_MODULE_0__["useEffect"])(effect, []);
}

/* harmony default export */ __webpack_exports__["default"] = (useMount);


/***/ }),

/***/ "./node_modules/@monaco-editor/react/lib/es/hooks/usePrevious/index.js":
/*!*****************************************************************************!*\
  !*** ./node_modules/@monaco-editor/react/lib/es/hooks/usePrevious/index.js ***!
  \*****************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);


function usePrevious(value) {
  const ref = Object(react__WEBPACK_IMPORTED_MODULE_0__["useRef"])();
  Object(react__WEBPACK_IMPORTED_MODULE_0__["useEffect"])(() => {
    ref.current = value;
  }, [value]);
  return ref.current;
}

/* harmony default export */ __webpack_exports__["default"] = (usePrevious);


/***/ }),

/***/ "./node_modules/@monaco-editor/react/lib/es/hooks/useUpdate/index.js":
/*!***************************************************************************!*\
  !*** ./node_modules/@monaco-editor/react/lib/es/hooks/useUpdate/index.js ***!
  \***************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);


function useUpdate(effect, deps, applyChanges = true) {
  const isInitialMount = Object(react__WEBPACK_IMPORTED_MODULE_0__["useRef"])(true);
  Object(react__WEBPACK_IMPORTED_MODULE_0__["useEffect"])(isInitialMount.current || !applyChanges ? () => {
    isInitialMount.current = false;
  } : effect, deps);
}

/* harmony default export */ __webpack_exports__["default"] = (useUpdate);


/***/ }),

/***/ "./node_modules/@monaco-editor/react/lib/es/index.js":
/*!***********************************************************!*\
  !*** ./node_modules/@monaco-editor/react/lib/es/index.js ***!
  \***********************************************************/
/*! exports provided: loader, DiffEditor, useMonaco, default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _monaco_editor_loader__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @monaco-editor/loader */ "./node_modules/@monaco-editor/loader/lib/es/index.js");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "loader", function() { return _monaco_editor_loader__WEBPACK_IMPORTED_MODULE_0__["default"]; });

/* harmony import */ var _DiffEditor_index_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./DiffEditor/index.js */ "./node_modules/@monaco-editor/react/lib/es/DiffEditor/index.js");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "DiffEditor", function() { return _DiffEditor_index_js__WEBPACK_IMPORTED_MODULE_1__["default"]; });

/* harmony import */ var _hooks_useMonaco_index_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./hooks/useMonaco/index.js */ "./node_modules/@monaco-editor/react/lib/es/hooks/useMonaco/index.js");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "useMonaco", function() { return _hooks_useMonaco_index_js__WEBPACK_IMPORTED_MODULE_2__["default"]; });

/* harmony import */ var _Editor_index_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./Editor/index.js */ "./node_modules/@monaco-editor/react/lib/es/Editor/index.js");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "default", function() { return _Editor_index_js__WEBPACK_IMPORTED_MODULE_3__["default"]; });







/***/ }),

/***/ "./node_modules/@monaco-editor/react/lib/es/utils/index.js":
/*!*****************************************************************!*\
  !*** ./node_modules/@monaco-editor/react/lib/es/utils/index.js ***!
  \*****************************************************************/
/*! exports provided: getOrCreateModel, isUndefined, noop */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getOrCreateModel", function() { return getOrCreateModel; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "isUndefined", function() { return isUndefined; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "noop", function() { return noop; });
function noop() {}

function getOrCreateModel(monaco, value, language, path) {
  return getModel(monaco, path) || createModel(monaco, value, language, path);
}

function getModel(monaco, path) {
  return monaco.editor.getModel(crateModelUri(monaco, path));
}

function createModel(monaco, value, language, path) {
  return monaco.editor.createModel(value, language, path && crateModelUri(monaco, path));
}

function crateModelUri(monaco, path) {
  return monaco.Uri.parse(path);
}

function isUndefined(input) {
  return input === undefined;
}




/***/ }),

/***/ "./node_modules/state-local/lib/es/state-local.js":
/*!********************************************************!*\
  !*** ./node_modules/state-local/lib/es/state-local.js ***!
  \********************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
function _defineProperty(obj, key, value) {
  if (key in obj) {
    Object.defineProperty(obj, key, {
      value: value,
      enumerable: true,
      configurable: true,
      writable: true
    });
  } else {
    obj[key] = value;
  }

  return obj;
}

function ownKeys(object, enumerableOnly) {
  var keys = Object.keys(object);

  if (Object.getOwnPropertySymbols) {
    var symbols = Object.getOwnPropertySymbols(object);
    if (enumerableOnly) symbols = symbols.filter(function (sym) {
      return Object.getOwnPropertyDescriptor(object, sym).enumerable;
    });
    keys.push.apply(keys, symbols);
  }

  return keys;
}

function _objectSpread2(target) {
  for (var i = 1; i < arguments.length; i++) {
    var source = arguments[i] != null ? arguments[i] : {};

    if (i % 2) {
      ownKeys(Object(source), true).forEach(function (key) {
        _defineProperty(target, key, source[key]);
      });
    } else if (Object.getOwnPropertyDescriptors) {
      Object.defineProperties(target, Object.getOwnPropertyDescriptors(source));
    } else {
      ownKeys(Object(source)).forEach(function (key) {
        Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key));
      });
    }
  }

  return target;
}

function compose() {
  for (var _len = arguments.length, fns = new Array(_len), _key = 0; _key < _len; _key++) {
    fns[_key] = arguments[_key];
  }

  return function (x) {
    return fns.reduceRight(function (y, f) {
      return f(y);
    }, x);
  };
}

function curry(fn) {
  return function curried() {
    var _this = this;

    for (var _len2 = arguments.length, args = new Array(_len2), _key2 = 0; _key2 < _len2; _key2++) {
      args[_key2] = arguments[_key2];
    }

    return args.length >= fn.length ? fn.apply(this, args) : function () {
      for (var _len3 = arguments.length, nextArgs = new Array(_len3), _key3 = 0; _key3 < _len3; _key3++) {
        nextArgs[_key3] = arguments[_key3];
      }

      return curried.apply(_this, [].concat(args, nextArgs));
    };
  };
}

function isObject(value) {
  return {}.toString.call(value).includes('Object');
}

function isEmpty(obj) {
  return !Object.keys(obj).length;
}

function isFunction(value) {
  return typeof value === 'function';
}

function hasOwnProperty(object, property) {
  return Object.prototype.hasOwnProperty.call(object, property);
}

function validateChanges(initial, changes) {
  if (!isObject(changes)) errorHandler('changeType');
  if (Object.keys(changes).some(function (field) {
    return !hasOwnProperty(initial, field);
  })) errorHandler('changeField');
  return changes;
}

function validateSelector(selector) {
  if (!isFunction(selector)) errorHandler('selectorType');
}

function validateHandler(handler) {
  if (!(isFunction(handler) || isObject(handler))) errorHandler('handlerType');
  if (isObject(handler) && Object.values(handler).some(function (_handler) {
    return !isFunction(_handler);
  })) errorHandler('handlersType');
}

function validateInitial(initial) {
  if (!initial) errorHandler('initialIsRequired');
  if (!isObject(initial)) errorHandler('initialType');
  if (isEmpty(initial)) errorHandler('initialContent');
}

function throwError(errorMessages, type) {
  throw new Error(errorMessages[type] || errorMessages["default"]);
}

var errorMessages = {
  initialIsRequired: 'initial state is required',
  initialType: 'initial state should be an object',
  initialContent: 'initial state shouldn\'t be an empty object',
  handlerType: 'handler should be an object or a function',
  handlersType: 'all handlers should be a functions',
  selectorType: 'selector should be a function',
  changeType: 'provided value of changes should be an object',
  changeField: 'it seams you want to change a field in the state which is not specified in the "initial" state',
  "default": 'an unknown error accured in `state-local` package'
};
var errorHandler = curry(throwError)(errorMessages);
var validators = {
  changes: validateChanges,
  selector: validateSelector,
  handler: validateHandler,
  initial: validateInitial
};

function create(initial) {
  var handler = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : {};
  validators.initial(initial);
  validators.handler(handler);
  var state = {
    current: initial
  };
  var didUpdate = curry(didStateUpdate)(state, handler);
  var update = curry(updateState)(state);
  var validate = curry(validators.changes)(initial);
  var getChanges = curry(extractChanges)(state);

  function getState() {
    var selector = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : function (state) {
      return state;
    };
    validators.selector(selector);
    return selector(state.current);
  }

  function setState(causedChanges) {
    compose(didUpdate, update, validate, getChanges)(causedChanges);
  }

  return [getState, setState];
}

function extractChanges(state, causedChanges) {
  return isFunction(causedChanges) ? causedChanges(state.current) : causedChanges;
}

function updateState(state, changes) {
  state.current = _objectSpread2(_objectSpread2({}, state.current), changes);
  return changes;
}

function didStateUpdate(state, handler, changes) {
  isFunction(handler) ? handler(state.current) : Object.keys(changes).forEach(function (field) {
    var _handler$field;

    return (_handler$field = handler[field]) === null || _handler$field === void 0 ? void 0 : _handler$field.call(handler, state.current[field]);
  });
  return changes;
}

var index = {
  create: create
};

/* harmony default export */ __webpack_exports__["default"] = (index);


/***/ })

}]);
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9fTl9FLy4vY29tcG9uZW50cy9Nb25hY28udHN4Iiwid2VicGFjazovL19OX0UvLi9ub2RlX21vZHVsZXMvQG1vbmFjby1lZGl0b3IvbG9hZGVyL2xpYi9lcy9fdmlydHVhbC9fcm9sbHVwUGx1Z2luQmFiZWxIZWxwZXJzLmpzIiwid2VicGFjazovL19OX0UvLi9ub2RlX21vZHVsZXMvQG1vbmFjby1lZGl0b3IvbG9hZGVyL2xpYi9lcy9jb25maWcvaW5kZXguanMiLCJ3ZWJwYWNrOi8vX05fRS8uL25vZGVfbW9kdWxlcy9AbW9uYWNvLWVkaXRvci9sb2FkZXIvbGliL2VzL2luZGV4LmpzIiwid2VicGFjazovL19OX0UvLi9ub2RlX21vZHVsZXMvQG1vbmFjby1lZGl0b3IvbG9hZGVyL2xpYi9lcy9sb2FkZXIvaW5kZXguanMiLCJ3ZWJwYWNrOi8vX05fRS8uL25vZGVfbW9kdWxlcy9AbW9uYWNvLWVkaXRvci9sb2FkZXIvbGliL2VzL3V0aWxzL2NvbXBvc2UuanMiLCJ3ZWJwYWNrOi8vX05fRS8uL25vZGVfbW9kdWxlcy9AbW9uYWNvLWVkaXRvci9sb2FkZXIvbGliL2VzL3V0aWxzL2N1cnJ5LmpzIiwid2VicGFjazovL19OX0UvLi9ub2RlX21vZHVsZXMvQG1vbmFjby1lZGl0b3IvbG9hZGVyL2xpYi9lcy91dGlscy9kZWVwTWVyZ2UuanMiLCJ3ZWJwYWNrOi8vX05fRS8uL25vZGVfbW9kdWxlcy9AbW9uYWNvLWVkaXRvci9sb2FkZXIvbGliL2VzL3V0aWxzL2lzT2JqZWN0LmpzIiwid2VicGFjazovL19OX0UvLi9ub2RlX21vZHVsZXMvQG1vbmFjby1lZGl0b3IvbG9hZGVyL2xpYi9lcy91dGlscy9tYWtlQ2FuY2VsYWJsZS5qcyIsIndlYnBhY2s6Ly9fTl9FLy4vbm9kZV9tb2R1bGVzL0Btb25hY28tZWRpdG9yL2xvYWRlci9saWIvZXMvdmFsaWRhdG9ycy9pbmRleC5qcyIsIndlYnBhY2s6Ly9fTl9FLy4vbm9kZV9tb2R1bGVzL0Btb25hY28tZWRpdG9yL3JlYWN0L2xpYi9lcy9EaWZmRWRpdG9yL0RpZmZFZGl0b3IuanMiLCJ3ZWJwYWNrOi8vX05fRS8uL25vZGVfbW9kdWxlcy9AbW9uYWNvLWVkaXRvci9yZWFjdC9saWIvZXMvRGlmZkVkaXRvci9pbmRleC5qcyIsIndlYnBhY2s6Ly9fTl9FLy4vbm9kZV9tb2R1bGVzL0Btb25hY28tZWRpdG9yL3JlYWN0L2xpYi9lcy9FZGl0b3IvRWRpdG9yLmpzIiwid2VicGFjazovL19OX0UvLi9ub2RlX21vZHVsZXMvQG1vbmFjby1lZGl0b3IvcmVhY3QvbGliL2VzL0VkaXRvci9pbmRleC5qcyIsIndlYnBhY2s6Ly9fTl9FLy4vbm9kZV9tb2R1bGVzL0Btb25hY28tZWRpdG9yL3JlYWN0L2xpYi9lcy9Mb2FkaW5nL0xvYWRpbmcuanMiLCJ3ZWJwYWNrOi8vX05fRS8uL25vZGVfbW9kdWxlcy9AbW9uYWNvLWVkaXRvci9yZWFjdC9saWIvZXMvTW9uYWNvQ29udGFpbmVyL01vbmFjb0NvbnRhaW5lci5qcyIsIndlYnBhY2s6Ly9fTl9FLy4vbm9kZV9tb2R1bGVzL0Btb25hY28tZWRpdG9yL3JlYWN0L2xpYi9lcy9Nb25hY29Db250YWluZXIvaW5kZXguanMiLCJ3ZWJwYWNrOi8vX05fRS8uL25vZGVfbW9kdWxlcy9AbW9uYWNvLWVkaXRvci9yZWFjdC9saWIvZXMvTW9uYWNvQ29udGFpbmVyL3N0eWxlcy5qcyIsIndlYnBhY2s6Ly9fTl9FLy4vbm9kZV9tb2R1bGVzL0Btb25hY28tZWRpdG9yL3JlYWN0L2xpYi9lcy9ob29rcy91c2VNb25hY28vaW5kZXguanMiLCJ3ZWJwYWNrOi8vX05fRS8uL25vZGVfbW9kdWxlcy9AbW9uYWNvLWVkaXRvci9yZWFjdC9saWIvZXMvaG9va3MvdXNlTW91bnQvaW5kZXguanMiLCJ3ZWJwYWNrOi8vX05fRS8uL25vZGVfbW9kdWxlcy9AbW9uYWNvLWVkaXRvci9yZWFjdC9saWIvZXMvaG9va3MvdXNlUHJldmlvdXMvaW5kZXguanMiLCJ3ZWJwYWNrOi8vX05fRS8uL25vZGVfbW9kdWxlcy9AbW9uYWNvLWVkaXRvci9yZWFjdC9saWIvZXMvaG9va3MvdXNlVXBkYXRlL2luZGV4LmpzIiwid2VicGFjazovL19OX0UvLi9ub2RlX21vZHVsZXMvQG1vbmFjby1lZGl0b3IvcmVhY3QvbGliL2VzL2luZGV4LmpzIiwid2VicGFjazovL19OX0UvLi9ub2RlX21vZHVsZXMvQG1vbmFjby1lZGl0b3IvcmVhY3QvbGliL2VzL3V0aWxzL2luZGV4LmpzIiwid2VicGFjazovL19OX0UvLi9ub2RlX21vZHVsZXMvc3RhdGUtbG9jYWwvbGliL2VzL3N0YXRlLWxvY2FsLmpzIl0sIm5hbWVzIjpbInByb2Nlc3NTaXplIiwic2l6ZSIsInRlc3QiLCJNb25hY28iLCJsYW5ndWFnZSIsInZhbHVlIiwiZGVmYXVsdFZhbHVlIiwiaGVpZ2h0Iiwid2lkdGgiLCJvcHRpb25zIiwib25DaGFuZ2UiXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQUFBO0FBQ0E7QUFDQTtBQUVPLFNBQVNBLFdBQVQsQ0FBcUJDLElBQXJCLEVBQTJCO0FBQ2hDLFNBQU8sQ0FBQyxRQUFRQyxJQUFSLENBQWFELElBQWIsQ0FBRCxHQUFzQkEsSUFBdEIsYUFBZ0NBLElBQWhDLE9BQVA7QUFDRDtBQWFNLElBQU1FLE1BQTZCLEdBQUcsU0FBaENBLE1BQWdDLE9BUXZDO0FBQUEsTUFQSkMsUUFPSSxRQVBKQSxRQU9JO0FBQUEsTUFOSkMsS0FNSSxRQU5KQSxLQU1JO0FBQUEsTUFMSkMsWUFLSSxRQUxKQSxZQUtJO0FBQUEsTUFKSkMsTUFJSSxRQUpKQSxNQUlJO0FBQUEsTUFISkMsS0FHSSxRQUhKQSxLQUdJO0FBQUEsTUFGSkMsT0FFSSxRQUZKQSxPQUVJO0FBQUEsTUFESkMsUUFDSSxRQURKQSxRQUNJO0FBQ0osc0JBQ0UscUVBQUMsNERBQUQ7QUFDRSxtQkFBZSxFQUFFTixRQURuQjtBQUVFLGdCQUFZLEVBQUVFLFlBRmhCO0FBR0UsU0FBSyxFQUFFRCxLQUhUO0FBSUUsVUFBTSxFQUFFRSxNQUpWO0FBS0UsU0FBSyxFQUFFQyxLQUxUO0FBTUUsV0FBTyxFQUFFQyxPQU5YO0FBT0UsWUFBUSxFQUFFQyxRQVBaO0FBUUUsV0FBTyxlQUNMLHFFQUFDLGlEQUFEO0FBQ0UsYUFBTyxFQUFDLE1BRFY7QUFFRSxnQkFBVSxFQUFDLFFBRmI7QUFHRSxvQkFBYyxFQUFDLFFBSGpCO0FBSUUsWUFBTSxFQUFFLEdBSlY7QUFLRSxVQUFJLEVBQUUsQ0FMUjtBQUFBLDZCQU9FLHFFQUFDLG9EQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFQRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBVEo7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQURGO0FBc0JELENBL0JNO0tBQU1QLE07QUFpQ0VBLHFFQUFmOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDcERBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsS0FBSztBQUNMLEdBQUc7QUFDSDtBQUNBOztBQUVBO0FBQ0E7O0FBRUE7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLEtBQUs7QUFDTDtBQUNBOztBQUVBO0FBQ0E7O0FBRUE7QUFDQSxpQkFBaUIsc0JBQXNCO0FBQ3ZDOztBQUVBO0FBQ0E7QUFDQTtBQUNBLE9BQU87QUFDUCxLQUFLO0FBQ0w7QUFDQSxLQUFLO0FBQ0w7QUFDQTtBQUNBLE9BQU87QUFDUDtBQUNBOztBQUVBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQSw2Q0FBNkMsK0JBQStCO0FBQzVFOztBQUVBO0FBQ0E7QUFDQSxHQUFHO0FBQ0g7QUFDQTtBQUNBLEdBQUc7QUFDSDtBQUNBO0FBQ0EsS0FBSztBQUNMO0FBQ0E7QUFDQTs7QUFFQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTs7QUFFQSx3Q0FBd0MsU0FBUzs7QUFFakQ7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7O0FBRXdVOzs7Ozs7Ozs7Ozs7O0FDekd4VTtBQUFBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRWUscUVBQU0sRUFBQzs7Ozs7Ozs7Ozs7OztBQ050QjtBQUFBO0FBQUE7QUFBQTtBQUF1QztBQUNLOzs7Ozs7Ozs7Ozs7O0FDRDVDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBMkY7QUFDM0Q7QUFDVTtBQUNNO0FBQ047QUFDQTtBQUNjOztBQUV4RDs7QUFFQSxvQkFBb0IsbURBQUs7QUFDekIsVUFBVSx3REFBUTtBQUNsQjtBQUNBO0FBQ0E7QUFDQTtBQUNBLENBQUM7QUFDRCxxQkFBcUIsMEZBQWM7QUFDbkM7QUFDQTtBQUNBO0FBQ0E7QUFDQSxXQUFXLE9BQU87QUFDbEI7OztBQUdBO0FBQ0E7QUFDQTtBQUNBLGNBQWMsbUVBQUssZUFBZSw0REFBVTtBQUM1QztBQUNBLEdBQUc7QUFDSDtBQUNBO0FBQ0E7QUFDQSxZQUFZLFFBQVE7QUFDcEI7OztBQUdBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLEdBQUc7O0FBRUg7QUFDQTtBQUNBO0FBQ0EsYUFBYSx3RUFBYztBQUMzQjs7QUFFQSxJQUFJLGlFQUFPO0FBQ1g7QUFDQTtBQUNBLEtBQUs7QUFDTDs7QUFFQSxTQUFTLHdFQUFjO0FBQ3ZCO0FBQ0E7QUFDQTtBQUNBLFdBQVcsT0FBTztBQUNsQixZQUFZLE9BQU87QUFDbkI7OztBQUdBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxXQUFXLE9BQU87QUFDbEIsWUFBWSxPQUFPO0FBQ25COzs7QUFHQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxZQUFZLE9BQU87QUFDbkI7OztBQUdBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxHQUFHO0FBQ0g7O0FBRUE7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7O0FBR0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxHQUFHO0FBQ0g7O0FBRUE7O0FBRUE7QUFDQTtBQUNBO0FBQ0EsR0FBRztBQUNIO0FBQ0EsR0FBRztBQUNIO0FBQ0E7QUFDQTtBQUNBOzs7QUFHQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLEtBQUs7QUFDTDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsWUFBWSxZQUFZO0FBQ3hCOzs7QUFHQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLEdBQUc7QUFDSDs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLEdBQUc7QUFDSCxDQUFDO0FBQ0Q7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFZSxxRUFBTSxFQUFDOzs7Ozs7Ozs7Ozs7O0FDM0t0QjtBQUFBO0FBQ0Esb0VBQW9FLGFBQWE7QUFDakY7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQSxLQUFLO0FBQ0w7QUFDQTs7QUFFZSxzRUFBTyxFQUFDOzs7Ozs7Ozs7Ozs7O0FDWnZCO0FBQUE7QUFDQTtBQUNBOztBQUVBLHVFQUF1RSxhQUFhO0FBQ3BGO0FBQ0E7O0FBRUE7QUFDQSxnRkFBZ0YsZUFBZTtBQUMvRjtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBOztBQUVlLG9FQUFLLEVBQUM7Ozs7Ozs7Ozs7Ozs7QUNsQnJCO0FBQUE7QUFBMkY7O0FBRTNGO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsR0FBRztBQUNILFNBQVMsMEZBQWMsQ0FBQywwRkFBYyxHQUFHO0FBQ3pDOztBQUVlLG9FQUFLLEVBQUM7Ozs7Ozs7Ozs7Ozs7QUNickI7QUFBQTtBQUNBLFdBQVc7QUFDWDs7QUFFZSx1RUFBUSxFQUFDOzs7Ozs7Ozs7Ozs7O0FDSnhCO0FBQUE7QUFBQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxLQUFLO0FBQ0w7QUFDQSxHQUFHO0FBQ0g7QUFDQTtBQUNBLEdBQUc7QUFDSDs7QUFFZSw2RUFBYyxFQUFDO0FBQ0M7Ozs7Ozs7Ozs7Ozs7QUNwQi9CO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBc0M7QUFDTTs7QUFFNUM7QUFDQTtBQUNBLFdBQVcsT0FBTztBQUNsQixZQUFZLE9BQU87QUFDbkI7O0FBRUE7QUFDQTtBQUNBLE9BQU8sa0VBQVE7O0FBRWY7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOzs7QUFHQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsdUlBQXVJLFFBQVEsb0JBQW9CLEVBQUUsaUNBQWlDLFNBQVMsWUFBWSxFQUFFO0FBQzdOO0FBQ0EsbUJBQW1CLCtEQUFLO0FBQ3hCO0FBQ0E7QUFDQTs7QUFFZSx5RUFBVSxFQUFDO0FBQ2E7Ozs7Ozs7Ozs7Ozs7QUNqRHZDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQTJDO0FBQzZCO0FBQ3JDO0FBQ3VCO0FBQ1I7QUFDRTtBQUNYOztBQUV6QztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBLENBQUM7QUFDRCw0Q0FBNEMsc0RBQVE7QUFDcEQsa0RBQWtELHNEQUFRO0FBQzFELG9CQUFvQixvREFBTTtBQUMxQixvQkFBb0Isb0RBQU07QUFDMUIsdUJBQXVCLG9EQUFNO0FBQzdCLHFCQUFxQixvREFBTTtBQUMzQix5QkFBeUIsb0RBQU07QUFDL0IsRUFBRSx3RUFBUTtBQUNWLHVCQUF1Qiw2REFBTTtBQUM3QjtBQUNBO0FBQ0EsR0FBRztBQUNILEVBQUUseUVBQVM7QUFDWDs7QUFFQTtBQUNBO0FBQ0EsS0FBSztBQUNMO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxTQUFTO0FBQ1Q7QUFDQTtBQUNBO0FBQ0EsR0FBRztBQUNILEVBQUUseUVBQVM7QUFDWDtBQUNBLEdBQUc7QUFDSCxFQUFFLHlFQUFTO0FBQ1g7QUFDQTtBQUNBO0FBQ0EsS0FBSztBQUNMO0FBQ0E7QUFDQSxHQUFHO0FBQ0gsRUFBRSx5RUFBUztBQUNYO0FBQ0EsR0FBRztBQUNILEVBQUUseUVBQVM7QUFDWDtBQUNBLEdBQUc7QUFDSCxvQkFBb0IseURBQVc7QUFDL0I7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsS0FBSztBQUNMLEdBQUc7QUFDSCx1QkFBdUIseURBQVc7QUFDbEM7QUFDQTtBQUNBO0FBQ0EsS0FBSztBQUNMO0FBQ0E7QUFDQTtBQUNBLEdBQUc7QUFDSCxFQUFFLHVEQUFTO0FBQ1g7QUFDQTtBQUNBO0FBQ0EsR0FBRztBQUNILEVBQUUsdURBQVM7QUFDWDtBQUNBLEdBQUc7O0FBRUg7QUFDQTs7QUFFQTtBQUNBOztBQUVBO0FBQ0E7O0FBRUE7QUFDQTs7QUFFQTtBQUNBOztBQUVBO0FBQ0E7O0FBRUEsc0JBQXNCLDRDQUFLLGVBQWUsaUVBQWU7QUFDekQ7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxHQUFHO0FBQ0g7O0FBRUE7QUFDQSxZQUFZLGlEQUFTO0FBQ3JCLFlBQVksaURBQVM7QUFDckIsWUFBWSxpREFBUztBQUNyQixvQkFBb0IsaURBQVM7QUFDN0Isb0JBQW9CLGlEQUFTOztBQUU3QjtBQUNBLHFCQUFxQixpREFBUztBQUM5QixxQkFBcUIsaURBQVM7QUFDOUIsNEJBQTRCLGlEQUFTO0FBQ3JDLDRCQUE0QixpREFBUztBQUNyQyxTQUFTLGlEQUFTO0FBQ2xCLFdBQVcsaURBQVMsWUFBWSxpREFBUyxVQUFVLGlEQUFTO0FBQzVELFdBQVcsaURBQVM7O0FBRXBCO0FBQ0EsU0FBUyxpREFBUyxZQUFZLGlEQUFTLFNBQVMsaURBQVM7QUFDekQsVUFBVSxpREFBUyxZQUFZLGlEQUFTLFNBQVMsaURBQVM7QUFDMUQsYUFBYSxpREFBUztBQUN0QixvQkFBb0IsaURBQVM7O0FBRTdCO0FBQ0EsZUFBZSxpREFBUztBQUN4QixXQUFXLGlEQUFTO0FBQ3BCO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsYUFBYTtBQUNiO0FBQ0E7O0FBRUE7QUFDQTtBQUNBOztBQUVBO0FBQ0EsZUFBZSxvREFBSTtBQUNuQixXQUFXLG9EQUFJO0FBQ2Y7O0FBRWUseUVBQVUsRUFBQzs7Ozs7Ozs7Ozs7OztBQ2pMMUI7QUFBQTtBQUFBO0FBQUE7QUFBNkI7QUFDWTs7QUFFekMseUJBQXlCLGtEQUFJLENBQUMsc0RBQVU7O0FBRXpCLG9FQUFLLEVBQUM7Ozs7Ozs7Ozs7Ozs7QUNMckI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQTJDO0FBQzZCO0FBQ3JDO0FBQ3VCO0FBQ1I7QUFDRTtBQUNvQjtBQUN4QztBQUN3Qjs7QUFFeEQsdURBQXVELG1EQUFLO0FBQzVEO0FBQ0EsQ0FBQztBQUNEOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsQ0FBQztBQUNELDRDQUE0QyxzREFBUTtBQUNwRCxrREFBa0Qsc0RBQVE7QUFDMUQsb0JBQW9CLG9EQUFNO0FBQzFCLG9CQUFvQixvREFBTTtBQUMxQix1QkFBdUIsb0RBQU07QUFDN0IscUJBQXFCLG9EQUFNO0FBQzNCLHlCQUF5QixvREFBTTtBQUMvQiwwQkFBMEIsb0RBQU07QUFDaEMsbUJBQW1CLG9EQUFNO0FBQ3pCLHVCQUF1QiwyRUFBVztBQUNsQyxFQUFFLHdFQUFRO0FBQ1YsdUJBQXVCLDZEQUFNO0FBQzdCO0FBQ0E7QUFDQSxHQUFHO0FBQ0gsRUFBRSx5RUFBUztBQUNYLGtCQUFrQix3RUFBZ0I7O0FBRWxDO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxHQUFHO0FBQ0gsRUFBRSx5RUFBUztBQUNYO0FBQ0EsR0FBRztBQUNILEVBQUUseUVBQVM7QUFDWDtBQUNBO0FBQ0EsS0FBSztBQUNMO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxTQUFTO0FBQ1Q7QUFDQTtBQUNBO0FBQ0EsR0FBRztBQUNILEVBQUUseUVBQVM7QUFDWDtBQUNBLEdBQUc7QUFDSCxFQUFFLHlFQUFTO0FBQ1g7QUFDQSxTQUFTLG1FQUFXO0FBQ3BCO0FBQ0E7QUFDQSxHQUFHO0FBQ0gsRUFBRSx5RUFBUztBQUNYO0FBQ0EsR0FBRztBQUNILHVCQUF1Qix5REFBVztBQUNsQztBQUNBO0FBQ0EseUJBQXlCLHdFQUFnQjtBQUN6QztBQUNBO0FBQ0E7QUFDQTtBQUNBLEtBQUs7QUFDTDtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBLE9BQU87QUFDUDs7QUFFQTtBQUNBLEdBQUc7QUFDSCxFQUFFLHVEQUFTO0FBQ1g7QUFDQTtBQUNBO0FBQ0EsR0FBRztBQUNILEVBQUUsdURBQVM7QUFDWDtBQUNBLEdBQUcsbURBQW1EO0FBQ3REOztBQUVBO0FBQ0EsRUFBRSx1REFBUztBQUNYO0FBQ0E7O0FBRUE7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBLE9BQU87QUFDUDtBQUNBLEdBQUcsNkJBQTZCOztBQUVoQyxFQUFFLHVEQUFTO0FBQ1g7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsR0FBRzs7QUFFSDtBQUNBOztBQUVBOztBQUVBO0FBQ0E7QUFDQSxLQUFLO0FBQ0w7O0FBRUE7QUFDQTs7QUFFQTtBQUNBOztBQUVBLHNCQUFzQiw0Q0FBSyxlQUFlLGlFQUFlO0FBQ3pEO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsR0FBRztBQUNIOztBQUVBO0FBQ0EsZ0JBQWdCLGlEQUFTO0FBQ3pCLGVBQWUsaURBQVM7QUFDeEIsbUJBQW1CLGlEQUFTO0FBQzVCLFNBQVMsaURBQVM7QUFDbEIsWUFBWSxpREFBUztBQUNyQixRQUFRLGlEQUFTOztBQUVqQjtBQUNBLFNBQVMsaURBQVM7QUFDbEIsUUFBUSxpREFBUztBQUNqQixXQUFXLGlEQUFTLFlBQVksaURBQVMsVUFBVSxpREFBUztBQUM1RCxXQUFXLGlEQUFTO0FBQ3BCLG9CQUFvQixpREFBUztBQUM3QixpQkFBaUIsaURBQVM7QUFDMUIsb0JBQW9CLGlEQUFTOztBQUU3QjtBQUNBLFNBQVMsaURBQVMsWUFBWSxpREFBUyxTQUFTLGlEQUFTO0FBQ3pELFVBQVUsaURBQVMsWUFBWSxpREFBUyxTQUFTLGlEQUFTO0FBQzFELGFBQWEsaURBQVM7QUFDdEIsb0JBQW9CLGlEQUFTOztBQUU3QjtBQUNBLGVBQWUsaURBQVM7QUFDeEIsV0FBVyxpREFBUztBQUNwQixZQUFZLGlEQUFTO0FBQ3JCLGNBQWMsaURBQVM7QUFDdkI7QUFDQTtBQUNBO0FBQ0E7QUFDQSxhQUFhO0FBQ2Isc0JBQXNCO0FBQ3RCO0FBQ0E7O0FBRUE7QUFDQTtBQUNBOztBQUVBO0FBQ0EsZUFBZSxvREFBSTtBQUNuQixXQUFXLG9EQUFJO0FBQ2YsY0FBYyxvREFBSTtBQUNsQjs7QUFFZSxxRUFBTSxFQUFDOzs7Ozs7Ozs7Ozs7O0FDcE90QjtBQUFBO0FBQUE7QUFBQTtBQUE2QjtBQUNJOztBQUVqQyx5QkFBeUIsa0RBQUksQ0FBQyxrREFBTTs7QUFFckIsb0VBQUssRUFBQzs7Ozs7Ozs7Ozs7OztBQ0xyQjtBQUFBO0FBQUE7QUFBMEI7O0FBRTFCO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQSxDQUFDO0FBQ0Qsc0JBQXNCLDRDQUFLO0FBQzNCO0FBQ0EsR0FBRztBQUNIOztBQUVlLHNFQUFPLEVBQUM7Ozs7Ozs7Ozs7Ozs7QUNsQnZCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQTBCO0FBQ1M7QUFDUztBQUNYOztBQUVqQzs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsQ0FBQztBQUNELHNCQUFzQiw0Q0FBSztBQUMzQixZQUFZLElBQUksa0RBQU07QUFDdEI7QUFDQTtBQUNBLEtBQUs7QUFDTDtBQUNBLEdBQUcsaUNBQWlDLDRDQUFLLGVBQWUsMkRBQU87QUFDL0Q7QUFDQSxHQUFHLGdCQUFnQiw0Q0FBSztBQUN4QjtBQUNBLFlBQVksSUFBSSxrREFBTTtBQUN0Qiw0QkFBNEIsa0RBQU07QUFDbEMsS0FBSztBQUNMO0FBQ0EsR0FBRztBQUNIOztBQUVBO0FBQ0EsU0FBUyxpREFBUyxZQUFZLGlEQUFTLFNBQVMsaURBQVM7QUFDekQsVUFBVSxpREFBUyxZQUFZLGlEQUFTLFNBQVMsaURBQVM7QUFDMUQsV0FBVyxpREFBUyxZQUFZLGlEQUFTLFVBQVUsaURBQVM7QUFDNUQsaUJBQWlCLGlEQUFTO0FBQzFCLGFBQWEsaURBQVM7QUFDdEIsb0JBQW9CLGlEQUFTO0FBQzdCOztBQUVlLDhFQUFlLEVBQUM7Ozs7Ozs7Ozs7Ozs7QUMxQy9CO0FBQUE7QUFBQTtBQUFBO0FBQTZCO0FBQ3dCOztBQUVyRCxtQ0FBbUMsa0RBQUksQ0FBQywyREFBaUI7O0FBRTFDLDhFQUFlLEVBQUM7Ozs7Ozs7Ozs7Ozs7QUNML0I7QUFBQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsR0FBRztBQUNIO0FBQ0E7QUFDQSxHQUFHO0FBQ0g7QUFDQTtBQUNBO0FBQ0E7O0FBRWUscUVBQU0sRUFBQzs7Ozs7Ozs7Ozs7OztBQ2R0QjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQTJDO0FBQ1Y7QUFDVzs7QUFFNUM7QUFDQSw4QkFBOEIsc0RBQVEsQ0FBQyw2REFBTTtBQUM3QyxFQUFFLGtFQUFRO0FBQ1Y7O0FBRUE7QUFDQSxtQkFBbUIsNkRBQU07QUFDekI7QUFDQTtBQUNBLE9BQU87QUFDUDs7QUFFQTtBQUNBOztBQUVBO0FBQ0E7QUFDQSxHQUFHO0FBQ0g7QUFDQTs7QUFFZSx3RUFBUyxFQUFDOzs7Ozs7Ozs7Ozs7O0FDekJ6QjtBQUFBO0FBQUE7QUFBa0M7O0FBRWxDO0FBQ0EsRUFBRSx1REFBUztBQUNYOztBQUVlLHVFQUFRLEVBQUM7Ozs7Ozs7Ozs7Ozs7QUNOeEI7QUFBQTtBQUFBO0FBQTBDOztBQUUxQztBQUNBLGNBQWMsb0RBQU07QUFDcEIsRUFBRSx1REFBUztBQUNYO0FBQ0EsR0FBRztBQUNIO0FBQ0E7O0FBRWUsMEVBQVcsRUFBQzs7Ozs7Ozs7Ozs7OztBQ1YzQjtBQUFBO0FBQUE7QUFBMEM7O0FBRTFDO0FBQ0EseUJBQXlCLG9EQUFNO0FBQy9CLEVBQUUsdURBQVM7QUFDWDtBQUNBLEdBQUc7QUFDSDs7QUFFZSx3RUFBUyxFQUFDOzs7Ozs7Ozs7Ozs7O0FDVHpCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQTBEO0FBQ0k7QUFDSTtBQUN0Qjs7Ozs7Ozs7Ozs7OztBQ0g1QztBQUFBO0FBQUE7QUFBQTtBQUFBOztBQUVBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7O0FBRStDOzs7Ozs7Ozs7Ozs7O0FDdEIvQztBQUFBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsS0FBSztBQUNMLEdBQUc7QUFDSDtBQUNBOztBQUVBO0FBQ0E7O0FBRUE7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLEtBQUs7QUFDTDtBQUNBOztBQUVBO0FBQ0E7O0FBRUE7QUFDQSxpQkFBaUIsc0JBQXNCO0FBQ3ZDOztBQUVBO0FBQ0E7QUFDQTtBQUNBLE9BQU87QUFDUCxLQUFLO0FBQ0w7QUFDQSxLQUFLO0FBQ0w7QUFDQTtBQUNBLE9BQU87QUFDUDtBQUNBOztBQUVBO0FBQ0E7O0FBRUE7QUFDQSxvRUFBb0UsYUFBYTtBQUNqRjtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBLEtBQUs7QUFDTDtBQUNBOztBQUVBO0FBQ0E7QUFDQTs7QUFFQSwwRUFBMEUsZUFBZTtBQUN6RjtBQUNBOztBQUVBO0FBQ0EsZ0ZBQWdGLGVBQWU7QUFDL0Y7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBLFdBQVc7QUFDWDs7QUFFQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLEdBQUc7QUFDSDtBQUNBOztBQUVBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLEdBQUc7QUFDSDs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQSxrREFBa0Q7QUFDbEQ7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQSxHQUFHO0FBQ0g7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7O0FBRWUsb0VBQUssRUFBQyIsImZpbGUiOiJzdGF0aWMvY2h1bmtzLzEuanMiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgUmVhY3QgZnJvbSBcInJlYWN0XCI7XHJcbmltcG9ydCBFZGl0b3IgZnJvbSBcIkBtb25hY28tZWRpdG9yL3JlYWN0XCI7XHJcbmltcG9ydCB7IFBhbmUsIFNwaW5uZXIgfSBmcm9tIFwiZXZlcmdyZWVuLXVpXCI7XHJcblxyXG5leHBvcnQgZnVuY3Rpb24gcHJvY2Vzc1NpemUoc2l6ZSkge1xyXG4gIHJldHVybiAhL15cXGQrJC8udGVzdChzaXplKSA/IHNpemUgOiBgJHtzaXplfXB4YDtcclxufVxyXG5cclxuaW50ZXJmYWNlIE1vbmFjb1Byb3BzIHtcclxuICB0aGVtZT86IHN0cmluZztcclxuICBsYW5ndWFnZT86IHN0cmluZztcclxuICB2YWx1ZT86IHN0cmluZztcclxuICB3aWR0aD86IG51bWJlciB8IHN0cmluZztcclxuICBoZWlnaHQ/OiBudW1iZXIgfCBzdHJpbmc7XHJcbiAgb3B0aW9ucz86IGFueTtcclxuICBkZWZhdWx0VmFsdWU/OiBzdHJpbmc7XHJcbiAgb25DaGFuZ2U6ICh2YWx1ZTogc3RyaW5nKSA9PiB2b2lkO1xyXG59XHJcblxyXG5leHBvcnQgY29uc3QgTW9uYWNvOiBSZWFjdC5GQzxNb25hY29Qcm9wcz4gPSAoe1xyXG4gIGxhbmd1YWdlLFxyXG4gIHZhbHVlLFxyXG4gIGRlZmF1bHRWYWx1ZSxcclxuICBoZWlnaHQsXHJcbiAgd2lkdGgsXHJcbiAgb3B0aW9ucyxcclxuICBvbkNoYW5nZVxyXG59KSA9PiB7XHJcbiAgcmV0dXJuIChcclxuICAgIDxFZGl0b3JcclxuICAgICAgZGVmYXVsdExhbmd1YWdlPXtsYW5ndWFnZX1cclxuICAgICAgZGVmYXVsdFZhbHVlPXtkZWZhdWx0VmFsdWV9XHJcbiAgICAgIHZhbHVlPXt2YWx1ZX1cclxuICAgICAgaGVpZ2h0PXtoZWlnaHR9XHJcbiAgICAgIHdpZHRoPXt3aWR0aH1cclxuICAgICAgb3B0aW9ucz17b3B0aW9uc31cclxuICAgICAgb25DaGFuZ2U9e29uQ2hhbmdlfVxyXG4gICAgICBsb2FkaW5nPXtcclxuICAgICAgICA8UGFuZVxyXG4gICAgICAgICAgZGlzcGxheT1cImZsZXhcIlxyXG4gICAgICAgICAgYWxpZ25JdGVtcz1cImNlbnRlclwiXHJcbiAgICAgICAgICBqdXN0aWZ5Q29udGVudD1cImNlbnRlclwiXHJcbiAgICAgICAgICBoZWlnaHQ9ezQwMH1cclxuICAgICAgICAgIGZsZXg9ezF9XHJcbiAgICAgICAgPlxyXG4gICAgICAgICAgPFNwaW5uZXIgLz5cclxuICAgICAgICA8L1BhbmU+XHJcbiAgICAgIH1cclxuICAgIC8+XHJcbiAgKTtcclxufTtcclxuXHJcbmV4cG9ydCBkZWZhdWx0IE1vbmFjbztcclxuIiwiZnVuY3Rpb24gX2RlZmluZVByb3BlcnR5KG9iaiwga2V5LCB2YWx1ZSkge1xuICBpZiAoa2V5IGluIG9iaikge1xuICAgIE9iamVjdC5kZWZpbmVQcm9wZXJ0eShvYmosIGtleSwge1xuICAgICAgdmFsdWU6IHZhbHVlLFxuICAgICAgZW51bWVyYWJsZTogdHJ1ZSxcbiAgICAgIGNvbmZpZ3VyYWJsZTogdHJ1ZSxcbiAgICAgIHdyaXRhYmxlOiB0cnVlXG4gICAgfSk7XG4gIH0gZWxzZSB7XG4gICAgb2JqW2tleV0gPSB2YWx1ZTtcbiAgfVxuXG4gIHJldHVybiBvYmo7XG59XG5cbmZ1bmN0aW9uIG93bktleXMob2JqZWN0LCBlbnVtZXJhYmxlT25seSkge1xuICB2YXIga2V5cyA9IE9iamVjdC5rZXlzKG9iamVjdCk7XG5cbiAgaWYgKE9iamVjdC5nZXRPd25Qcm9wZXJ0eVN5bWJvbHMpIHtcbiAgICB2YXIgc3ltYm9scyA9IE9iamVjdC5nZXRPd25Qcm9wZXJ0eVN5bWJvbHMob2JqZWN0KTtcbiAgICBpZiAoZW51bWVyYWJsZU9ubHkpIHN5bWJvbHMgPSBzeW1ib2xzLmZpbHRlcihmdW5jdGlvbiAoc3ltKSB7XG4gICAgICByZXR1cm4gT2JqZWN0LmdldE93blByb3BlcnR5RGVzY3JpcHRvcihvYmplY3QsIHN5bSkuZW51bWVyYWJsZTtcbiAgICB9KTtcbiAgICBrZXlzLnB1c2guYXBwbHkoa2V5cywgc3ltYm9scyk7XG4gIH1cblxuICByZXR1cm4ga2V5cztcbn1cblxuZnVuY3Rpb24gX29iamVjdFNwcmVhZDIodGFyZ2V0KSB7XG4gIGZvciAodmFyIGkgPSAxOyBpIDwgYXJndW1lbnRzLmxlbmd0aDsgaSsrKSB7XG4gICAgdmFyIHNvdXJjZSA9IGFyZ3VtZW50c1tpXSAhPSBudWxsID8gYXJndW1lbnRzW2ldIDoge307XG5cbiAgICBpZiAoaSAlIDIpIHtcbiAgICAgIG93bktleXMoT2JqZWN0KHNvdXJjZSksIHRydWUpLmZvckVhY2goZnVuY3Rpb24gKGtleSkge1xuICAgICAgICBfZGVmaW5lUHJvcGVydHkodGFyZ2V0LCBrZXksIHNvdXJjZVtrZXldKTtcbiAgICAgIH0pO1xuICAgIH0gZWxzZSBpZiAoT2JqZWN0LmdldE93blByb3BlcnR5RGVzY3JpcHRvcnMpIHtcbiAgICAgIE9iamVjdC5kZWZpbmVQcm9wZXJ0aWVzKHRhcmdldCwgT2JqZWN0LmdldE93blByb3BlcnR5RGVzY3JpcHRvcnMoc291cmNlKSk7XG4gICAgfSBlbHNlIHtcbiAgICAgIG93bktleXMoT2JqZWN0KHNvdXJjZSkpLmZvckVhY2goZnVuY3Rpb24gKGtleSkge1xuICAgICAgICBPYmplY3QuZGVmaW5lUHJvcGVydHkodGFyZ2V0LCBrZXksIE9iamVjdC5nZXRPd25Qcm9wZXJ0eURlc2NyaXB0b3Ioc291cmNlLCBrZXkpKTtcbiAgICAgIH0pO1xuICAgIH1cbiAgfVxuXG4gIHJldHVybiB0YXJnZXQ7XG59XG5cbmZ1bmN0aW9uIF9zbGljZWRUb0FycmF5KGFyciwgaSkge1xuICByZXR1cm4gX2FycmF5V2l0aEhvbGVzKGFycikgfHwgX2l0ZXJhYmxlVG9BcnJheUxpbWl0KGFyciwgaSkgfHwgX3Vuc3VwcG9ydGVkSXRlcmFibGVUb0FycmF5KGFyciwgaSkgfHwgX25vbkl0ZXJhYmxlUmVzdCgpO1xufVxuXG5mdW5jdGlvbiBfYXJyYXlXaXRoSG9sZXMoYXJyKSB7XG4gIGlmIChBcnJheS5pc0FycmF5KGFycikpIHJldHVybiBhcnI7XG59XG5cbmZ1bmN0aW9uIF9pdGVyYWJsZVRvQXJyYXlMaW1pdChhcnIsIGkpIHtcbiAgaWYgKHR5cGVvZiBTeW1ib2wgPT09IFwidW5kZWZpbmVkXCIgfHwgIShTeW1ib2wuaXRlcmF0b3IgaW4gT2JqZWN0KGFycikpKSByZXR1cm47XG4gIHZhciBfYXJyID0gW107XG4gIHZhciBfbiA9IHRydWU7XG4gIHZhciBfZCA9IGZhbHNlO1xuICB2YXIgX2UgPSB1bmRlZmluZWQ7XG5cbiAgdHJ5IHtcbiAgICBmb3IgKHZhciBfaSA9IGFycltTeW1ib2wuaXRlcmF0b3JdKCksIF9zOyAhKF9uID0gKF9zID0gX2kubmV4dCgpKS5kb25lKTsgX24gPSB0cnVlKSB7XG4gICAgICBfYXJyLnB1c2goX3MudmFsdWUpO1xuXG4gICAgICBpZiAoaSAmJiBfYXJyLmxlbmd0aCA9PT0gaSkgYnJlYWs7XG4gICAgfVxuICB9IGNhdGNoIChlcnIpIHtcbiAgICBfZCA9IHRydWU7XG4gICAgX2UgPSBlcnI7XG4gIH0gZmluYWxseSB7XG4gICAgdHJ5IHtcbiAgICAgIGlmICghX24gJiYgX2lbXCJyZXR1cm5cIl0gIT0gbnVsbCkgX2lbXCJyZXR1cm5cIl0oKTtcbiAgICB9IGZpbmFsbHkge1xuICAgICAgaWYgKF9kKSB0aHJvdyBfZTtcbiAgICB9XG4gIH1cblxuICByZXR1cm4gX2Fycjtcbn1cblxuZnVuY3Rpb24gX3Vuc3VwcG9ydGVkSXRlcmFibGVUb0FycmF5KG8sIG1pbkxlbikge1xuICBpZiAoIW8pIHJldHVybjtcbiAgaWYgKHR5cGVvZiBvID09PSBcInN0cmluZ1wiKSByZXR1cm4gX2FycmF5TGlrZVRvQXJyYXkobywgbWluTGVuKTtcbiAgdmFyIG4gPSBPYmplY3QucHJvdG90eXBlLnRvU3RyaW5nLmNhbGwobykuc2xpY2UoOCwgLTEpO1xuICBpZiAobiA9PT0gXCJPYmplY3RcIiAmJiBvLmNvbnN0cnVjdG9yKSBuID0gby5jb25zdHJ1Y3Rvci5uYW1lO1xuICBpZiAobiA9PT0gXCJNYXBcIiB8fCBuID09PSBcIlNldFwiKSByZXR1cm4gQXJyYXkuZnJvbShvKTtcbiAgaWYgKG4gPT09IFwiQXJndW1lbnRzXCIgfHwgL14oPzpVaXxJKW50KD86OHwxNnwzMikoPzpDbGFtcGVkKT9BcnJheSQvLnRlc3QobikpIHJldHVybiBfYXJyYXlMaWtlVG9BcnJheShvLCBtaW5MZW4pO1xufVxuXG5mdW5jdGlvbiBfYXJyYXlMaWtlVG9BcnJheShhcnIsIGxlbikge1xuICBpZiAobGVuID09IG51bGwgfHwgbGVuID4gYXJyLmxlbmd0aCkgbGVuID0gYXJyLmxlbmd0aDtcblxuICBmb3IgKHZhciBpID0gMCwgYXJyMiA9IG5ldyBBcnJheShsZW4pOyBpIDwgbGVuOyBpKyspIGFycjJbaV0gPSBhcnJbaV07XG5cbiAgcmV0dXJuIGFycjI7XG59XG5cbmZ1bmN0aW9uIF9ub25JdGVyYWJsZVJlc3QoKSB7XG4gIHRocm93IG5ldyBUeXBlRXJyb3IoXCJJbnZhbGlkIGF0dGVtcHQgdG8gZGVzdHJ1Y3R1cmUgbm9uLWl0ZXJhYmxlIGluc3RhbmNlLlxcbkluIG9yZGVyIHRvIGJlIGl0ZXJhYmxlLCBub24tYXJyYXkgb2JqZWN0cyBtdXN0IGhhdmUgYSBbU3ltYm9sLml0ZXJhdG9yXSgpIG1ldGhvZC5cIik7XG59XG5cbmV4cG9ydCB7IF9hcnJheUxpa2VUb0FycmF5IGFzIGFycmF5TGlrZVRvQXJyYXksIF9hcnJheVdpdGhIb2xlcyBhcyBhcnJheVdpdGhIb2xlcywgX2RlZmluZVByb3BlcnR5IGFzIGRlZmluZVByb3BlcnR5LCBfaXRlcmFibGVUb0FycmF5TGltaXQgYXMgaXRlcmFibGVUb0FycmF5TGltaXQsIF9ub25JdGVyYWJsZVJlc3QgYXMgbm9uSXRlcmFibGVSZXN0LCBfb2JqZWN0U3ByZWFkMiBhcyBvYmplY3RTcHJlYWQyLCBfc2xpY2VkVG9BcnJheSBhcyBzbGljZWRUb0FycmF5LCBfdW5zdXBwb3J0ZWRJdGVyYWJsZVRvQXJyYXkgYXMgdW5zdXBwb3J0ZWRJdGVyYWJsZVRvQXJyYXkgfTtcbiIsInZhciBjb25maWcgPSB7XG4gIHBhdGhzOiB7XG4gICAgdnM6ICdodHRwczovL2Nkbi5qc2RlbGl2ci5uZXQvbnBtL21vbmFjby1lZGl0b3JAMC4yNS4yL21pbi92cydcbiAgfVxufTtcblxuZXhwb3J0IGRlZmF1bHQgY29uZmlnO1xuIiwiaW1wb3J0IGxvYWRlciBmcm9tICcuL2xvYWRlci9pbmRleC5qcyc7XG5leHBvcnQgeyBkZWZhdWx0IH0gZnJvbSAnLi9sb2FkZXIvaW5kZXguanMnO1xuIiwiaW1wb3J0IHsgc2xpY2VkVG9BcnJheSBhcyBfc2xpY2VkVG9BcnJheSB9IGZyb20gJy4uL192aXJ0dWFsL19yb2xsdXBQbHVnaW5CYWJlbEhlbHBlcnMuanMnO1xuaW1wb3J0IHN0YXRlIGZyb20gJ3N0YXRlLWxvY2FsJztcbmltcG9ydCBjb25maWckMSBmcm9tICcuLi9jb25maWcvaW5kZXguanMnO1xuaW1wb3J0IHZhbGlkYXRvcnMgZnJvbSAnLi4vdmFsaWRhdG9ycy9pbmRleC5qcyc7XG5pbXBvcnQgY29tcG9zZSBmcm9tICcuLi91dGlscy9jb21wb3NlLmpzJztcbmltcG9ydCBtZXJnZSBmcm9tICcuLi91dGlscy9kZWVwTWVyZ2UuanMnO1xuaW1wb3J0IG1ha2VDYW5jZWxhYmxlIGZyb20gJy4uL3V0aWxzL21ha2VDYW5jZWxhYmxlLmpzJztcblxuLyoqIHRoZSBsb2NhbCBzdGF0ZSBvZiB0aGUgbW9kdWxlICovXG5cbnZhciBfc3RhdGUkY3JlYXRlID0gc3RhdGUuY3JlYXRlKHtcbiAgY29uZmlnOiBjb25maWckMSxcbiAgaXNJbml0aWFsaXplZDogZmFsc2UsXG4gIHJlc29sdmU6IG51bGwsXG4gIHJlamVjdDogbnVsbCxcbiAgbW9uYWNvOiBudWxsXG59KSxcbiAgICBfc3RhdGUkY3JlYXRlMiA9IF9zbGljZWRUb0FycmF5KF9zdGF0ZSRjcmVhdGUsIDIpLFxuICAgIGdldFN0YXRlID0gX3N0YXRlJGNyZWF0ZTJbMF0sXG4gICAgc2V0U3RhdGUgPSBfc3RhdGUkY3JlYXRlMlsxXTtcbi8qKlxuICogc2V0IHRoZSBsb2FkZXIgY29uZmlndXJhdGlvblxuICogQHBhcmFtIHtPYmplY3R9IGNvbmZpZyAtIHRoZSBjb25maWd1cmF0aW9uIG9iamVjdFxuICovXG5cblxuZnVuY3Rpb24gY29uZmlnKGNvbmZpZykge1xuICBzZXRTdGF0ZShmdW5jdGlvbiAoc3RhdGUpIHtcbiAgICByZXR1cm4ge1xuICAgICAgY29uZmlnOiBtZXJnZShzdGF0ZS5jb25maWcsIHZhbGlkYXRvcnMuY29uZmlnKGNvbmZpZykpXG4gICAgfTtcbiAgfSk7XG59XG4vKipcbiAqIGhhbmRsZXMgdGhlIGluaXRpYWxpemF0aW9uIG9mIHRoZSBtb25hY28tZWRpdG9yXG4gKiBAcmV0dXJuIHtQcm9taXNlfSAtIHJldHVybnMgYW4gaW5zdGFuY2Ugb2YgbW9uYWNvICh3aXRoIGEgY2FuY2VsYWJsZSBwcm9taXNlKVxuICovXG5cblxuZnVuY3Rpb24gaW5pdCgpIHtcbiAgdmFyIHN0YXRlID0gZ2V0U3RhdGUoZnVuY3Rpb24gKF9yZWYpIHtcbiAgICB2YXIgaXNJbml0aWFsaXplZCA9IF9yZWYuaXNJbml0aWFsaXplZDtcbiAgICByZXR1cm4ge1xuICAgICAgaXNJbml0aWFsaXplZDogaXNJbml0aWFsaXplZFxuICAgIH07XG4gIH0pO1xuXG4gIGlmICghc3RhdGUuaXNJbml0aWFsaXplZCkge1xuICAgIGlmICh3aW5kb3cubW9uYWNvICYmIHdpbmRvdy5tb25hY28uZWRpdG9yKSB7XG4gICAgICBzdG9yZU1vbmFjb0luc3RhbmNlKHdpbmRvdy5tb25hY28pO1xuICAgICAgcmV0dXJuIG1ha2VDYW5jZWxhYmxlKFByb21pc2UucmVzb2x2ZSh3aW5kb3cubW9uYWNvKSk7XG4gICAgfVxuXG4gICAgY29tcG9zZShpbmplY3RTY3JpcHRzLCBnZXRNb25hY29Mb2FkZXJTY3JpcHQpKGNvbmZpZ3VyZUxvYWRlcik7XG4gICAgc2V0U3RhdGUoe1xuICAgICAgaXNJbml0aWFsaXplZDogdHJ1ZVxuICAgIH0pO1xuICB9XG5cbiAgcmV0dXJuIG1ha2VDYW5jZWxhYmxlKHdyYXBwZXJQcm9taXNlKTtcbn1cbi8qKlxuICogaW5qZWN0cyBwcm92aWRlZCBzY3JpcHRzIGludG8gdGhlIGRvY3VtZW50LmJvZHlcbiAqIEBwYXJhbSB7T2JqZWN0fSBzY3JpcHQgLSBhbiBIVE1MIHNjcmlwdCBlbGVtZW50XG4gKiBAcmV0dXJuIHtPYmplY3R9IC0gdGhlIGluamVjdGVkIEhUTUwgc2NyaXB0IGVsZW1lbnRcbiAqL1xuXG5cbmZ1bmN0aW9uIGluamVjdFNjcmlwdHMoc2NyaXB0KSB7XG4gIHJldHVybiBkb2N1bWVudC5ib2R5LmFwcGVuZENoaWxkKHNjcmlwdCk7XG59XG4vKipcbiAqIGNyZWF0ZXMgYW4gSFRNTCBzY3JpcHQgZWxlbWVudCB3aXRoL3dpdGhvdXQgcHJvdmlkZWQgc3JjXG4gKiBAcGFyYW0ge3N0cmluZ30gW3NyY10gLSB0aGUgc291cmNlIHBhdGggb2YgdGhlIHNjcmlwdFxuICogQHJldHVybiB7T2JqZWN0fSAtIHRoZSBjcmVhdGVkIEhUTUwgc2NyaXB0IGVsZW1lbnRcbiAqL1xuXG5cbmZ1bmN0aW9uIGNyZWF0ZVNjcmlwdChzcmMpIHtcbiAgdmFyIHNjcmlwdCA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoJ3NjcmlwdCcpO1xuICByZXR1cm4gc3JjICYmIChzY3JpcHQuc3JjID0gc3JjKSwgc2NyaXB0O1xufVxuLyoqXG4gKiBjcmVhdGVzIGFuIEhUTUwgc2NyaXB0IGVsZW1lbnQgd2l0aCB0aGUgbW9uYWNvIGxvYWRlciBzcmNcbiAqIEByZXR1cm4ge09iamVjdH0gLSB0aGUgY3JlYXRlZCBIVE1MIHNjcmlwdCBlbGVtZW50XG4gKi9cblxuXG5mdW5jdGlvbiBnZXRNb25hY29Mb2FkZXJTY3JpcHQoY29uZmlndXJlTG9hZGVyKSB7XG4gIHZhciBzdGF0ZSA9IGdldFN0YXRlKGZ1bmN0aW9uIChfcmVmMikge1xuICAgIHZhciBjb25maWcgPSBfcmVmMi5jb25maWcsXG4gICAgICAgIHJlamVjdCA9IF9yZWYyLnJlamVjdDtcbiAgICByZXR1cm4ge1xuICAgICAgY29uZmlnOiBjb25maWcsXG4gICAgICByZWplY3Q6IHJlamVjdFxuICAgIH07XG4gIH0pO1xuICB2YXIgbG9hZGVyU2NyaXB0ID0gY3JlYXRlU2NyaXB0KFwiXCIuY29uY2F0KHN0YXRlLmNvbmZpZy5wYXRocy52cywgXCIvbG9hZGVyLmpzXCIpKTtcblxuICBsb2FkZXJTY3JpcHQub25sb2FkID0gZnVuY3Rpb24gKCkge1xuICAgIHJldHVybiBjb25maWd1cmVMb2FkZXIoKTtcbiAgfTtcblxuICBsb2FkZXJTY3JpcHQub25lcnJvciA9IHN0YXRlLnJlamVjdDtcbiAgcmV0dXJuIGxvYWRlclNjcmlwdDtcbn1cbi8qKlxuICogY29uZmlndXJlcyB0aGUgbW9uYWNvIGxvYWRlclxuICovXG5cblxuZnVuY3Rpb24gY29uZmlndXJlTG9hZGVyKCkge1xuICB2YXIgc3RhdGUgPSBnZXRTdGF0ZShmdW5jdGlvbiAoX3JlZjMpIHtcbiAgICB2YXIgY29uZmlnID0gX3JlZjMuY29uZmlnLFxuICAgICAgICByZXNvbHZlID0gX3JlZjMucmVzb2x2ZSxcbiAgICAgICAgcmVqZWN0ID0gX3JlZjMucmVqZWN0O1xuICAgIHJldHVybiB7XG4gICAgICBjb25maWc6IGNvbmZpZyxcbiAgICAgIHJlc29sdmU6IHJlc29sdmUsXG4gICAgICByZWplY3Q6IHJlamVjdFxuICAgIH07XG4gIH0pO1xuICB2YXIgcmVxdWlyZSA9IHdpbmRvdy5yZXF1aXJlO1xuXG4gIHJlcXVpcmUuY29uZmlnKHN0YXRlLmNvbmZpZyk7XG5cbiAgcmVxdWlyZShbJ3ZzL2VkaXRvci9lZGl0b3IubWFpbiddLCBmdW5jdGlvbiAobW9uYWNvKSB7XG4gICAgc3RvcmVNb25hY29JbnN0YW5jZShtb25hY28pO1xuICAgIHN0YXRlLnJlc29sdmUobW9uYWNvKTtcbiAgfSwgZnVuY3Rpb24gKGVycm9yKSB7XG4gICAgc3RhdGUucmVqZWN0KGVycm9yKTtcbiAgfSk7XG59XG4vKipcbiAqIHN0b3JlIG1vbmFjbyBpbnN0YW5jZSBpbiBsb2NhbCBzdGF0ZVxuICovXG5cblxuZnVuY3Rpb24gc3RvcmVNb25hY29JbnN0YW5jZShtb25hY28pIHtcbiAgaWYgKCFnZXRTdGF0ZSgpLm1vbmFjbykge1xuICAgIHNldFN0YXRlKHtcbiAgICAgIG1vbmFjbzogbW9uYWNvXG4gICAgfSk7XG4gIH1cbn1cbi8qKlxuICogaW50ZXJuYWwgaGVscGVyIGZ1bmN0aW9uXG4gKiBleHRyYWN0cyBzdG9yZWQgbW9uYWNvIGluc3RhbmNlXG4gKiBAcmV0dXJuIHtPYmplY3R8bnVsbH0gLSB0aGUgbW9uYWNvIGluc3RhbmNlXG4gKi9cblxuXG5mdW5jdGlvbiBfX2dldE1vbmFjb0luc3RhbmNlKCkge1xuICByZXR1cm4gZ2V0U3RhdGUoZnVuY3Rpb24gKF9yZWY0KSB7XG4gICAgdmFyIG1vbmFjbyA9IF9yZWY0Lm1vbmFjbztcbiAgICByZXR1cm4gbW9uYWNvO1xuICB9KTtcbn1cblxudmFyIHdyYXBwZXJQcm9taXNlID0gbmV3IFByb21pc2UoZnVuY3Rpb24gKHJlc29sdmUsIHJlamVjdCkge1xuICByZXR1cm4gc2V0U3RhdGUoe1xuICAgIHJlc29sdmU6IHJlc29sdmUsXG4gICAgcmVqZWN0OiByZWplY3RcbiAgfSk7XG59KTtcbnZhciBsb2FkZXIgPSB7XG4gIGNvbmZpZzogY29uZmlnLFxuICBpbml0OiBpbml0LFxuICBfX2dldE1vbmFjb0luc3RhbmNlOiBfX2dldE1vbmFjb0luc3RhbmNlXG59O1xuXG5leHBvcnQgZGVmYXVsdCBsb2FkZXI7XG4iLCJ2YXIgY29tcG9zZSA9IGZ1bmN0aW9uIGNvbXBvc2UoKSB7XG4gIGZvciAodmFyIF9sZW4gPSBhcmd1bWVudHMubGVuZ3RoLCBmbnMgPSBuZXcgQXJyYXkoX2xlbiksIF9rZXkgPSAwOyBfa2V5IDwgX2xlbjsgX2tleSsrKSB7XG4gICAgZm5zW19rZXldID0gYXJndW1lbnRzW19rZXldO1xuICB9XG5cbiAgcmV0dXJuIGZ1bmN0aW9uICh4KSB7XG4gICAgcmV0dXJuIGZucy5yZWR1Y2VSaWdodChmdW5jdGlvbiAoeSwgZikge1xuICAgICAgcmV0dXJuIGYoeSk7XG4gICAgfSwgeCk7XG4gIH07XG59O1xuXG5leHBvcnQgZGVmYXVsdCBjb21wb3NlO1xuIiwiZnVuY3Rpb24gY3VycnkoZm4pIHtcbiAgcmV0dXJuIGZ1bmN0aW9uIGN1cnJpZWQoKSB7XG4gICAgdmFyIF90aGlzID0gdGhpcztcblxuICAgIGZvciAodmFyIF9sZW4gPSBhcmd1bWVudHMubGVuZ3RoLCBhcmdzID0gbmV3IEFycmF5KF9sZW4pLCBfa2V5ID0gMDsgX2tleSA8IF9sZW47IF9rZXkrKykge1xuICAgICAgYXJnc1tfa2V5XSA9IGFyZ3VtZW50c1tfa2V5XTtcbiAgICB9XG5cbiAgICByZXR1cm4gYXJncy5sZW5ndGggPj0gZm4ubGVuZ3RoID8gZm4uYXBwbHkodGhpcywgYXJncykgOiBmdW5jdGlvbiAoKSB7XG4gICAgICBmb3IgKHZhciBfbGVuMiA9IGFyZ3VtZW50cy5sZW5ndGgsIG5leHRBcmdzID0gbmV3IEFycmF5KF9sZW4yKSwgX2tleTIgPSAwOyBfa2V5MiA8IF9sZW4yOyBfa2V5MisrKSB7XG4gICAgICAgIG5leHRBcmdzW19rZXkyXSA9IGFyZ3VtZW50c1tfa2V5Ml07XG4gICAgICB9XG5cbiAgICAgIHJldHVybiBjdXJyaWVkLmFwcGx5KF90aGlzLCBbXS5jb25jYXQoYXJncywgbmV4dEFyZ3MpKTtcbiAgICB9O1xuICB9O1xufVxuXG5leHBvcnQgZGVmYXVsdCBjdXJyeTtcbiIsImltcG9ydCB7IG9iamVjdFNwcmVhZDIgYXMgX29iamVjdFNwcmVhZDIgfSBmcm9tICcuLi9fdmlydHVhbC9fcm9sbHVwUGx1Z2luQmFiZWxIZWxwZXJzLmpzJztcblxuZnVuY3Rpb24gbWVyZ2UodGFyZ2V0LCBzb3VyY2UpIHtcbiAgT2JqZWN0LmtleXMoc291cmNlKS5mb3JFYWNoKGZ1bmN0aW9uIChrZXkpIHtcbiAgICBpZiAoc291cmNlW2tleV0gaW5zdGFuY2VvZiBPYmplY3QpIHtcbiAgICAgIGlmICh0YXJnZXRba2V5XSkge1xuICAgICAgICBPYmplY3QuYXNzaWduKHNvdXJjZVtrZXldLCBtZXJnZSh0YXJnZXRba2V5XSwgc291cmNlW2tleV0pKTtcbiAgICAgIH1cbiAgICB9XG4gIH0pO1xuICByZXR1cm4gX29iamVjdFNwcmVhZDIoX29iamVjdFNwcmVhZDIoe30sIHRhcmdldCksIHNvdXJjZSk7XG59XG5cbmV4cG9ydCBkZWZhdWx0IG1lcmdlO1xuIiwiZnVuY3Rpb24gaXNPYmplY3QodmFsdWUpIHtcbiAgcmV0dXJuIHt9LnRvU3RyaW5nLmNhbGwodmFsdWUpLmluY2x1ZGVzKCdPYmplY3QnKTtcbn1cblxuZXhwb3J0IGRlZmF1bHQgaXNPYmplY3Q7XG4iLCIvLyBUaGUgc291cmNlIChoYXMgYmVlbiBjaGFuZ2VkKSBpcyBodHRwczovL2dpdGh1Yi5jb20vZmFjZWJvb2svcmVhY3QvaXNzdWVzLzU0NjUjaXNzdWVjb21tZW50LTE1Nzg4ODMyNVxudmFyIENBTkNFTEFUSU9OX01FU1NBR0UgPSB7XG4gIHR5cGU6ICdjYW5jZWxhdGlvbicsXG4gIG1zZzogJ29wZXJhdGlvbiBpcyBtYW51YWxseSBjYW5jZWxlZCdcbn07XG5cbmZ1bmN0aW9uIG1ha2VDYW5jZWxhYmxlKHByb21pc2UpIHtcbiAgdmFyIGhhc0NhbmNlbGVkXyA9IGZhbHNlO1xuICB2YXIgd3JhcHBlZFByb21pc2UgPSBuZXcgUHJvbWlzZShmdW5jdGlvbiAocmVzb2x2ZSwgcmVqZWN0KSB7XG4gICAgcHJvbWlzZS50aGVuKGZ1bmN0aW9uICh2YWwpIHtcbiAgICAgIHJldHVybiBoYXNDYW5jZWxlZF8gPyByZWplY3QoQ0FOQ0VMQVRJT05fTUVTU0FHRSkgOiByZXNvbHZlKHZhbCk7XG4gICAgfSk7XG4gICAgcHJvbWlzZVtcImNhdGNoXCJdKHJlamVjdCk7XG4gIH0pO1xuICByZXR1cm4gd3JhcHBlZFByb21pc2UuY2FuY2VsID0gZnVuY3Rpb24gKCkge1xuICAgIHJldHVybiBoYXNDYW5jZWxlZF8gPSB0cnVlO1xuICB9LCB3cmFwcGVkUHJvbWlzZTtcbn1cblxuZXhwb3J0IGRlZmF1bHQgbWFrZUNhbmNlbGFibGU7XG5leHBvcnQgeyBDQU5DRUxBVElPTl9NRVNTQUdFIH07XG4iLCJpbXBvcnQgY3VycnkgZnJvbSAnLi4vdXRpbHMvY3VycnkuanMnO1xuaW1wb3J0IGlzT2JqZWN0IGZyb20gJy4uL3V0aWxzL2lzT2JqZWN0LmpzJztcblxuLyoqXG4gKiB2YWxpZGF0ZXMgdGhlIGNvbmZpZ3VyYXRpb24gb2JqZWN0IGFuZCBpbmZvcm1zIGFib3V0IGRlcHJlY2F0aW9uXG4gKiBAcGFyYW0ge09iamVjdH0gY29uZmlnIC0gdGhlIGNvbmZpZ3VyYXRpb24gb2JqZWN0IFxuICogQHJldHVybiB7T2JqZWN0fSBjb25maWcgLSB0aGUgdmFsaWRhdGVkIGNvbmZpZ3VyYXRpb24gb2JqZWN0XG4gKi9cblxuZnVuY3Rpb24gdmFsaWRhdGVDb25maWcoY29uZmlnKSB7XG4gIGlmICghY29uZmlnKSBlcnJvckhhbmRsZXIoJ2NvbmZpZ0lzUmVxdWlyZWQnKTtcbiAgaWYgKCFpc09iamVjdChjb25maWcpKSBlcnJvckhhbmRsZXIoJ2NvbmZpZ1R5cGUnKTtcblxuICBpZiAoY29uZmlnLnVybHMpIHtcbiAgICBpbmZvcm1BYm91dERlcHJlY2F0aW9uKCk7XG4gICAgcmV0dXJuIHtcbiAgICAgIHBhdGhzOiB7XG4gICAgICAgIHZzOiBjb25maWcudXJscy5tb25hY29CYXNlXG4gICAgICB9XG4gICAgfTtcbiAgfVxuXG4gIHJldHVybiBjb25maWc7XG59XG4vKipcbiAqIGxvZ3MgZGVwcmVjYXRpb24gbWVzc2FnZVxuICovXG5cblxuZnVuY3Rpb24gaW5mb3JtQWJvdXREZXByZWNhdGlvbigpIHtcbiAgY29uc29sZS53YXJuKGVycm9yTWVzc2FnZXMuZGVwcmVjYXRpb24pO1xufVxuXG5mdW5jdGlvbiB0aHJvd0Vycm9yKGVycm9yTWVzc2FnZXMsIHR5cGUpIHtcbiAgdGhyb3cgbmV3IEVycm9yKGVycm9yTWVzc2FnZXNbdHlwZV0gfHwgZXJyb3JNZXNzYWdlc1tcImRlZmF1bHRcIl0pO1xufVxuXG52YXIgZXJyb3JNZXNzYWdlcyA9IHtcbiAgY29uZmlnSXNSZXF1aXJlZDogJ3RoZSBjb25maWd1cmF0aW9uIG9iamVjdCBpcyByZXF1aXJlZCcsXG4gIGNvbmZpZ1R5cGU6ICd0aGUgY29uZmlndXJhdGlvbiBvYmplY3Qgc2hvdWxkIGJlIGFuIG9iamVjdCcsXG4gIFwiZGVmYXVsdFwiOiAnYW4gdW5rbm93biBlcnJvciBhY2N1cmVkIGluIGBAbW9uYWNvLWVkaXRvci9sb2FkZXJgIHBhY2thZ2UnLFxuICBkZXByZWNhdGlvbjogXCJEZXByZWNhdGlvbiB3YXJuaW5nIVxcbiAgICBZb3UgYXJlIHVzaW5nIGRlcHJlY2F0ZWQgd2F5IG9mIGNvbmZpZ3VyYXRpb24uXFxuXFxuICAgIEluc3RlYWQgb2YgdXNpbmdcXG4gICAgICBtb25hY28uY29uZmlnKHsgdXJsczogeyBtb25hY29CYXNlOiAnLi4uJyB9IH0pXFxuICAgIHVzZVxcbiAgICAgIG1vbmFjby5jb25maWcoeyBwYXRoczogeyB2czogJy4uLicgfSB9KVxcblxcbiAgICBGb3IgbW9yZSBwbGVhc2UgY2hlY2sgdGhlIGxpbmsgaHR0cHM6Ly9naXRodWIuY29tL3N1cmVuLWF0b3lhbi9tb25hY28tbG9hZGVyI2NvbmZpZ1xcbiAgXCJcbn07XG52YXIgZXJyb3JIYW5kbGVyID0gY3VycnkodGhyb3dFcnJvcikoZXJyb3JNZXNzYWdlcyk7XG52YXIgdmFsaWRhdG9ycyA9IHtcbiAgY29uZmlnOiB2YWxpZGF0ZUNvbmZpZ1xufTtcblxuZXhwb3J0IGRlZmF1bHQgdmFsaWRhdG9ycztcbmV4cG9ydCB7IGVycm9ySGFuZGxlciwgZXJyb3JNZXNzYWdlcyB9O1xuIiwiaW1wb3J0IGxvYWRlciBmcm9tICdAbW9uYWNvLWVkaXRvci9sb2FkZXInO1xuaW1wb3J0IFJlYWN0LCB7IHVzZVN0YXRlLCB1c2VSZWYsIHVzZUNhbGxiYWNrLCB1c2VFZmZlY3QgfSBmcm9tICdyZWFjdCc7XG5pbXBvcnQgUHJvcFR5cGVzIGZyb20gJ3Byb3AtdHlwZXMnO1xuaW1wb3J0IE1vbmFjb0NvbnRhaW5lciBmcm9tICcuLi9Nb25hY29Db250YWluZXIvaW5kZXguanMnO1xuaW1wb3J0IHVzZU1vdW50IGZyb20gJy4uL2hvb2tzL3VzZU1vdW50L2luZGV4LmpzJztcbmltcG9ydCB1c2VVcGRhdGUgZnJvbSAnLi4vaG9va3MvdXNlVXBkYXRlL2luZGV4LmpzJztcbmltcG9ydCB7IG5vb3AgfSBmcm9tICcuLi91dGlscy9pbmRleC5qcyc7XG5cbmZ1bmN0aW9uIERpZmZFZGl0b3Ioe1xuICBvcmlnaW5hbCxcbiAgbW9kaWZpZWQsXG4gIGxhbmd1YWdlLFxuICBvcmlnaW5hbExhbmd1YWdlLFxuICBtb2RpZmllZExhbmd1YWdlLFxuXG4gIC8qID09PSAqL1xuICBvcmlnaW5hbE1vZGVsUGF0aCxcbiAgbW9kaWZpZWRNb2RlbFBhdGgsXG4gIGtlZXBDdXJyZW50T3JpZ2luYWxNb2RlbCxcbiAga2VlcEN1cnJlbnRNb2RpZmllZE1vZGVsLFxuICB0aGVtZSxcbiAgbG9hZGluZyxcbiAgb3B0aW9ucyxcblxuICAvKiA9PT0gKi9cbiAgaGVpZ2h0LFxuICB3aWR0aCxcbiAgY2xhc3NOYW1lLFxuICB3cmFwcGVyQ2xhc3NOYW1lLFxuXG4gIC8qID09PSAqL1xuICBiZWZvcmVNb3VudCxcbiAgb25Nb3VudFxufSkge1xuICBjb25zdCBbaXNFZGl0b3JSZWFkeSwgc2V0SXNFZGl0b3JSZWFkeV0gPSB1c2VTdGF0ZShmYWxzZSk7XG4gIGNvbnN0IFtpc01vbmFjb01vdW50aW5nLCBzZXRJc01vbmFjb01vdW50aW5nXSA9IHVzZVN0YXRlKHRydWUpO1xuICBjb25zdCBlZGl0b3JSZWYgPSB1c2VSZWYobnVsbCk7XG4gIGNvbnN0IG1vbmFjb1JlZiA9IHVzZVJlZihudWxsKTtcbiAgY29uc3QgY29udGFpbmVyUmVmID0gdXNlUmVmKG51bGwpO1xuICBjb25zdCBvbk1vdW50UmVmID0gdXNlUmVmKG9uTW91bnQpO1xuICBjb25zdCBiZWZvcmVNb3VudFJlZiA9IHVzZVJlZihiZWZvcmVNb3VudCk7XG4gIHVzZU1vdW50KCgpID0+IHtcbiAgICBjb25zdCBjYW5jZWxhYmxlID0gbG9hZGVyLmluaXQoKTtcbiAgICBjYW5jZWxhYmxlLnRoZW4obW9uYWNvID0+IChtb25hY29SZWYuY3VycmVudCA9IG1vbmFjbykgJiYgc2V0SXNNb25hY29Nb3VudGluZyhmYWxzZSkpLmNhdGNoKGVycm9yID0+IChlcnJvciA9PT0gbnVsbCB8fCBlcnJvciA9PT0gdm9pZCAwID8gdm9pZCAwIDogZXJyb3IudHlwZSkgIT09ICdjYW5jZWxhdGlvbicgJiYgY29uc29sZS5lcnJvcignTW9uYWNvIGluaXRpYWxpemF0aW9uOiBlcnJvcjonLCBlcnJvcikpO1xuICAgIHJldHVybiAoKSA9PiBlZGl0b3JSZWYuY3VycmVudCA/IGRpc3Bvc2VFZGl0b3IoKSA6IGNhbmNlbGFibGUuY2FuY2VsKCk7XG4gIH0pO1xuICB1c2VVcGRhdGUoKCkgPT4ge1xuICAgIGNvbnN0IG1vZGlmaWVkRWRpdG9yID0gZWRpdG9yUmVmLmN1cnJlbnQuZ2V0TW9kaWZpZWRFZGl0b3IoKTtcblxuICAgIGlmIChtb2RpZmllZEVkaXRvci5nZXRPcHRpb24obW9uYWNvUmVmLmN1cnJlbnQuZWRpdG9yLkVkaXRvck9wdGlvbi5yZWFkT25seSkpIHtcbiAgICAgIG1vZGlmaWVkRWRpdG9yLnNldFZhbHVlKG1vZGlmaWVkKTtcbiAgICB9IGVsc2Uge1xuICAgICAgaWYgKG1vZGlmaWVkICE9PSBtb2RpZmllZEVkaXRvci5nZXRWYWx1ZSgpKSB7XG4gICAgICAgIG1vZGlmaWVkRWRpdG9yLmV4ZWN1dGVFZGl0cygnJywgW3tcbiAgICAgICAgICByYW5nZTogbW9kaWZpZWRFZGl0b3IuZ2V0TW9kZWwoKS5nZXRGdWxsTW9kZWxSYW5nZSgpLFxuICAgICAgICAgIHRleHQ6IG1vZGlmaWVkLFxuICAgICAgICAgIGZvcmNlTW92ZU1hcmtlcnM6IHRydWVcbiAgICAgICAgfV0pO1xuICAgICAgICBtb2RpZmllZEVkaXRvci5wdXNoVW5kb1N0b3AoKTtcbiAgICAgIH1cbiAgICB9XG4gIH0sIFttb2RpZmllZF0sIGlzRWRpdG9yUmVhZHkpO1xuICB1c2VVcGRhdGUoKCkgPT4ge1xuICAgIGVkaXRvclJlZi5jdXJyZW50LmdldE1vZGVsKCkub3JpZ2luYWwuc2V0VmFsdWUob3JpZ2luYWwpO1xuICB9LCBbb3JpZ2luYWxdLCBpc0VkaXRvclJlYWR5KTtcbiAgdXNlVXBkYXRlKCgpID0+IHtcbiAgICBjb25zdCB7XG4gICAgICBvcmlnaW5hbCxcbiAgICAgIG1vZGlmaWVkXG4gICAgfSA9IGVkaXRvclJlZi5jdXJyZW50LmdldE1vZGVsKCk7XG4gICAgbW9uYWNvUmVmLmN1cnJlbnQuZWRpdG9yLnNldE1vZGVsTGFuZ3VhZ2Uob3JpZ2luYWwsIG9yaWdpbmFsTGFuZ3VhZ2UgfHwgbGFuZ3VhZ2UpO1xuICAgIG1vbmFjb1JlZi5jdXJyZW50LmVkaXRvci5zZXRNb2RlbExhbmd1YWdlKG1vZGlmaWVkLCBtb2RpZmllZExhbmd1YWdlIHx8IGxhbmd1YWdlKTtcbiAgfSwgW2xhbmd1YWdlLCBvcmlnaW5hbExhbmd1YWdlLCBtb2RpZmllZExhbmd1YWdlXSwgaXNFZGl0b3JSZWFkeSk7XG4gIHVzZVVwZGF0ZSgoKSA9PiB7XG4gICAgbW9uYWNvUmVmLmN1cnJlbnQuZWRpdG9yLnNldFRoZW1lKHRoZW1lKTtcbiAgfSwgW3RoZW1lXSwgaXNFZGl0b3JSZWFkeSk7XG4gIHVzZVVwZGF0ZSgoKSA9PiB7XG4gICAgZWRpdG9yUmVmLmN1cnJlbnQudXBkYXRlT3B0aW9ucyhvcHRpb25zKTtcbiAgfSwgW29wdGlvbnNdLCBpc0VkaXRvclJlYWR5KTtcbiAgY29uc3Qgc2V0TW9kZWxzID0gdXNlQ2FsbGJhY2soKCkgPT4ge1xuICAgIGJlZm9yZU1vdW50UmVmLmN1cnJlbnQobW9uYWNvUmVmLmN1cnJlbnQpO1xuICAgIGNvbnN0IG9yaWdpbmFsTW9kZWwgPSBtb25hY29SZWYuY3VycmVudC5lZGl0b3IuY3JlYXRlTW9kZWwob3JpZ2luYWwsIG9yaWdpbmFsTGFuZ3VhZ2UgfHwgbGFuZ3VhZ2UsIG9yaWdpbmFsTW9kZWxQYXRoICYmIG1vbmFjb1JlZi5jdXJyZW50LlVyaS5wYXJzZShvcmlnaW5hbE1vZGVsUGF0aCkpO1xuICAgIGNvbnN0IG1vZGlmaWVkTW9kZWwgPSBtb25hY29SZWYuY3VycmVudC5lZGl0b3IuY3JlYXRlTW9kZWwobW9kaWZpZWQsIG1vZGlmaWVkTGFuZ3VhZ2UgfHwgbGFuZ3VhZ2UsIG1vZGlmaWVkTW9kZWxQYXRoICYmIG1vbmFjb1JlZi5jdXJyZW50LlVyaS5wYXJzZShtb2RpZmllZE1vZGVsUGF0aCkpO1xuICAgIGVkaXRvclJlZi5jdXJyZW50LnNldE1vZGVsKHtcbiAgICAgIG9yaWdpbmFsOiBvcmlnaW5hbE1vZGVsLFxuICAgICAgbW9kaWZpZWQ6IG1vZGlmaWVkTW9kZWxcbiAgICB9KTtcbiAgfSwgW2xhbmd1YWdlLCBtb2RpZmllZCwgbW9kaWZpZWRMYW5ndWFnZSwgb3JpZ2luYWwsIG9yaWdpbmFsTGFuZ3VhZ2UsIG9yaWdpbmFsTW9kZWxQYXRoLCBtb2RpZmllZE1vZGVsUGF0aF0pO1xuICBjb25zdCBjcmVhdGVFZGl0b3IgPSB1c2VDYWxsYmFjaygoKSA9PiB7XG4gICAgZWRpdG9yUmVmLmN1cnJlbnQgPSBtb25hY29SZWYuY3VycmVudC5lZGl0b3IuY3JlYXRlRGlmZkVkaXRvcihjb250YWluZXJSZWYuY3VycmVudCwge1xuICAgICAgYXV0b21hdGljTGF5b3V0OiB0cnVlLFxuICAgICAgLi4ub3B0aW9uc1xuICAgIH0pO1xuICAgIHNldE1vZGVscygpO1xuICAgIG1vbmFjb1JlZi5jdXJyZW50LmVkaXRvci5zZXRUaGVtZSh0aGVtZSk7XG4gICAgc2V0SXNFZGl0b3JSZWFkeSh0cnVlKTtcbiAgfSwgW29wdGlvbnMsIHRoZW1lLCBzZXRNb2RlbHNdKTtcbiAgdXNlRWZmZWN0KCgpID0+IHtcbiAgICBpZiAoaXNFZGl0b3JSZWFkeSkge1xuICAgICAgb25Nb3VudFJlZi5jdXJyZW50KGVkaXRvclJlZi5jdXJyZW50LCBtb25hY29SZWYuY3VycmVudCk7XG4gICAgfVxuICB9LCBbaXNFZGl0b3JSZWFkeV0pO1xuICB1c2VFZmZlY3QoKCkgPT4ge1xuICAgICFpc01vbmFjb01vdW50aW5nICYmICFpc0VkaXRvclJlYWR5ICYmIGNyZWF0ZUVkaXRvcigpO1xuICB9LCBbaXNNb25hY29Nb3VudGluZywgaXNFZGl0b3JSZWFkeSwgY3JlYXRlRWRpdG9yXSk7XG5cbiAgZnVuY3Rpb24gZGlzcG9zZUVkaXRvcigpIHtcbiAgICBjb25zdCBtb2RlbHMgPSBlZGl0b3JSZWYuY3VycmVudC5nZXRNb2RlbCgpO1xuXG4gICAgaWYgKCFrZWVwQ3VycmVudE9yaWdpbmFsTW9kZWwpIHtcbiAgICAgIHZhciBfbW9kZWxzJG9yaWdpbmFsO1xuXG4gICAgICAoX21vZGVscyRvcmlnaW5hbCA9IG1vZGVscy5vcmlnaW5hbCkgPT09IG51bGwgfHwgX21vZGVscyRvcmlnaW5hbCA9PT0gdm9pZCAwID8gdm9pZCAwIDogX21vZGVscyRvcmlnaW5hbC5kaXNwb3NlKCk7XG4gICAgfVxuXG4gICAgaWYgKCFrZWVwQ3VycmVudE1vZGlmaWVkTW9kZWwpIHtcbiAgICAgIHZhciBfbW9kZWxzJG1vZGlmaWVkO1xuXG4gICAgICAoX21vZGVscyRtb2RpZmllZCA9IG1vZGVscy5tb2RpZmllZCkgPT09IG51bGwgfHwgX21vZGVscyRtb2RpZmllZCA9PT0gdm9pZCAwID8gdm9pZCAwIDogX21vZGVscyRtb2RpZmllZC5kaXNwb3NlKCk7XG4gICAgfVxuXG4gICAgZWRpdG9yUmVmLmN1cnJlbnQuZGlzcG9zZSgpO1xuICB9XG5cbiAgcmV0dXJuIC8qI19fUFVSRV9fKi9SZWFjdC5jcmVhdGVFbGVtZW50KE1vbmFjb0NvbnRhaW5lciwge1xuICAgIHdpZHRoOiB3aWR0aCxcbiAgICBoZWlnaHQ6IGhlaWdodCxcbiAgICBpc0VkaXRvclJlYWR5OiBpc0VkaXRvclJlYWR5LFxuICAgIGxvYWRpbmc6IGxvYWRpbmcsXG4gICAgX3JlZjogY29udGFpbmVyUmVmLFxuICAgIGNsYXNzTmFtZTogY2xhc3NOYW1lLFxuICAgIHdyYXBwZXJDbGFzc05hbWU6IHdyYXBwZXJDbGFzc05hbWVcbiAgfSk7XG59XG5cbkRpZmZFZGl0b3IucHJvcFR5cGVzID0ge1xuICBvcmlnaW5hbDogUHJvcFR5cGVzLnN0cmluZyxcbiAgbW9kaWZpZWQ6IFByb3BUeXBlcy5zdHJpbmcsXG4gIGxhbmd1YWdlOiBQcm9wVHlwZXMuc3RyaW5nLFxuICBvcmlnaW5hbExhbmd1YWdlOiBQcm9wVHlwZXMuc3RyaW5nLFxuICBtb2RpZmllZExhbmd1YWdlOiBQcm9wVHlwZXMuc3RyaW5nLFxuXG4gIC8qID09PSAqL1xuICBvcmlnaW5hbE1vZGVsUGF0aDogUHJvcFR5cGVzLnN0cmluZyxcbiAgbW9kaWZpZWRNb2RlbFBhdGg6IFByb3BUeXBlcy5zdHJpbmcsXG4gIGtlZXBDdXJyZW50T3JpZ2luYWxNb2RlbDogUHJvcFR5cGVzLmJvb2wsXG4gIGtlZXBDdXJyZW50TW9kaWZpZWRNb2RlbDogUHJvcFR5cGVzLmJvb2wsXG4gIHRoZW1lOiBQcm9wVHlwZXMuc3RyaW5nLFxuICBsb2FkaW5nOiBQcm9wVHlwZXMub25lT2ZUeXBlKFtQcm9wVHlwZXMuZWxlbWVudCwgUHJvcFR5cGVzLnN0cmluZ10pLFxuICBvcHRpb25zOiBQcm9wVHlwZXMub2JqZWN0LFxuXG4gIC8qID09PSAqL1xuICB3aWR0aDogUHJvcFR5cGVzLm9uZU9mVHlwZShbUHJvcFR5cGVzLm51bWJlciwgUHJvcFR5cGVzLnN0cmluZ10pLFxuICBoZWlnaHQ6IFByb3BUeXBlcy5vbmVPZlR5cGUoW1Byb3BUeXBlcy5udW1iZXIsIFByb3BUeXBlcy5zdHJpbmddKSxcbiAgY2xhc3NOYW1lOiBQcm9wVHlwZXMuc3RyaW5nLFxuICB3cmFwcGVyQ2xhc3NOYW1lOiBQcm9wVHlwZXMuc3RyaW5nLFxuXG4gIC8qID09PSAqL1xuICBiZWZvcmVNb3VudDogUHJvcFR5cGVzLmZ1bmMsXG4gIG9uTW91bnQ6IFByb3BUeXBlcy5mdW5jXG59O1xuRGlmZkVkaXRvci5kZWZhdWx0UHJvcHMgPSB7XG4gIHRoZW1lOiAnbGlnaHQnLFxuICBsb2FkaW5nOiAnTG9hZGluZy4uLicsXG4gIG9wdGlvbnM6IHt9LFxuICBrZWVwQ3VycmVudE9yaWdpbmFsTW9kZWw6IGZhbHNlLFxuICBrZWVwQ3VycmVudE1vZGlmaWVkTW9kZWw6IGZhbHNlLFxuXG4gIC8qID09PSAqL1xuICB3aWR0aDogJzEwMCUnLFxuICBoZWlnaHQ6ICcxMDAlJyxcblxuICAvKiA9PT0gKi9cbiAgYmVmb3JlTW91bnQ6IG5vb3AsXG4gIG9uTW91bnQ6IG5vb3Bcbn07XG5cbmV4cG9ydCBkZWZhdWx0IERpZmZFZGl0b3I7XG4iLCJpbXBvcnQgeyBtZW1vIH0gZnJvbSAncmVhY3QnO1xuaW1wb3J0IERpZmZFZGl0b3IgZnJvbSAnLi9EaWZmRWRpdG9yLmpzJztcblxudmFyIGluZGV4ID0gLyojX19QVVJFX18qL21lbW8oRGlmZkVkaXRvcik7XG5cbmV4cG9ydCBkZWZhdWx0IGluZGV4O1xuIiwiaW1wb3J0IGxvYWRlciBmcm9tICdAbW9uYWNvLWVkaXRvci9sb2FkZXInO1xuaW1wb3J0IFJlYWN0LCB7IHVzZVN0YXRlLCB1c2VSZWYsIHVzZUNhbGxiYWNrLCB1c2VFZmZlY3QgfSBmcm9tICdyZWFjdCc7XG5pbXBvcnQgUHJvcFR5cGVzIGZyb20gJ3Byb3AtdHlwZXMnO1xuaW1wb3J0IE1vbmFjb0NvbnRhaW5lciBmcm9tICcuLi9Nb25hY29Db250YWluZXIvaW5kZXguanMnO1xuaW1wb3J0IHVzZU1vdW50IGZyb20gJy4uL2hvb2tzL3VzZU1vdW50L2luZGV4LmpzJztcbmltcG9ydCB1c2VVcGRhdGUgZnJvbSAnLi4vaG9va3MvdXNlVXBkYXRlL2luZGV4LmpzJztcbmltcG9ydCB7IGdldE9yQ3JlYXRlTW9kZWwsIG5vb3AsIGlzVW5kZWZpbmVkIH0gZnJvbSAnLi4vdXRpbHMvaW5kZXguanMnO1xuaW1wb3J0IHN0YXRlIGZyb20gJ3N0YXRlLWxvY2FsJztcbmltcG9ydCB1c2VQcmV2aW91cyBmcm9tICcuLi9ob29rcy91c2VQcmV2aW91cy9pbmRleC5qcyc7XG5cbmNvbnN0IFtnZXRNb2RlbE1hcmtlcnNTZXR0ZXIsIHNldE1vZGVsTWFya2Vyc1NldHRlcl0gPSBzdGF0ZS5jcmVhdGUoe1xuICBiYWNrdXA6IG51bGxcbn0pO1xuY29uc3Qgdmlld1N0YXRlcyA9IG5ldyBNYXAoKTtcblxuZnVuY3Rpb24gRWRpdG9yKHtcbiAgZGVmYXVsdFZhbHVlLFxuICBkZWZhdWx0TGFuZ3VhZ2UsXG4gIGRlZmF1bHRQYXRoLFxuICB2YWx1ZSxcbiAgbGFuZ3VhZ2UsXG4gIHBhdGgsXG5cbiAgLyogPT09ICovXG4gIHRoZW1lLFxuICBsaW5lLFxuICBsb2FkaW5nLFxuICBvcHRpb25zLFxuICBvdmVycmlkZVNlcnZpY2VzLFxuICBzYXZlVmlld1N0YXRlLFxuICBrZWVwQ3VycmVudE1vZGVsLFxuXG4gIC8qID09PSAqL1xuICB3aWR0aCxcbiAgaGVpZ2h0LFxuICBjbGFzc05hbWUsXG4gIHdyYXBwZXJDbGFzc05hbWUsXG5cbiAgLyogPT09ICovXG4gIGJlZm9yZU1vdW50LFxuICBvbk1vdW50LFxuICBvbkNoYW5nZSxcbiAgb25WYWxpZGF0ZVxufSkge1xuICBjb25zdCBbaXNFZGl0b3JSZWFkeSwgc2V0SXNFZGl0b3JSZWFkeV0gPSB1c2VTdGF0ZShmYWxzZSk7XG4gIGNvbnN0IFtpc01vbmFjb01vdW50aW5nLCBzZXRJc01vbmFjb01vdW50aW5nXSA9IHVzZVN0YXRlKHRydWUpO1xuICBjb25zdCBtb25hY29SZWYgPSB1c2VSZWYobnVsbCk7XG4gIGNvbnN0IGVkaXRvclJlZiA9IHVzZVJlZihudWxsKTtcbiAgY29uc3QgY29udGFpbmVyUmVmID0gdXNlUmVmKG51bGwpO1xuICBjb25zdCBvbk1vdW50UmVmID0gdXNlUmVmKG9uTW91bnQpO1xuICBjb25zdCBiZWZvcmVNb3VudFJlZiA9IHVzZVJlZihiZWZvcmVNb3VudCk7XG4gIGNvbnN0IHN1YnNjcmlwdGlvblJlZiA9IHVzZVJlZihudWxsKTtcbiAgY29uc3QgdmFsdWVSZWYgPSB1c2VSZWYodmFsdWUpO1xuICBjb25zdCBwcmV2aW91c1BhdGggPSB1c2VQcmV2aW91cyhwYXRoKTtcbiAgdXNlTW91bnQoKCkgPT4ge1xuICAgIGNvbnN0IGNhbmNlbGFibGUgPSBsb2FkZXIuaW5pdCgpO1xuICAgIGNhbmNlbGFibGUudGhlbihtb25hY28gPT4gKG1vbmFjb1JlZi5jdXJyZW50ID0gbW9uYWNvKSAmJiBzZXRJc01vbmFjb01vdW50aW5nKGZhbHNlKSkuY2F0Y2goZXJyb3IgPT4gKGVycm9yID09PSBudWxsIHx8IGVycm9yID09PSB2b2lkIDAgPyB2b2lkIDAgOiBlcnJvci50eXBlKSAhPT0gJ2NhbmNlbGF0aW9uJyAmJiBjb25zb2xlLmVycm9yKCdNb25hY28gaW5pdGlhbGl6YXRpb246IGVycm9yOicsIGVycm9yKSk7XG4gICAgcmV0dXJuICgpID0+IGVkaXRvclJlZi5jdXJyZW50ID8gZGlzcG9zZUVkaXRvcigpIDogY2FuY2VsYWJsZS5jYW5jZWwoKTtcbiAgfSk7XG4gIHVzZVVwZGF0ZSgoKSA9PiB7XG4gICAgY29uc3QgbW9kZWwgPSBnZXRPckNyZWF0ZU1vZGVsKG1vbmFjb1JlZi5jdXJyZW50LCBkZWZhdWx0VmFsdWUgfHwgdmFsdWUsIGRlZmF1bHRMYW5ndWFnZSB8fCBsYW5ndWFnZSwgcGF0aCk7XG5cbiAgICBpZiAobW9kZWwgIT09IGVkaXRvclJlZi5jdXJyZW50LmdldE1vZGVsKCkpIHtcbiAgICAgIHNhdmVWaWV3U3RhdGUgJiYgdmlld1N0YXRlcy5zZXQocHJldmlvdXNQYXRoLCBlZGl0b3JSZWYuY3VycmVudC5zYXZlVmlld1N0YXRlKCkpO1xuICAgICAgZWRpdG9yUmVmLmN1cnJlbnQuc2V0TW9kZWwobW9kZWwpO1xuICAgICAgc2F2ZVZpZXdTdGF0ZSAmJiBlZGl0b3JSZWYuY3VycmVudC5yZXN0b3JlVmlld1N0YXRlKHZpZXdTdGF0ZXMuZ2V0KHBhdGgpKTtcbiAgICB9XG4gIH0sIFtwYXRoXSwgaXNFZGl0b3JSZWFkeSk7XG4gIHVzZVVwZGF0ZSgoKSA9PiB7XG4gICAgZWRpdG9yUmVmLmN1cnJlbnQudXBkYXRlT3B0aW9ucyhvcHRpb25zKTtcbiAgfSwgW29wdGlvbnNdLCBpc0VkaXRvclJlYWR5KTtcbiAgdXNlVXBkYXRlKCgpID0+IHtcbiAgICBpZiAoZWRpdG9yUmVmLmN1cnJlbnQuZ2V0T3B0aW9uKG1vbmFjb1JlZi5jdXJyZW50LmVkaXRvci5FZGl0b3JPcHRpb24ucmVhZE9ubHkpKSB7XG4gICAgICBlZGl0b3JSZWYuY3VycmVudC5zZXRWYWx1ZSh2YWx1ZSk7XG4gICAgfSBlbHNlIHtcbiAgICAgIGlmICh2YWx1ZSAhPT0gZWRpdG9yUmVmLmN1cnJlbnQuZ2V0VmFsdWUoKSkge1xuICAgICAgICBlZGl0b3JSZWYuY3VycmVudC5leGVjdXRlRWRpdHMoJycsIFt7XG4gICAgICAgICAgcmFuZ2U6IGVkaXRvclJlZi5jdXJyZW50LmdldE1vZGVsKCkuZ2V0RnVsbE1vZGVsUmFuZ2UoKSxcbiAgICAgICAgICB0ZXh0OiB2YWx1ZSxcbiAgICAgICAgICBmb3JjZU1vdmVNYXJrZXJzOiB0cnVlXG4gICAgICAgIH1dKTtcbiAgICAgICAgZWRpdG9yUmVmLmN1cnJlbnQucHVzaFVuZG9TdG9wKCk7XG4gICAgICB9XG4gICAgfVxuICB9LCBbdmFsdWVdLCBpc0VkaXRvclJlYWR5KTtcbiAgdXNlVXBkYXRlKCgpID0+IHtcbiAgICBtb25hY29SZWYuY3VycmVudC5lZGl0b3Iuc2V0TW9kZWxMYW5ndWFnZShlZGl0b3JSZWYuY3VycmVudC5nZXRNb2RlbCgpLCBsYW5ndWFnZSk7XG4gIH0sIFtsYW5ndWFnZV0sIGlzRWRpdG9yUmVhZHkpO1xuICB1c2VVcGRhdGUoKCkgPT4ge1xuICAgIC8vIHJlYXNvbiBmb3IgdW5kZWZpbmVkIGNoZWNrOiBodHRwczovL2dpdGh1Yi5jb20vc3VyZW4tYXRveWFuL21vbmFjby1yZWFjdC9wdWxsLzE4OFxuICAgIGlmICghaXNVbmRlZmluZWQobGluZSkpIHtcbiAgICAgIGVkaXRvclJlZi5jdXJyZW50LnJldmVhbExpbmUobGluZSk7XG4gICAgfVxuICB9LCBbbGluZV0sIGlzRWRpdG9yUmVhZHkpO1xuICB1c2VVcGRhdGUoKCkgPT4ge1xuICAgIG1vbmFjb1JlZi5jdXJyZW50LmVkaXRvci5zZXRUaGVtZSh0aGVtZSk7XG4gIH0sIFt0aGVtZV0sIGlzRWRpdG9yUmVhZHkpO1xuICBjb25zdCBjcmVhdGVFZGl0b3IgPSB1c2VDYWxsYmFjaygoKSA9PiB7XG4gICAgYmVmb3JlTW91bnRSZWYuY3VycmVudChtb25hY29SZWYuY3VycmVudCk7XG4gICAgY29uc3QgYXV0b0NyZWF0ZWRNb2RlbFBhdGggPSBwYXRoIHx8IGRlZmF1bHRQYXRoO1xuICAgIGNvbnN0IGRlZmF1bHRNb2RlbCA9IGdldE9yQ3JlYXRlTW9kZWwobW9uYWNvUmVmLmN1cnJlbnQsIHZhbHVlIHx8IGRlZmF1bHRWYWx1ZSwgZGVmYXVsdExhbmd1YWdlIHx8IGxhbmd1YWdlLCBhdXRvQ3JlYXRlZE1vZGVsUGF0aCk7XG4gICAgZWRpdG9yUmVmLmN1cnJlbnQgPSBtb25hY29SZWYuY3VycmVudC5lZGl0b3IuY3JlYXRlKGNvbnRhaW5lclJlZi5jdXJyZW50LCB7XG4gICAgICBtb2RlbDogZGVmYXVsdE1vZGVsLFxuICAgICAgYXV0b21hdGljTGF5b3V0OiB0cnVlLFxuICAgICAgLi4ub3B0aW9uc1xuICAgIH0sIG92ZXJyaWRlU2VydmljZXMpO1xuICAgIHNhdmVWaWV3U3RhdGUgJiYgZWRpdG9yUmVmLmN1cnJlbnQucmVzdG9yZVZpZXdTdGF0ZSh2aWV3U3RhdGVzLmdldChhdXRvQ3JlYXRlZE1vZGVsUGF0aCkpO1xuICAgIG1vbmFjb1JlZi5jdXJyZW50LmVkaXRvci5zZXRUaGVtZSh0aGVtZSk7XG5cbiAgICBpZiAoIWdldE1vZGVsTWFya2Vyc1NldHRlcigpLmJhY2t1cCkge1xuICAgICAgc2V0TW9kZWxNYXJrZXJzU2V0dGVyKHtcbiAgICAgICAgYmFja3VwOiBtb25hY29SZWYuY3VycmVudC5lZGl0b3Iuc2V0TW9kZWxNYXJrZXJzXG4gICAgICB9KTtcbiAgICB9XG5cbiAgICBzZXRJc0VkaXRvclJlYWR5KHRydWUpO1xuICB9LCBbZGVmYXVsdFZhbHVlLCBkZWZhdWx0TGFuZ3VhZ2UsIGRlZmF1bHRQYXRoLCB2YWx1ZSwgbGFuZ3VhZ2UsIHBhdGgsIG9wdGlvbnMsIG92ZXJyaWRlU2VydmljZXMsIHNhdmVWaWV3U3RhdGUsIHRoZW1lXSk7XG4gIHVzZUVmZmVjdCgoKSA9PiB7XG4gICAgaWYgKGlzRWRpdG9yUmVhZHkpIHtcbiAgICAgIG9uTW91bnRSZWYuY3VycmVudChlZGl0b3JSZWYuY3VycmVudCwgbW9uYWNvUmVmLmN1cnJlbnQpO1xuICAgIH1cbiAgfSwgW2lzRWRpdG9yUmVhZHldKTtcbiAgdXNlRWZmZWN0KCgpID0+IHtcbiAgICAhaXNNb25hY29Nb3VudGluZyAmJiAhaXNFZGl0b3JSZWFkeSAmJiBjcmVhdGVFZGl0b3IoKTtcbiAgfSwgW2lzTW9uYWNvTW91bnRpbmcsIGlzRWRpdG9yUmVhZHksIGNyZWF0ZUVkaXRvcl0pOyAvLyBzdWJzY3JpcHRpb25cbiAgLy8gdG8gYXZvaWQgdW5uZWNlc3NhcnkgdXBkYXRlcyAoYXR0YWNoIC0gZGlzcG9zZSBsaXN0ZW5lcikgaW4gc3Vic2NyaXB0aW9uXG5cbiAgdmFsdWVSZWYuY3VycmVudCA9IHZhbHVlO1xuICB1c2VFZmZlY3QoKCkgPT4ge1xuICAgIGlmIChpc0VkaXRvclJlYWR5ICYmIG9uQ2hhbmdlKSB7XG4gICAgICB2YXIgX3N1YnNjcmlwdGlvblJlZiRjdXJyLCBfZWRpdG9yUmVmJGN1cnJlbnQ7XG5cbiAgICAgIChfc3Vic2NyaXB0aW9uUmVmJGN1cnIgPSBzdWJzY3JpcHRpb25SZWYuY3VycmVudCkgPT09IG51bGwgfHwgX3N1YnNjcmlwdGlvblJlZiRjdXJyID09PSB2b2lkIDAgPyB2b2lkIDAgOiBfc3Vic2NyaXB0aW9uUmVmJGN1cnIuZGlzcG9zZSgpO1xuICAgICAgc3Vic2NyaXB0aW9uUmVmLmN1cnJlbnQgPSAoX2VkaXRvclJlZiRjdXJyZW50ID0gZWRpdG9yUmVmLmN1cnJlbnQpID09PSBudWxsIHx8IF9lZGl0b3JSZWYkY3VycmVudCA9PT0gdm9pZCAwID8gdm9pZCAwIDogX2VkaXRvclJlZiRjdXJyZW50Lm9uRGlkQ2hhbmdlTW9kZWxDb250ZW50KGV2ZW50ID0+IHtcbiAgICAgICAgY29uc3QgZWRpdG9yVmFsdWUgPSBlZGl0b3JSZWYuY3VycmVudC5nZXRWYWx1ZSgpO1xuXG4gICAgICAgIGlmICh2YWx1ZVJlZi5jdXJyZW50ICE9PSBlZGl0b3JWYWx1ZSkge1xuICAgICAgICAgIG9uQ2hhbmdlKGVkaXRvclZhbHVlLCBldmVudCk7XG4gICAgICAgIH1cbiAgICAgIH0pO1xuICAgIH1cbiAgfSwgW2lzRWRpdG9yUmVhZHksIG9uQ2hhbmdlXSk7IC8vIG9uVmFsaWRhdGVcblxuICB1c2VFZmZlY3QoKCkgPT4ge1xuICAgIGlmIChpc0VkaXRvclJlYWR5KSB7XG4gICAgICBtb25hY29SZWYuY3VycmVudC5lZGl0b3Iuc2V0TW9kZWxNYXJrZXJzID0gZnVuY3Rpb24gKG1vZGVsLCBvd25lciwgbWFya2Vycykge1xuICAgICAgICB2YXIgX2dldE1vZGVsTWFya2Vyc1NldHRlO1xuXG4gICAgICAgIChfZ2V0TW9kZWxNYXJrZXJzU2V0dGUgPSBnZXRNb2RlbE1hcmtlcnNTZXR0ZXIoKS5iYWNrdXApID09PSBudWxsIHx8IF9nZXRNb2RlbE1hcmtlcnNTZXR0ZSA9PT0gdm9pZCAwID8gdm9pZCAwIDogX2dldE1vZGVsTWFya2Vyc1NldHRlLmNhbGwobW9uYWNvUmVmLmN1cnJlbnQuZWRpdG9yLCBtb2RlbCwgb3duZXIsIG1hcmtlcnMpO1xuICAgICAgICBvblZhbGlkYXRlID09PSBudWxsIHx8IG9uVmFsaWRhdGUgPT09IHZvaWQgMCA/IHZvaWQgMCA6IG9uVmFsaWRhdGUobWFya2Vycyk7XG4gICAgICB9O1xuICAgIH1cbiAgfSwgW2lzRWRpdG9yUmVhZHksIG9uVmFsaWRhdGVdKTtcblxuICBmdW5jdGlvbiBkaXNwb3NlRWRpdG9yKCkge1xuICAgIHZhciBfc3Vic2NyaXB0aW9uUmVmJGN1cnIyO1xuXG4gICAgKF9zdWJzY3JpcHRpb25SZWYkY3VycjIgPSBzdWJzY3JpcHRpb25SZWYuY3VycmVudCkgPT09IG51bGwgfHwgX3N1YnNjcmlwdGlvblJlZiRjdXJyMiA9PT0gdm9pZCAwID8gdm9pZCAwIDogX3N1YnNjcmlwdGlvblJlZiRjdXJyMi5kaXNwb3NlKCk7XG5cbiAgICBpZiAoa2VlcEN1cnJlbnRNb2RlbCkge1xuICAgICAgc2F2ZVZpZXdTdGF0ZSAmJiB2aWV3U3RhdGVzLnNldChwYXRoLCBlZGl0b3JSZWYuY3VycmVudC5zYXZlVmlld1N0YXRlKCkpO1xuICAgIH0gZWxzZSB7XG4gICAgICB2YXIgX2VkaXRvclJlZiRjdXJyZW50JGdlO1xuXG4gICAgICAoX2VkaXRvclJlZiRjdXJyZW50JGdlID0gZWRpdG9yUmVmLmN1cnJlbnQuZ2V0TW9kZWwoKSkgPT09IG51bGwgfHwgX2VkaXRvclJlZiRjdXJyZW50JGdlID09PSB2b2lkIDAgPyB2b2lkIDAgOiBfZWRpdG9yUmVmJGN1cnJlbnQkZ2UuZGlzcG9zZSgpO1xuICAgIH1cblxuICAgIGVkaXRvclJlZi5jdXJyZW50LmRpc3Bvc2UoKTtcbiAgfVxuXG4gIHJldHVybiAvKiNfX1BVUkVfXyovUmVhY3QuY3JlYXRlRWxlbWVudChNb25hY29Db250YWluZXIsIHtcbiAgICB3aWR0aDogd2lkdGgsXG4gICAgaGVpZ2h0OiBoZWlnaHQsXG4gICAgaXNFZGl0b3JSZWFkeTogaXNFZGl0b3JSZWFkeSxcbiAgICBsb2FkaW5nOiBsb2FkaW5nLFxuICAgIF9yZWY6IGNvbnRhaW5lclJlZixcbiAgICBjbGFzc05hbWU6IGNsYXNzTmFtZSxcbiAgICB3cmFwcGVyQ2xhc3NOYW1lOiB3cmFwcGVyQ2xhc3NOYW1lXG4gIH0pO1xufVxuXG5FZGl0b3IucHJvcFR5cGVzID0ge1xuICBkZWZhdWx0VmFsdWU6IFByb3BUeXBlcy5zdHJpbmcsXG4gIGRlZmF1bHRQYXRoOiBQcm9wVHlwZXMuc3RyaW5nLFxuICBkZWZhdWx0TGFuZ3VhZ2U6IFByb3BUeXBlcy5zdHJpbmcsXG4gIHZhbHVlOiBQcm9wVHlwZXMuc3RyaW5nLFxuICBsYW5ndWFnZTogUHJvcFR5cGVzLnN0cmluZyxcbiAgcGF0aDogUHJvcFR5cGVzLnN0cmluZyxcblxuICAvKiA9PT0gKi9cbiAgdGhlbWU6IFByb3BUeXBlcy5zdHJpbmcsXG4gIGxpbmU6IFByb3BUeXBlcy5udW1iZXIsXG4gIGxvYWRpbmc6IFByb3BUeXBlcy5vbmVPZlR5cGUoW1Byb3BUeXBlcy5lbGVtZW50LCBQcm9wVHlwZXMuc3RyaW5nXSksXG4gIG9wdGlvbnM6IFByb3BUeXBlcy5vYmplY3QsXG4gIG92ZXJyaWRlU2VydmljZXM6IFByb3BUeXBlcy5vYmplY3QsXG4gIHNhdmVWaWV3U3RhdGU6IFByb3BUeXBlcy5ib29sLFxuICBrZWVwQ3VycmVudE1vZGVsOiBQcm9wVHlwZXMuYm9vbCxcblxuICAvKiA9PT0gKi9cbiAgd2lkdGg6IFByb3BUeXBlcy5vbmVPZlR5cGUoW1Byb3BUeXBlcy5udW1iZXIsIFByb3BUeXBlcy5zdHJpbmddKSxcbiAgaGVpZ2h0OiBQcm9wVHlwZXMub25lT2ZUeXBlKFtQcm9wVHlwZXMubnVtYmVyLCBQcm9wVHlwZXMuc3RyaW5nXSksXG4gIGNsYXNzTmFtZTogUHJvcFR5cGVzLnN0cmluZyxcbiAgd3JhcHBlckNsYXNzTmFtZTogUHJvcFR5cGVzLnN0cmluZyxcblxuICAvKiA9PT0gKi9cbiAgYmVmb3JlTW91bnQ6IFByb3BUeXBlcy5mdW5jLFxuICBvbk1vdW50OiBQcm9wVHlwZXMuZnVuYyxcbiAgb25DaGFuZ2U6IFByb3BUeXBlcy5mdW5jLFxuICBvblZhbGlkYXRlOiBQcm9wVHlwZXMuZnVuY1xufTtcbkVkaXRvci5kZWZhdWx0UHJvcHMgPSB7XG4gIHRoZW1lOiAnbGlnaHQnLFxuICBsb2FkaW5nOiAnTG9hZGluZy4uLicsXG4gIG9wdGlvbnM6IHt9LFxuICBvdmVycmlkZVNlcnZpY2VzOiB7fSxcbiAgc2F2ZVZpZXdTdGF0ZTogdHJ1ZSxcbiAga2VlcEN1cnJlbnRNb2RlbDogZmFsc2UsXG5cbiAgLyogPT09ICovXG4gIHdpZHRoOiAnMTAwJScsXG4gIGhlaWdodDogJzEwMCUnLFxuXG4gIC8qID09PSAqL1xuICBiZWZvcmVNb3VudDogbm9vcCxcbiAgb25Nb3VudDogbm9vcCxcbiAgb25WYWxpZGF0ZTogbm9vcFxufTtcblxuZXhwb3J0IGRlZmF1bHQgRWRpdG9yO1xuIiwiaW1wb3J0IHsgbWVtbyB9IGZyb20gJ3JlYWN0JztcbmltcG9ydCBFZGl0b3IgZnJvbSAnLi9FZGl0b3IuanMnO1xuXG52YXIgaW5kZXggPSAvKiNfX1BVUkVfXyovbWVtbyhFZGl0b3IpO1xuXG5leHBvcnQgZGVmYXVsdCBpbmRleDtcbiIsImltcG9ydCBSZWFjdCBmcm9tICdyZWFjdCc7XG5cbmNvbnN0IGxvYWRpbmdTdHlsZXMgPSB7XG4gIGRpc3BsYXk6ICdmbGV4JyxcbiAgaGVpZ2h0OiAnMTAwJScsXG4gIHdpZHRoOiAnMTAwJScsXG4gIGp1c3RpZnlDb250ZW50OiAnY2VudGVyJyxcbiAgYWxpZ25JdGVtczogJ2NlbnRlcidcbn07XG5cbmZ1bmN0aW9uIExvYWRpbmcoe1xuICBjb250ZW50XG59KSB7XG4gIHJldHVybiAvKiNfX1BVUkVfXyovUmVhY3QuY3JlYXRlRWxlbWVudChcImRpdlwiLCB7XG4gICAgc3R5bGU6IGxvYWRpbmdTdHlsZXNcbiAgfSwgY29udGVudCk7XG59XG5cbmV4cG9ydCBkZWZhdWx0IExvYWRpbmc7XG4iLCJpbXBvcnQgUmVhY3QgZnJvbSAncmVhY3QnO1xuaW1wb3J0IFByb3BUeXBlcyBmcm9tICdwcm9wLXR5cGVzJztcbmltcG9ydCBMb2FkaW5nIGZyb20gJy4uL0xvYWRpbmcvTG9hZGluZy5qcyc7XG5pbXBvcnQgc3R5bGVzIGZyb20gJy4vc3R5bGVzLmpzJztcblxuLy8gb25lIG9mIHRoZSByZWFzb25zIHdoeSB3ZSB1c2UgYSBzZXBhcmF0ZSBwcm9wIGZvciBwYXNzaW5nIHJlZiBpbnN0ZWFkIG9mIHVzaW5nIGZvcndhcmRyZWZcblxuZnVuY3Rpb24gTW9uYWNvQ29udGFpbmVyKHtcbiAgd2lkdGgsXG4gIGhlaWdodCxcbiAgaXNFZGl0b3JSZWFkeSxcbiAgbG9hZGluZyxcbiAgX3JlZixcbiAgY2xhc3NOYW1lLFxuICB3cmFwcGVyQ2xhc3NOYW1lXG59KSB7XG4gIHJldHVybiAvKiNfX1BVUkVfXyovUmVhY3QuY3JlYXRlRWxlbWVudChcInNlY3Rpb25cIiwge1xuICAgIHN0eWxlOiB7IC4uLnN0eWxlcy53cmFwcGVyLFxuICAgICAgd2lkdGgsXG4gICAgICBoZWlnaHRcbiAgICB9LFxuICAgIGNsYXNzTmFtZTogd3JhcHBlckNsYXNzTmFtZVxuICB9LCAhaXNFZGl0b3JSZWFkeSAmJiAvKiNfX1BVUkVfXyovUmVhY3QuY3JlYXRlRWxlbWVudChMb2FkaW5nLCB7XG4gICAgY29udGVudDogbG9hZGluZ1xuICB9KSwgLyojX19QVVJFX18qL1JlYWN0LmNyZWF0ZUVsZW1lbnQoXCJkaXZcIiwge1xuICAgIHJlZjogX3JlZixcbiAgICBzdHlsZTogeyAuLi5zdHlsZXMuZnVsbFdpZHRoLFxuICAgICAgLi4uKCFpc0VkaXRvclJlYWR5ICYmIHN0eWxlcy5oaWRlKVxuICAgIH0sXG4gICAgY2xhc3NOYW1lOiBjbGFzc05hbWVcbiAgfSkpO1xufVxuXG5Nb25hY29Db250YWluZXIucHJvcFR5cGVzID0ge1xuICB3aWR0aDogUHJvcFR5cGVzLm9uZU9mVHlwZShbUHJvcFR5cGVzLm51bWJlciwgUHJvcFR5cGVzLnN0cmluZ10pLmlzUmVxdWlyZWQsXG4gIGhlaWdodDogUHJvcFR5cGVzLm9uZU9mVHlwZShbUHJvcFR5cGVzLm51bWJlciwgUHJvcFR5cGVzLnN0cmluZ10pLmlzUmVxdWlyZWQsXG4gIGxvYWRpbmc6IFByb3BUeXBlcy5vbmVPZlR5cGUoW1Byb3BUeXBlcy5lbGVtZW50LCBQcm9wVHlwZXMuc3RyaW5nXSkuaXNSZXF1aXJlZCxcbiAgaXNFZGl0b3JSZWFkeTogUHJvcFR5cGVzLmJvb2wuaXNSZXF1aXJlZCxcbiAgY2xhc3NOYW1lOiBQcm9wVHlwZXMuc3RyaW5nLFxuICB3cmFwcGVyQ2xhc3NOYW1lOiBQcm9wVHlwZXMuc3RyaW5nXG59O1xuXG5leHBvcnQgZGVmYXVsdCBNb25hY29Db250YWluZXI7XG4iLCJpbXBvcnQgeyBtZW1vIH0gZnJvbSAncmVhY3QnO1xuaW1wb3J0IE1vbmFjb0NvbnRhaW5lciQxIGZyb20gJy4vTW9uYWNvQ29udGFpbmVyLmpzJztcblxudmFyIE1vbmFjb0NvbnRhaW5lciA9IC8qI19fUFVSRV9fKi9tZW1vKE1vbmFjb0NvbnRhaW5lciQxKTtcblxuZXhwb3J0IGRlZmF1bHQgTW9uYWNvQ29udGFpbmVyO1xuIiwiY29uc3Qgc3R5bGVzID0ge1xuICB3cmFwcGVyOiB7XG4gICAgZGlzcGxheTogJ2ZsZXgnLFxuICAgIHBvc2l0aW9uOiAncmVsYXRpdmUnLFxuICAgIHRleHRBbGlnbjogJ2luaXRpYWwnXG4gIH0sXG4gIGZ1bGxXaWR0aDoge1xuICAgIHdpZHRoOiAnMTAwJSdcbiAgfSxcbiAgaGlkZToge1xuICAgIGRpc3BsYXk6ICdub25lJ1xuICB9XG59O1xuXG5leHBvcnQgZGVmYXVsdCBzdHlsZXM7XG4iLCJpbXBvcnQgbG9hZGVyIGZyb20gJ0Btb25hY28tZWRpdG9yL2xvYWRlcic7XG5pbXBvcnQgeyB1c2VTdGF0ZSB9IGZyb20gJ3JlYWN0JztcbmltcG9ydCB1c2VNb3VudCBmcm9tICcuLi91c2VNb3VudC9pbmRleC5qcyc7XG5cbmZ1bmN0aW9uIHVzZU1vbmFjbygpIHtcbiAgY29uc3QgW21vbmFjbywgc2V0TW9uYWNvXSA9IHVzZVN0YXRlKGxvYWRlci5fX2dldE1vbmFjb0luc3RhbmNlKCkpO1xuICB1c2VNb3VudCgoKSA9PiB7XG4gICAgbGV0IGNhbmNlbGFibGU7XG5cbiAgICBpZiAoIW1vbmFjbykge1xuICAgICAgY2FuY2VsYWJsZSA9IGxvYWRlci5pbml0KCk7XG4gICAgICBjYW5jZWxhYmxlLnRoZW4obW9uYWNvID0+IHtcbiAgICAgICAgc2V0TW9uYWNvKG1vbmFjbyk7XG4gICAgICB9KTtcbiAgICB9XG5cbiAgICByZXR1cm4gKCkgPT4ge1xuICAgICAgdmFyIF9jYW5jZWxhYmxlO1xuXG4gICAgICByZXR1cm4gKF9jYW5jZWxhYmxlID0gY2FuY2VsYWJsZSkgPT09IG51bGwgfHwgX2NhbmNlbGFibGUgPT09IHZvaWQgMCA/IHZvaWQgMCA6IF9jYW5jZWxhYmxlLmNhbmNlbCgpO1xuICAgIH07XG4gIH0pO1xuICByZXR1cm4gbW9uYWNvO1xufVxuXG5leHBvcnQgZGVmYXVsdCB1c2VNb25hY287XG4iLCJpbXBvcnQgeyB1c2VFZmZlY3QgfSBmcm9tICdyZWFjdCc7XG5cbmZ1bmN0aW9uIHVzZU1vdW50KGVmZmVjdCkge1xuICB1c2VFZmZlY3QoZWZmZWN0LCBbXSk7XG59XG5cbmV4cG9ydCBkZWZhdWx0IHVzZU1vdW50O1xuIiwiaW1wb3J0IHsgdXNlUmVmLCB1c2VFZmZlY3QgfSBmcm9tICdyZWFjdCc7XG5cbmZ1bmN0aW9uIHVzZVByZXZpb3VzKHZhbHVlKSB7XG4gIGNvbnN0IHJlZiA9IHVzZVJlZigpO1xuICB1c2VFZmZlY3QoKCkgPT4ge1xuICAgIHJlZi5jdXJyZW50ID0gdmFsdWU7XG4gIH0sIFt2YWx1ZV0pO1xuICByZXR1cm4gcmVmLmN1cnJlbnQ7XG59XG5cbmV4cG9ydCBkZWZhdWx0IHVzZVByZXZpb3VzO1xuIiwiaW1wb3J0IHsgdXNlUmVmLCB1c2VFZmZlY3QgfSBmcm9tICdyZWFjdCc7XG5cbmZ1bmN0aW9uIHVzZVVwZGF0ZShlZmZlY3QsIGRlcHMsIGFwcGx5Q2hhbmdlcyA9IHRydWUpIHtcbiAgY29uc3QgaXNJbml0aWFsTW91bnQgPSB1c2VSZWYodHJ1ZSk7XG4gIHVzZUVmZmVjdChpc0luaXRpYWxNb3VudC5jdXJyZW50IHx8ICFhcHBseUNoYW5nZXMgPyAoKSA9PiB7XG4gICAgaXNJbml0aWFsTW91bnQuY3VycmVudCA9IGZhbHNlO1xuICB9IDogZWZmZWN0LCBkZXBzKTtcbn1cblxuZXhwb3J0IGRlZmF1bHQgdXNlVXBkYXRlO1xuIiwiZXhwb3J0IHsgZGVmYXVsdCBhcyBsb2FkZXIgfSBmcm9tICdAbW9uYWNvLWVkaXRvci9sb2FkZXInO1xuZXhwb3J0IHsgZGVmYXVsdCBhcyBEaWZmRWRpdG9yIH0gZnJvbSAnLi9EaWZmRWRpdG9yL2luZGV4LmpzJztcbmV4cG9ydCB7IGRlZmF1bHQgYXMgdXNlTW9uYWNvIH0gZnJvbSAnLi9ob29rcy91c2VNb25hY28vaW5kZXguanMnO1xuZXhwb3J0IHsgZGVmYXVsdCB9IGZyb20gJy4vRWRpdG9yL2luZGV4LmpzJztcbiIsImZ1bmN0aW9uIG5vb3AoKSB7fVxuXG5mdW5jdGlvbiBnZXRPckNyZWF0ZU1vZGVsKG1vbmFjbywgdmFsdWUsIGxhbmd1YWdlLCBwYXRoKSB7XG4gIHJldHVybiBnZXRNb2RlbChtb25hY28sIHBhdGgpIHx8IGNyZWF0ZU1vZGVsKG1vbmFjbywgdmFsdWUsIGxhbmd1YWdlLCBwYXRoKTtcbn1cblxuZnVuY3Rpb24gZ2V0TW9kZWwobW9uYWNvLCBwYXRoKSB7XG4gIHJldHVybiBtb25hY28uZWRpdG9yLmdldE1vZGVsKGNyYXRlTW9kZWxVcmkobW9uYWNvLCBwYXRoKSk7XG59XG5cbmZ1bmN0aW9uIGNyZWF0ZU1vZGVsKG1vbmFjbywgdmFsdWUsIGxhbmd1YWdlLCBwYXRoKSB7XG4gIHJldHVybiBtb25hY28uZWRpdG9yLmNyZWF0ZU1vZGVsKHZhbHVlLCBsYW5ndWFnZSwgcGF0aCAmJiBjcmF0ZU1vZGVsVXJpKG1vbmFjbywgcGF0aCkpO1xufVxuXG5mdW5jdGlvbiBjcmF0ZU1vZGVsVXJpKG1vbmFjbywgcGF0aCkge1xuICByZXR1cm4gbW9uYWNvLlVyaS5wYXJzZShwYXRoKTtcbn1cblxuZnVuY3Rpb24gaXNVbmRlZmluZWQoaW5wdXQpIHtcbiAgcmV0dXJuIGlucHV0ID09PSB1bmRlZmluZWQ7XG59XG5cbmV4cG9ydCB7IGdldE9yQ3JlYXRlTW9kZWwsIGlzVW5kZWZpbmVkLCBub29wIH07XG4iLCJmdW5jdGlvbiBfZGVmaW5lUHJvcGVydHkob2JqLCBrZXksIHZhbHVlKSB7XG4gIGlmIChrZXkgaW4gb2JqKSB7XG4gICAgT2JqZWN0LmRlZmluZVByb3BlcnR5KG9iaiwga2V5LCB7XG4gICAgICB2YWx1ZTogdmFsdWUsXG4gICAgICBlbnVtZXJhYmxlOiB0cnVlLFxuICAgICAgY29uZmlndXJhYmxlOiB0cnVlLFxuICAgICAgd3JpdGFibGU6IHRydWVcbiAgICB9KTtcbiAgfSBlbHNlIHtcbiAgICBvYmpba2V5XSA9IHZhbHVlO1xuICB9XG5cbiAgcmV0dXJuIG9iajtcbn1cblxuZnVuY3Rpb24gb3duS2V5cyhvYmplY3QsIGVudW1lcmFibGVPbmx5KSB7XG4gIHZhciBrZXlzID0gT2JqZWN0LmtleXMob2JqZWN0KTtcblxuICBpZiAoT2JqZWN0LmdldE93blByb3BlcnR5U3ltYm9scykge1xuICAgIHZhciBzeW1ib2xzID0gT2JqZWN0LmdldE93blByb3BlcnR5U3ltYm9scyhvYmplY3QpO1xuICAgIGlmIChlbnVtZXJhYmxlT25seSkgc3ltYm9scyA9IHN5bWJvbHMuZmlsdGVyKGZ1bmN0aW9uIChzeW0pIHtcbiAgICAgIHJldHVybiBPYmplY3QuZ2V0T3duUHJvcGVydHlEZXNjcmlwdG9yKG9iamVjdCwgc3ltKS5lbnVtZXJhYmxlO1xuICAgIH0pO1xuICAgIGtleXMucHVzaC5hcHBseShrZXlzLCBzeW1ib2xzKTtcbiAgfVxuXG4gIHJldHVybiBrZXlzO1xufVxuXG5mdW5jdGlvbiBfb2JqZWN0U3ByZWFkMih0YXJnZXQpIHtcbiAgZm9yICh2YXIgaSA9IDE7IGkgPCBhcmd1bWVudHMubGVuZ3RoOyBpKyspIHtcbiAgICB2YXIgc291cmNlID0gYXJndW1lbnRzW2ldICE9IG51bGwgPyBhcmd1bWVudHNbaV0gOiB7fTtcblxuICAgIGlmIChpICUgMikge1xuICAgICAgb3duS2V5cyhPYmplY3Qoc291cmNlKSwgdHJ1ZSkuZm9yRWFjaChmdW5jdGlvbiAoa2V5KSB7XG4gICAgICAgIF9kZWZpbmVQcm9wZXJ0eSh0YXJnZXQsIGtleSwgc291cmNlW2tleV0pO1xuICAgICAgfSk7XG4gICAgfSBlbHNlIGlmIChPYmplY3QuZ2V0T3duUHJvcGVydHlEZXNjcmlwdG9ycykge1xuICAgICAgT2JqZWN0LmRlZmluZVByb3BlcnRpZXModGFyZ2V0LCBPYmplY3QuZ2V0T3duUHJvcGVydHlEZXNjcmlwdG9ycyhzb3VyY2UpKTtcbiAgICB9IGVsc2Uge1xuICAgICAgb3duS2V5cyhPYmplY3Qoc291cmNlKSkuZm9yRWFjaChmdW5jdGlvbiAoa2V5KSB7XG4gICAgICAgIE9iamVjdC5kZWZpbmVQcm9wZXJ0eSh0YXJnZXQsIGtleSwgT2JqZWN0LmdldE93blByb3BlcnR5RGVzY3JpcHRvcihzb3VyY2UsIGtleSkpO1xuICAgICAgfSk7XG4gICAgfVxuICB9XG5cbiAgcmV0dXJuIHRhcmdldDtcbn1cblxuZnVuY3Rpb24gY29tcG9zZSgpIHtcbiAgZm9yICh2YXIgX2xlbiA9IGFyZ3VtZW50cy5sZW5ndGgsIGZucyA9IG5ldyBBcnJheShfbGVuKSwgX2tleSA9IDA7IF9rZXkgPCBfbGVuOyBfa2V5KyspIHtcbiAgICBmbnNbX2tleV0gPSBhcmd1bWVudHNbX2tleV07XG4gIH1cblxuICByZXR1cm4gZnVuY3Rpb24gKHgpIHtcbiAgICByZXR1cm4gZm5zLnJlZHVjZVJpZ2h0KGZ1bmN0aW9uICh5LCBmKSB7XG4gICAgICByZXR1cm4gZih5KTtcbiAgICB9LCB4KTtcbiAgfTtcbn1cblxuZnVuY3Rpb24gY3VycnkoZm4pIHtcbiAgcmV0dXJuIGZ1bmN0aW9uIGN1cnJpZWQoKSB7XG4gICAgdmFyIF90aGlzID0gdGhpcztcblxuICAgIGZvciAodmFyIF9sZW4yID0gYXJndW1lbnRzLmxlbmd0aCwgYXJncyA9IG5ldyBBcnJheShfbGVuMiksIF9rZXkyID0gMDsgX2tleTIgPCBfbGVuMjsgX2tleTIrKykge1xuICAgICAgYXJnc1tfa2V5Ml0gPSBhcmd1bWVudHNbX2tleTJdO1xuICAgIH1cblxuICAgIHJldHVybiBhcmdzLmxlbmd0aCA+PSBmbi5sZW5ndGggPyBmbi5hcHBseSh0aGlzLCBhcmdzKSA6IGZ1bmN0aW9uICgpIHtcbiAgICAgIGZvciAodmFyIF9sZW4zID0gYXJndW1lbnRzLmxlbmd0aCwgbmV4dEFyZ3MgPSBuZXcgQXJyYXkoX2xlbjMpLCBfa2V5MyA9IDA7IF9rZXkzIDwgX2xlbjM7IF9rZXkzKyspIHtcbiAgICAgICAgbmV4dEFyZ3NbX2tleTNdID0gYXJndW1lbnRzW19rZXkzXTtcbiAgICAgIH1cblxuICAgICAgcmV0dXJuIGN1cnJpZWQuYXBwbHkoX3RoaXMsIFtdLmNvbmNhdChhcmdzLCBuZXh0QXJncykpO1xuICAgIH07XG4gIH07XG59XG5cbmZ1bmN0aW9uIGlzT2JqZWN0KHZhbHVlKSB7XG4gIHJldHVybiB7fS50b1N0cmluZy5jYWxsKHZhbHVlKS5pbmNsdWRlcygnT2JqZWN0Jyk7XG59XG5cbmZ1bmN0aW9uIGlzRW1wdHkob2JqKSB7XG4gIHJldHVybiAhT2JqZWN0LmtleXMob2JqKS5sZW5ndGg7XG59XG5cbmZ1bmN0aW9uIGlzRnVuY3Rpb24odmFsdWUpIHtcbiAgcmV0dXJuIHR5cGVvZiB2YWx1ZSA9PT0gJ2Z1bmN0aW9uJztcbn1cblxuZnVuY3Rpb24gaGFzT3duUHJvcGVydHkob2JqZWN0LCBwcm9wZXJ0eSkge1xuICByZXR1cm4gT2JqZWN0LnByb3RvdHlwZS5oYXNPd25Qcm9wZXJ0eS5jYWxsKG9iamVjdCwgcHJvcGVydHkpO1xufVxuXG5mdW5jdGlvbiB2YWxpZGF0ZUNoYW5nZXMoaW5pdGlhbCwgY2hhbmdlcykge1xuICBpZiAoIWlzT2JqZWN0KGNoYW5nZXMpKSBlcnJvckhhbmRsZXIoJ2NoYW5nZVR5cGUnKTtcbiAgaWYgKE9iamVjdC5rZXlzKGNoYW5nZXMpLnNvbWUoZnVuY3Rpb24gKGZpZWxkKSB7XG4gICAgcmV0dXJuICFoYXNPd25Qcm9wZXJ0eShpbml0aWFsLCBmaWVsZCk7XG4gIH0pKSBlcnJvckhhbmRsZXIoJ2NoYW5nZUZpZWxkJyk7XG4gIHJldHVybiBjaGFuZ2VzO1xufVxuXG5mdW5jdGlvbiB2YWxpZGF0ZVNlbGVjdG9yKHNlbGVjdG9yKSB7XG4gIGlmICghaXNGdW5jdGlvbihzZWxlY3RvcikpIGVycm9ySGFuZGxlcignc2VsZWN0b3JUeXBlJyk7XG59XG5cbmZ1bmN0aW9uIHZhbGlkYXRlSGFuZGxlcihoYW5kbGVyKSB7XG4gIGlmICghKGlzRnVuY3Rpb24oaGFuZGxlcikgfHwgaXNPYmplY3QoaGFuZGxlcikpKSBlcnJvckhhbmRsZXIoJ2hhbmRsZXJUeXBlJyk7XG4gIGlmIChpc09iamVjdChoYW5kbGVyKSAmJiBPYmplY3QudmFsdWVzKGhhbmRsZXIpLnNvbWUoZnVuY3Rpb24gKF9oYW5kbGVyKSB7XG4gICAgcmV0dXJuICFpc0Z1bmN0aW9uKF9oYW5kbGVyKTtcbiAgfSkpIGVycm9ySGFuZGxlcignaGFuZGxlcnNUeXBlJyk7XG59XG5cbmZ1bmN0aW9uIHZhbGlkYXRlSW5pdGlhbChpbml0aWFsKSB7XG4gIGlmICghaW5pdGlhbCkgZXJyb3JIYW5kbGVyKCdpbml0aWFsSXNSZXF1aXJlZCcpO1xuICBpZiAoIWlzT2JqZWN0KGluaXRpYWwpKSBlcnJvckhhbmRsZXIoJ2luaXRpYWxUeXBlJyk7XG4gIGlmIChpc0VtcHR5KGluaXRpYWwpKSBlcnJvckhhbmRsZXIoJ2luaXRpYWxDb250ZW50Jyk7XG59XG5cbmZ1bmN0aW9uIHRocm93RXJyb3IoZXJyb3JNZXNzYWdlcywgdHlwZSkge1xuICB0aHJvdyBuZXcgRXJyb3IoZXJyb3JNZXNzYWdlc1t0eXBlXSB8fCBlcnJvck1lc3NhZ2VzW1wiZGVmYXVsdFwiXSk7XG59XG5cbnZhciBlcnJvck1lc3NhZ2VzID0ge1xuICBpbml0aWFsSXNSZXF1aXJlZDogJ2luaXRpYWwgc3RhdGUgaXMgcmVxdWlyZWQnLFxuICBpbml0aWFsVHlwZTogJ2luaXRpYWwgc3RhdGUgc2hvdWxkIGJlIGFuIG9iamVjdCcsXG4gIGluaXRpYWxDb250ZW50OiAnaW5pdGlhbCBzdGF0ZSBzaG91bGRuXFwndCBiZSBhbiBlbXB0eSBvYmplY3QnLFxuICBoYW5kbGVyVHlwZTogJ2hhbmRsZXIgc2hvdWxkIGJlIGFuIG9iamVjdCBvciBhIGZ1bmN0aW9uJyxcbiAgaGFuZGxlcnNUeXBlOiAnYWxsIGhhbmRsZXJzIHNob3VsZCBiZSBhIGZ1bmN0aW9ucycsXG4gIHNlbGVjdG9yVHlwZTogJ3NlbGVjdG9yIHNob3VsZCBiZSBhIGZ1bmN0aW9uJyxcbiAgY2hhbmdlVHlwZTogJ3Byb3ZpZGVkIHZhbHVlIG9mIGNoYW5nZXMgc2hvdWxkIGJlIGFuIG9iamVjdCcsXG4gIGNoYW5nZUZpZWxkOiAnaXQgc2VhbXMgeW91IHdhbnQgdG8gY2hhbmdlIGEgZmllbGQgaW4gdGhlIHN0YXRlIHdoaWNoIGlzIG5vdCBzcGVjaWZpZWQgaW4gdGhlIFwiaW5pdGlhbFwiIHN0YXRlJyxcbiAgXCJkZWZhdWx0XCI6ICdhbiB1bmtub3duIGVycm9yIGFjY3VyZWQgaW4gYHN0YXRlLWxvY2FsYCBwYWNrYWdlJ1xufTtcbnZhciBlcnJvckhhbmRsZXIgPSBjdXJyeSh0aHJvd0Vycm9yKShlcnJvck1lc3NhZ2VzKTtcbnZhciB2YWxpZGF0b3JzID0ge1xuICBjaGFuZ2VzOiB2YWxpZGF0ZUNoYW5nZXMsXG4gIHNlbGVjdG9yOiB2YWxpZGF0ZVNlbGVjdG9yLFxuICBoYW5kbGVyOiB2YWxpZGF0ZUhhbmRsZXIsXG4gIGluaXRpYWw6IHZhbGlkYXRlSW5pdGlhbFxufTtcblxuZnVuY3Rpb24gY3JlYXRlKGluaXRpYWwpIHtcbiAgdmFyIGhhbmRsZXIgPSBhcmd1bWVudHMubGVuZ3RoID4gMSAmJiBhcmd1bWVudHNbMV0gIT09IHVuZGVmaW5lZCA/IGFyZ3VtZW50c1sxXSA6IHt9O1xuICB2YWxpZGF0b3JzLmluaXRpYWwoaW5pdGlhbCk7XG4gIHZhbGlkYXRvcnMuaGFuZGxlcihoYW5kbGVyKTtcbiAgdmFyIHN0YXRlID0ge1xuICAgIGN1cnJlbnQ6IGluaXRpYWxcbiAgfTtcbiAgdmFyIGRpZFVwZGF0ZSA9IGN1cnJ5KGRpZFN0YXRlVXBkYXRlKShzdGF0ZSwgaGFuZGxlcik7XG4gIHZhciB1cGRhdGUgPSBjdXJyeSh1cGRhdGVTdGF0ZSkoc3RhdGUpO1xuICB2YXIgdmFsaWRhdGUgPSBjdXJyeSh2YWxpZGF0b3JzLmNoYW5nZXMpKGluaXRpYWwpO1xuICB2YXIgZ2V0Q2hhbmdlcyA9IGN1cnJ5KGV4dHJhY3RDaGFuZ2VzKShzdGF0ZSk7XG5cbiAgZnVuY3Rpb24gZ2V0U3RhdGUoKSB7XG4gICAgdmFyIHNlbGVjdG9yID0gYXJndW1lbnRzLmxlbmd0aCA+IDAgJiYgYXJndW1lbnRzWzBdICE9PSB1bmRlZmluZWQgPyBhcmd1bWVudHNbMF0gOiBmdW5jdGlvbiAoc3RhdGUpIHtcbiAgICAgIHJldHVybiBzdGF0ZTtcbiAgICB9O1xuICAgIHZhbGlkYXRvcnMuc2VsZWN0b3Ioc2VsZWN0b3IpO1xuICAgIHJldHVybiBzZWxlY3RvcihzdGF0ZS5jdXJyZW50KTtcbiAgfVxuXG4gIGZ1bmN0aW9uIHNldFN0YXRlKGNhdXNlZENoYW5nZXMpIHtcbiAgICBjb21wb3NlKGRpZFVwZGF0ZSwgdXBkYXRlLCB2YWxpZGF0ZSwgZ2V0Q2hhbmdlcykoY2F1c2VkQ2hhbmdlcyk7XG4gIH1cblxuICByZXR1cm4gW2dldFN0YXRlLCBzZXRTdGF0ZV07XG59XG5cbmZ1bmN0aW9uIGV4dHJhY3RDaGFuZ2VzKHN0YXRlLCBjYXVzZWRDaGFuZ2VzKSB7XG4gIHJldHVybiBpc0Z1bmN0aW9uKGNhdXNlZENoYW5nZXMpID8gY2F1c2VkQ2hhbmdlcyhzdGF0ZS5jdXJyZW50KSA6IGNhdXNlZENoYW5nZXM7XG59XG5cbmZ1bmN0aW9uIHVwZGF0ZVN0YXRlKHN0YXRlLCBjaGFuZ2VzKSB7XG4gIHN0YXRlLmN1cnJlbnQgPSBfb2JqZWN0U3ByZWFkMihfb2JqZWN0U3ByZWFkMih7fSwgc3RhdGUuY3VycmVudCksIGNoYW5nZXMpO1xuICByZXR1cm4gY2hhbmdlcztcbn1cblxuZnVuY3Rpb24gZGlkU3RhdGVVcGRhdGUoc3RhdGUsIGhhbmRsZXIsIGNoYW5nZXMpIHtcbiAgaXNGdW5jdGlvbihoYW5kbGVyKSA/IGhhbmRsZXIoc3RhdGUuY3VycmVudCkgOiBPYmplY3Qua2V5cyhjaGFuZ2VzKS5mb3JFYWNoKGZ1bmN0aW9uIChmaWVsZCkge1xuICAgIHZhciBfaGFuZGxlciRmaWVsZDtcblxuICAgIHJldHVybiAoX2hhbmRsZXIkZmllbGQgPSBoYW5kbGVyW2ZpZWxkXSkgPT09IG51bGwgfHwgX2hhbmRsZXIkZmllbGQgPT09IHZvaWQgMCA/IHZvaWQgMCA6IF9oYW5kbGVyJGZpZWxkLmNhbGwoaGFuZGxlciwgc3RhdGUuY3VycmVudFtmaWVsZF0pO1xuICB9KTtcbiAgcmV0dXJuIGNoYW5nZXM7XG59XG5cbnZhciBpbmRleCA9IHtcbiAgY3JlYXRlOiBjcmVhdGVcbn07XG5cbmV4cG9ydCBkZWZhdWx0IGluZGV4O1xuIl0sInNvdXJjZVJvb3QiOiIifQ==