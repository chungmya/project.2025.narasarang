(typeof self !== "object" ? self : this["webpackJsonp_N_E"] = typeof self !== "object" ? self : this["webpackJsonp_N_E"] || []).push([[2],{

/***/ "./node_modules/json_typegen_wasm/json_typegen_wasm.js":
/*!*************************************************************!*\
  !*** ./node_modules/json_typegen_wasm/json_typegen_wasm.js ***!
  \*************************************************************/
/*! exports provided: run */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _json_typegen_wasm_bg_wasm__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./json_typegen_wasm_bg.wasm */ "./node_modules/json_typegen_wasm/json_typegen_wasm_bg.wasm");
/* harmony import */ var _json_typegen_wasm_bg_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./json_typegen_wasm_bg.js */ "./node_modules/json_typegen_wasm/json_typegen_wasm_bg.js");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "run", function() { return _json_typegen_wasm_bg_js__WEBPACK_IMPORTED_MODULE_1__["run"]; });




/***/ }),

/***/ "./node_modules/json_typegen_wasm/json_typegen_wasm_bg.js":
/*!****************************************************************!*\
  !*** ./node_modules/json_typegen_wasm/json_typegen_wasm_bg.js ***!
  \****************************************************************/
/*! exports provided: run */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* WEBPACK VAR INJECTION */(function(module) {/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "run", function() { return run; });
/* harmony import */ var _json_typegen_wasm_bg_wasm__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./json_typegen_wasm_bg.wasm */ "./node_modules/json_typegen_wasm/json_typegen_wasm_bg.wasm");


let WASM_VECTOR_LEN = 0;

let cachegetUint8Memory0 = null;
function getUint8Memory0() {
    if (cachegetUint8Memory0 === null || cachegetUint8Memory0.buffer !== _json_typegen_wasm_bg_wasm__WEBPACK_IMPORTED_MODULE_0__["memory"].buffer) {
        cachegetUint8Memory0 = new Uint8Array(_json_typegen_wasm_bg_wasm__WEBPACK_IMPORTED_MODULE_0__["memory"].buffer);
    }
    return cachegetUint8Memory0;
}

const lTextEncoder = typeof TextEncoder === 'undefined' ? (0, module.require)('util').TextEncoder : TextEncoder;

let cachedTextEncoder = new lTextEncoder('utf-8');

if ( true && !window.TextEncoder) {
        const encoding = __webpack_require__(/*! text-encoding-utf-8 */ "./node_modules/text-encoding-utf-8/lib/encoding.lib.mjs");
        window.TextEncoder = encoding.TextEncoder;
        window.TextDecoder = encoding.TextDecoder;
    }

const encodeString = (typeof cachedTextEncoder.encodeInto === 'function'
    ? function (arg, view) {
    return cachedTextEncoder.encodeInto(arg, view);
}
    : function (arg, view) {
    const buf = cachedTextEncoder.encode(arg);
    view.set(buf);
    return {
        read: arg.length,
        written: buf.length
    };
});

function passStringToWasm0(arg, malloc, realloc) {

    if (realloc === undefined) {
        const buf = cachedTextEncoder.encode(arg);
        const ptr = malloc(buf.length);
        getUint8Memory0().subarray(ptr, ptr + buf.length).set(buf);
        WASM_VECTOR_LEN = buf.length;
        return ptr;
    }

    let len = arg.length;
    let ptr = malloc(len);

    const mem = getUint8Memory0();

    let offset = 0;

    for (; offset < len; offset++) {
        const code = arg.charCodeAt(offset);
        if (code > 0x7F) break;
        mem[ptr + offset] = code;
    }

    if (offset !== len) {
        if (offset !== 0) {
            arg = arg.slice(offset);
        }
        ptr = realloc(ptr, len, len = offset + arg.length * 3);
        const view = getUint8Memory0().subarray(ptr + offset, ptr + len);
        const ret = encodeString(arg, view);

        offset += ret.written;
    }

    WASM_VECTOR_LEN = offset;
    return ptr;
}

let cachegetInt32Memory0 = null;
function getInt32Memory0() {
    if (cachegetInt32Memory0 === null || cachegetInt32Memory0.buffer !== _json_typegen_wasm_bg_wasm__WEBPACK_IMPORTED_MODULE_0__["memory"].buffer) {
        cachegetInt32Memory0 = new Int32Array(_json_typegen_wasm_bg_wasm__WEBPACK_IMPORTED_MODULE_0__["memory"].buffer);
    }
    return cachegetInt32Memory0;
}

const lTextDecoder = typeof TextDecoder === 'undefined' ? (0, module.require)('util').TextDecoder : TextDecoder;

let cachedTextDecoder = new lTextDecoder('utf-8', { ignoreBOM: true, fatal: true });

cachedTextDecoder.decode();

function getStringFromWasm0(ptr, len) {
    return cachedTextDecoder.decode(getUint8Memory0().subarray(ptr, ptr + len));
}
/**
* @param {string} name
* @param {string} input
* @param {string} options
* @returns {string}
*/
function run(name, input, options) {
    try {
        const retptr = _json_typegen_wasm_bg_wasm__WEBPACK_IMPORTED_MODULE_0__["__wbindgen_add_to_stack_pointer"](-16);
        var ptr0 = passStringToWasm0(name, _json_typegen_wasm_bg_wasm__WEBPACK_IMPORTED_MODULE_0__["__wbindgen_malloc"], _json_typegen_wasm_bg_wasm__WEBPACK_IMPORTED_MODULE_0__["__wbindgen_realloc"]);
        var len0 = WASM_VECTOR_LEN;
        var ptr1 = passStringToWasm0(input, _json_typegen_wasm_bg_wasm__WEBPACK_IMPORTED_MODULE_0__["__wbindgen_malloc"], _json_typegen_wasm_bg_wasm__WEBPACK_IMPORTED_MODULE_0__["__wbindgen_realloc"]);
        var len1 = WASM_VECTOR_LEN;
        var ptr2 = passStringToWasm0(options, _json_typegen_wasm_bg_wasm__WEBPACK_IMPORTED_MODULE_0__["__wbindgen_malloc"], _json_typegen_wasm_bg_wasm__WEBPACK_IMPORTED_MODULE_0__["__wbindgen_realloc"]);
        var len2 = WASM_VECTOR_LEN;
        _json_typegen_wasm_bg_wasm__WEBPACK_IMPORTED_MODULE_0__["run"](retptr, ptr0, len0, ptr1, len1, ptr2, len2);
        var r0 = getInt32Memory0()[retptr / 4 + 0];
        var r1 = getInt32Memory0()[retptr / 4 + 1];
        return getStringFromWasm0(r0, r1);
    } finally {
        _json_typegen_wasm_bg_wasm__WEBPACK_IMPORTED_MODULE_0__["__wbindgen_add_to_stack_pointer"](16);
        _json_typegen_wasm_bg_wasm__WEBPACK_IMPORTED_MODULE_0__["__wbindgen_free"](r0, r1);
    }
}


/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(/*! ./../next/dist/compiled/webpack/harmony-module.js */ "./node_modules/next/dist/compiled/webpack/harmony-module.js")(module)))

/***/ }),

/***/ "./node_modules/json_typegen_wasm/json_typegen_wasm_bg.wasm":
/*!******************************************************************!*\
  !*** ./node_modules/json_typegen_wasm/json_typegen_wasm_bg.wasm ***!
  \******************************************************************/
/*! exports provided: memory, run, __wbindgen_add_to_stack_pointer, __wbindgen_malloc, __wbindgen_realloc, __wbindgen_free */
/***/ (function(module, exports, __webpack_require__) {

"use strict";
// Instantiate WebAssembly module
var wasmExports = __webpack_require__.w[module.i];
__webpack_require__.r(exports);
// export exports from WebAssembly module
for(var name in wasmExports) if(name != "__webpack_init__") exports[name] = wasmExports[name];
// exec imports from WebAssembly module (for esm order)


// exec wasm module
wasmExports["__webpack_init__"]()

/***/ }),

/***/ "./node_modules/text-encoding-utf-8/lib/encoding.lib.mjs":
/*!***************************************************************!*\
  !*** ./node_modules/text-encoding-utf-8/lib/encoding.lib.mjs ***!
  \***************************************************************/
/*! exports provided: TextEncoder, TextDecoder */
/***/ (function(__webpack_module__, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "TextEncoder", function() { return TextEncoder; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "TextDecoder", function() { return TextDecoder; });


// This is free and unencumbered software released into the public domain.
// See LICENSE.md for more information.

//
// Utilities
//

/**
 * @param {number} a The number to test.
 * @param {number} min The minimum value in the range, inclusive.
 * @param {number} max The maximum value in the range, inclusive.
 * @return {boolean} True if a >= min and a <= max.
 */
function inRange(a, min, max) {
  return min <= a && a <= max;
}

/**
 * @param {*} o
 * @return {Object}
 */
function ToDictionary(o) {
  if (o === undefined) return {};
  if (o === Object(o)) return o;
  throw TypeError('Could not convert argument to dictionary');
}

/**
 * @param {string} string Input string of UTF-16 code units.
 * @return {!Array.<number>} Code points.
 */
function stringToCodePoints(string) {
  // https://heycam.github.io/webidl/#dfn-obtain-unicode

  // 1. Let S be the DOMString value.
  var s = String(string);

  // 2. Let n be the length of S.
  var n = s.length;

  // 3. Initialize i to 0.
  var i = 0;

  // 4. Initialize U to be an empty sequence of Unicode characters.
  var u = [];

  // 5. While i < n:
  while (i < n) {

    // 1. Let c be the code unit in S at index i.
    var c = s.charCodeAt(i);

    // 2. Depending on the value of c:

    // c < 0xD800 or c > 0xDFFF
    if (c < 0xD800 || c > 0xDFFF) {
      // Append to U the Unicode character with code point c.
      u.push(c);
    }

    // 0xDC00 ≤ c ≤ 0xDFFF
    else if (0xDC00 <= c && c <= 0xDFFF) {
      // Append to U a U+FFFD REPLACEMENT CHARACTER.
      u.push(0xFFFD);
    }

    // 0xD800 ≤ c ≤ 0xDBFF
    else if (0xD800 <= c && c <= 0xDBFF) {
      // 1. If i = n−1, then append to U a U+FFFD REPLACEMENT
      // CHARACTER.
      if (i === n - 1) {
        u.push(0xFFFD);
      }
      // 2. Otherwise, i < n−1:
      else {
        // 1. Let d be the code unit in S at index i+1.
        var d = string.charCodeAt(i + 1);

        // 2. If 0xDC00 ≤ d ≤ 0xDFFF, then:
        if (0xDC00 <= d && d <= 0xDFFF) {
          // 1. Let a be c & 0x3FF.
          var a = c & 0x3FF;

          // 2. Let b be d & 0x3FF.
          var b = d & 0x3FF;

          // 3. Append to U the Unicode character with code point
          // 2^16+2^10*a+b.
          u.push(0x10000 + (a << 10) + b);

          // 4. Set i to i+1.
          i += 1;
        }

        // 3. Otherwise, d < 0xDC00 or d > 0xDFFF. Append to U a
        // U+FFFD REPLACEMENT CHARACTER.
        else  {
          u.push(0xFFFD);
        }
      }
    }

    // 3. Set i to i+1.
    i += 1;
  }

  // 6. Return U.
  return u;
}

/**
 * @param {!Array.<number>} code_points Array of code points.
 * @return {string} string String of UTF-16 code units.
 */
function codePointsToString(code_points) {
  var s = '';
  for (var i = 0; i < code_points.length; ++i) {
    var cp = code_points[i];
    if (cp <= 0xFFFF) {
      s += String.fromCharCode(cp);
    } else {
      cp -= 0x10000;
      s += String.fromCharCode((cp >> 10) + 0xD800,
                               (cp & 0x3FF) + 0xDC00);
    }
  }
  return s;
}


//
// Implementation of Encoding specification
// https://encoding.spec.whatwg.org/
//

//
// 3. Terminology
//

/**
 * End-of-stream is a special token that signifies no more tokens
 * are in the stream.
 * @const
 */ var end_of_stream = -1;

/**
 * A stream represents an ordered sequence of tokens.
 *
 * @constructor
 * @param {!(Array.<number>|Uint8Array)} tokens Array of tokens that provide the
 * stream.
 */
function Stream(tokens) {
  /** @type {!Array.<number>} */
  this.tokens = [].slice.call(tokens);
}

Stream.prototype = {
  /**
   * @return {boolean} True if end-of-stream has been hit.
   */
  endOfStream: function() {
    return !this.tokens.length;
  },

  /**
   * When a token is read from a stream, the first token in the
   * stream must be returned and subsequently removed, and
   * end-of-stream must be returned otherwise.
   *
   * @return {number} Get the next token from the stream, or
   * end_of_stream.
   */
   read: function() {
    if (!this.tokens.length)
      return end_of_stream;
     return this.tokens.shift();
   },

  /**
   * When one or more tokens are prepended to a stream, those tokens
   * must be inserted, in given order, before the first token in the
   * stream.
   *
   * @param {(number|!Array.<number>)} token The token(s) to prepend to the stream.
   */
  prepend: function(token) {
    if (Array.isArray(token)) {
      var tokens = /**@type {!Array.<number>}*/(token);
      while (tokens.length)
        this.tokens.unshift(tokens.pop());
    } else {
      this.tokens.unshift(token);
    }
  },

  /**
   * When one or more tokens are pushed to a stream, those tokens
   * must be inserted, in given order, after the last token in the
   * stream.
   *
   * @param {(number|!Array.<number>)} token The tokens(s) to prepend to the stream.
   */
  push: function(token) {
    if (Array.isArray(token)) {
      var tokens = /**@type {!Array.<number>}*/(token);
      while (tokens.length)
        this.tokens.push(tokens.shift());
    } else {
      this.tokens.push(token);
    }
  }
};

//
// 4. Encodings
//

// 4.1 Encoders and decoders

/** @const */
var finished = -1;

/**
 * @param {boolean} fatal If true, decoding errors raise an exception.
 * @param {number=} opt_code_point Override the standard fallback code point.
 * @return {number} The code point to insert on a decoding error.
 */
function decoderError(fatal, opt_code_point) {
  if (fatal)
    throw TypeError('Decoder error');
  return opt_code_point || 0xFFFD;
}

/** @interface */
function Decoder() {}
Decoder.prototype = {
  /**
   * @param {Stream} stream The stream of bytes being decoded.
   * @param {number} bite The next byte read from the stream.
   * @return {?(number|!Array.<number>)} The next code point(s)
   *     decoded, or null if not enough data exists in the input
   *     stream to decode a complete code point, or |finished|.
   */
  handler: function(stream, bite) {}
};

/** @interface */
function Encoder() {}
Encoder.prototype = {
  /**
   * @param {Stream} stream The stream of code points being encoded.
   * @param {number} code_point Next code point read from the stream.
   * @return {(number|!Array.<number>)} Byte(s) to emit, or |finished|.
   */
  handler: function(stream, code_point) {}
};

//
// 7. API
//

/** @const */ var DEFAULT_ENCODING = 'utf-8';

// 7.1 Interface TextDecoder

/**
 * @constructor
 * @param {string=} encoding The label of the encoding;
 *     defaults to 'utf-8'.
 * @param {Object=} options
 */
function TextDecoder(encoding, options) {
  if (!(this instanceof TextDecoder)) {
    return new TextDecoder(encoding, options);
  }
  encoding = encoding !== undefined ? String(encoding).toLowerCase() : DEFAULT_ENCODING;
  if (encoding !== DEFAULT_ENCODING) {
    throw new Error('Encoding not supported. Only utf-8 is supported');
  }
  options = ToDictionary(options);

  /** @private @type {boolean} */
  this._streaming = false;
  /** @private @type {boolean} */
  this._BOMseen = false;
  /** @private @type {?Decoder} */
  this._decoder = null;
  /** @private @type {boolean} */
  this._fatal = Boolean(options['fatal']);
  /** @private @type {boolean} */
  this._ignoreBOM = Boolean(options['ignoreBOM']);

  Object.defineProperty(this, 'encoding', {value: 'utf-8'});
  Object.defineProperty(this, 'fatal', {value: this._fatal});
  Object.defineProperty(this, 'ignoreBOM', {value: this._ignoreBOM});
}

TextDecoder.prototype = {
  /**
   * @param {ArrayBufferView=} input The buffer of bytes to decode.
   * @param {Object=} options
   * @return {string} The decoded string.
   */
  decode: function decode(input, options) {
    var bytes;
    if (typeof input === 'object' && input instanceof ArrayBuffer) {
      bytes = new Uint8Array(input);
    } else if (typeof input === 'object' && 'buffer' in input &&
               input.buffer instanceof ArrayBuffer) {
      bytes = new Uint8Array(input.buffer,
                             input.byteOffset,
                             input.byteLength);
    } else {
      bytes = new Uint8Array(0);
    }

    options = ToDictionary(options);

    if (!this._streaming) {
      this._decoder = new UTF8Decoder({fatal: this._fatal});
      this._BOMseen = false;
    }
    this._streaming = Boolean(options['stream']);

    var input_stream = new Stream(bytes);

    var code_points = [];

    /** @type {?(number|!Array.<number>)} */
    var result;

    while (!input_stream.endOfStream()) {
      result = this._decoder.handler(input_stream, input_stream.read());
      if (result === finished)
        break;
      if (result === null)
        continue;
      if (Array.isArray(result))
        code_points.push.apply(code_points, /**@type {!Array.<number>}*/(result));
      else
        code_points.push(result);
    }
    if (!this._streaming) {
      do {
        result = this._decoder.handler(input_stream, input_stream.read());
        if (result === finished)
          break;
        if (result === null)
          continue;
        if (Array.isArray(result))
          code_points.push.apply(code_points, /**@type {!Array.<number>}*/(result));
        else
          code_points.push(result);
      } while (!input_stream.endOfStream());
      this._decoder = null;
    }

    if (code_points.length) {
      // If encoding is one of utf-8, utf-16be, and utf-16le, and
      // ignore BOM flag and BOM seen flag are unset, run these
      // subsubsteps:
      if (['utf-8'].indexOf(this.encoding) !== -1 &&
          !this._ignoreBOM && !this._BOMseen) {
        // If token is U+FEFF, set BOM seen flag.
        if (code_points[0] === 0xFEFF) {
          this._BOMseen = true;
          code_points.shift();
        } else {
          // Otherwise, if token is not end-of-stream, set BOM seen
          // flag and append token to output.
          this._BOMseen = true;
        }
      }
    }

    return codePointsToString(code_points);
  }
};

// 7.2 Interface TextEncoder

/**
 * @constructor
 * @param {string=} encoding The label of the encoding;
 *     defaults to 'utf-8'.
 * @param {Object=} options
 */
function TextEncoder(encoding, options) {
  if (!(this instanceof TextEncoder))
    return new TextEncoder(encoding, options);
  encoding = encoding !== undefined ? String(encoding).toLowerCase() : DEFAULT_ENCODING;
  if (encoding !== DEFAULT_ENCODING) {
    throw new Error('Encoding not supported. Only utf-8 is supported');
  }
  options = ToDictionary(options);

  /** @private @type {boolean} */
  this._streaming = false;
  /** @private @type {?Encoder} */
  this._encoder = null;
  /** @private @type {{fatal: boolean}} */
  this._options = {fatal: Boolean(options['fatal'])};

  Object.defineProperty(this, 'encoding', {value: 'utf-8'});
}

TextEncoder.prototype = {
  /**
   * @param {string=} opt_string The string to encode.
   * @param {Object=} options
   * @return {Uint8Array} Encoded bytes, as a Uint8Array.
   */
  encode: function encode(opt_string, options) {
    opt_string = opt_string ? String(opt_string) : '';
    options = ToDictionary(options);

    // NOTE: This option is nonstandard. None of the encodings
    // permitted for encoding (i.e. UTF-8, UTF-16) are stateful,
    // so streaming is not necessary.
    if (!this._streaming)
      this._encoder = new UTF8Encoder(this._options);
    this._streaming = Boolean(options['stream']);

    var bytes = [];
    var input_stream = new Stream(stringToCodePoints(opt_string));
    /** @type {?(number|!Array.<number>)} */
    var result;
    while (!input_stream.endOfStream()) {
      result = this._encoder.handler(input_stream, input_stream.read());
      if (result === finished)
        break;
      if (Array.isArray(result))
        bytes.push.apply(bytes, /**@type {!Array.<number>}*/(result));
      else
        bytes.push(result);
    }
    if (!this._streaming) {
      while (true) {
        result = this._encoder.handler(input_stream, input_stream.read());
        if (result === finished)
          break;
        if (Array.isArray(result))
          bytes.push.apply(bytes, /**@type {!Array.<number>}*/(result));
        else
          bytes.push(result);
      }
      this._encoder = null;
    }
    return new Uint8Array(bytes);
  }
};

//
// 8. The encoding
//

// 8.1 utf-8

/**
 * @constructor
 * @implements {Decoder}
 * @param {{fatal: boolean}} options
 */
function UTF8Decoder(options) {
  var fatal = options.fatal;

  // utf-8's decoder's has an associated utf-8 code point, utf-8
  // bytes seen, and utf-8 bytes needed (all initially 0), a utf-8
  // lower boundary (initially 0x80), and a utf-8 upper boundary
  // (initially 0xBF).
  var /** @type {number} */ utf8_code_point = 0,
      /** @type {number} */ utf8_bytes_seen = 0,
      /** @type {number} */ utf8_bytes_needed = 0,
      /** @type {number} */ utf8_lower_boundary = 0x80,
      /** @type {number} */ utf8_upper_boundary = 0xBF;

  /**
   * @param {Stream} stream The stream of bytes being decoded.
   * @param {number} bite The next byte read from the stream.
   * @return {?(number|!Array.<number>)} The next code point(s)
   *     decoded, or null if not enough data exists in the input
   *     stream to decode a complete code point.
   */
  this.handler = function(stream, bite) {
    // 1. If byte is end-of-stream and utf-8 bytes needed is not 0,
    // set utf-8 bytes needed to 0 and return error.
    if (bite === end_of_stream && utf8_bytes_needed !== 0) {
      utf8_bytes_needed = 0;
      return decoderError(fatal);
    }

    // 2. If byte is end-of-stream, return finished.
    if (bite === end_of_stream)
      return finished;

    // 3. If utf-8 bytes needed is 0, based on byte:
    if (utf8_bytes_needed === 0) {

      // 0x00 to 0x7F
      if (inRange(bite, 0x00, 0x7F)) {
        // Return a code point whose value is byte.
        return bite;
      }

      // 0xC2 to 0xDF
      if (inRange(bite, 0xC2, 0xDF)) {
        // Set utf-8 bytes needed to 1 and utf-8 code point to byte
        // − 0xC0.
        utf8_bytes_needed = 1;
        utf8_code_point = bite - 0xC0;
      }

      // 0xE0 to 0xEF
      else if (inRange(bite, 0xE0, 0xEF)) {
        // 1. If byte is 0xE0, set utf-8 lower boundary to 0xA0.
        if (bite === 0xE0)
          utf8_lower_boundary = 0xA0;
        // 2. If byte is 0xED, set utf-8 upper boundary to 0x9F.
        if (bite === 0xED)
          utf8_upper_boundary = 0x9F;
        // 3. Set utf-8 bytes needed to 2 and utf-8 code point to
        // byte − 0xE0.
        utf8_bytes_needed = 2;
        utf8_code_point = bite - 0xE0;
      }

      // 0xF0 to 0xF4
      else if (inRange(bite, 0xF0, 0xF4)) {
        // 1. If byte is 0xF0, set utf-8 lower boundary to 0x90.
        if (bite === 0xF0)
          utf8_lower_boundary = 0x90;
        // 2. If byte is 0xF4, set utf-8 upper boundary to 0x8F.
        if (bite === 0xF4)
          utf8_upper_boundary = 0x8F;
        // 3. Set utf-8 bytes needed to 3 and utf-8 code point to
        // byte − 0xF0.
        utf8_bytes_needed = 3;
        utf8_code_point = bite - 0xF0;
      }

      // Otherwise
      else {
        // Return error.
        return decoderError(fatal);
      }

      // Then (byte is in the range 0xC2 to 0xF4) set utf-8 code
      // point to utf-8 code point << (6 × utf-8 bytes needed) and
      // return continue.
      utf8_code_point = utf8_code_point << (6 * utf8_bytes_needed);
      return null;
    }

    // 4. If byte is not in the range utf-8 lower boundary to utf-8
    // upper boundary, run these substeps:
    if (!inRange(bite, utf8_lower_boundary, utf8_upper_boundary)) {

      // 1. Set utf-8 code point, utf-8 bytes needed, and utf-8
      // bytes seen to 0, set utf-8 lower boundary to 0x80, and set
      // utf-8 upper boundary to 0xBF.
      utf8_code_point = utf8_bytes_needed = utf8_bytes_seen = 0;
      utf8_lower_boundary = 0x80;
      utf8_upper_boundary = 0xBF;

      // 2. Prepend byte to stream.
      stream.prepend(bite);

      // 3. Return error.
      return decoderError(fatal);
    }

    // 5. Set utf-8 lower boundary to 0x80 and utf-8 upper boundary
    // to 0xBF.
    utf8_lower_boundary = 0x80;
    utf8_upper_boundary = 0xBF;

    // 6. Increase utf-8 bytes seen by one and set utf-8 code point
    // to utf-8 code point + (byte − 0x80) << (6 × (utf-8 bytes
    // needed − utf-8 bytes seen)).
    utf8_bytes_seen += 1;
    utf8_code_point += (bite - 0x80) << (6 * (utf8_bytes_needed - utf8_bytes_seen));

    // 7. If utf-8 bytes seen is not equal to utf-8 bytes needed,
    // continue.
    if (utf8_bytes_seen !== utf8_bytes_needed)
      return null;

    // 8. Let code point be utf-8 code point.
    var code_point = utf8_code_point;

    // 9. Set utf-8 code point, utf-8 bytes needed, and utf-8 bytes
    // seen to 0.
    utf8_code_point = utf8_bytes_needed = utf8_bytes_seen = 0;

    // 10. Return a code point whose value is code point.
    return code_point;
  };
}

/**
 * @constructor
 * @implements {Encoder}
 * @param {{fatal: boolean}} options
 */
function UTF8Encoder(options) {
  var fatal = options.fatal;
  /**
   * @param {Stream} stream Input stream.
   * @param {number} code_point Next code point read from the stream.
   * @return {(number|!Array.<number>)} Byte(s) to emit.
   */
  this.handler = function(stream, code_point) {
    // 1. If code point is end-of-stream, return finished.
    if (code_point === end_of_stream)
      return finished;

    // 2. If code point is in the range U+0000 to U+007F, return a
    // byte whose value is code point.
    if (inRange(code_point, 0x0000, 0x007f))
      return code_point;

    // 3. Set count and offset based on the range code point is in:
    var count, offset;
    // U+0080 to U+07FF:    1 and 0xC0
    if (inRange(code_point, 0x0080, 0x07FF)) {
      count = 1;
      offset = 0xC0;
    }
    // U+0800 to U+FFFF:    2 and 0xE0
    else if (inRange(code_point, 0x0800, 0xFFFF)) {
      count = 2;
      offset = 0xE0;
    }
    // U+10000 to U+10FFFF: 3 and 0xF0
    else if (inRange(code_point, 0x10000, 0x10FFFF)) {
      count = 3;
      offset = 0xF0;
    }

    // 4.Let bytes be a byte sequence whose first byte is (code
    // point >> (6 × count)) + offset.
    var bytes = [(code_point >> (6 * count)) + offset];

    // 5. Run these substeps while count is greater than 0:
    while (count > 0) {

      // 1. Set temp to code point >> (6 × (count − 1)).
      var temp = code_point >> (6 * (count - 1));

      // 2. Append to bytes 0x80 | (temp & 0x3F).
      bytes.push(0x80 | (temp & 0x3F));

      // 3. Decrease count by one.
      count -= 1;
    }

    // 6. Return bytes bytes, in order.
    return bytes;
  };
}




/***/ })

}]);
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9fTl9FLy4vbm9kZV9tb2R1bGVzL2pzb25fdHlwZWdlbl93YXNtL2pzb25fdHlwZWdlbl93YXNtLmpzIiwid2VicGFjazovL19OX0UvLi9ub2RlX21vZHVsZXMvanNvbl90eXBlZ2VuX3dhc20vanNvbl90eXBlZ2VuX3dhc21fYmcuanMiLCJ3ZWJwYWNrOi8vX05fRS8uL25vZGVfbW9kdWxlcy90ZXh0LWVuY29kaW5nLXV0Zi04L2xpYi9lbmNvZGluZy5saWIubWpzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQW9EOzs7Ozs7Ozs7Ozs7O0FDQXBEO0FBQUE7QUFBQTtBQUFvRDs7QUFFcEQ7O0FBRUE7QUFDQTtBQUNBLHlFQUF5RSxpRUFBVztBQUNwRiw4Q0FBOEMsaUVBQVc7QUFDekQ7QUFDQTtBQUNBOztBQUVBOztBQUVBOztBQUVBLElBQUksS0FBVTtBQUNkLHlCQUF5QixtQkFBTyxDQUFDLG9GQUFxQjtBQUN0RDtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLENBQUM7O0FBRUQ7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTs7QUFFQTs7QUFFQTs7QUFFQSxVQUFVLGNBQWM7QUFDeEI7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBLHlFQUF5RSxpRUFBVztBQUNwRiw4Q0FBOEMsaUVBQVc7QUFDekQ7QUFDQTtBQUNBOztBQUVBOztBQUVBLG1EQUFtRCwrQkFBK0I7O0FBRWxGOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsVUFBVSxPQUFPO0FBQ2pCLFVBQVUsT0FBTztBQUNqQixVQUFVLE9BQU87QUFDakIsWUFBWTtBQUNaO0FBQ087QUFDUDtBQUNBLHVCQUF1QiwwRkFBb0M7QUFDM0QsMkNBQTJDLDRFQUFzQixFQUFFLDZFQUF1QjtBQUMxRjtBQUNBLDRDQUE0Qyw0RUFBc0IsRUFBRSw2RUFBdUI7QUFDM0Y7QUFDQSw4Q0FBOEMsNEVBQXNCLEVBQUUsNkVBQXVCO0FBQzdGO0FBQ0EsUUFBUSw4REFBUTtBQUNoQjtBQUNBO0FBQ0E7QUFDQSxLQUFLO0FBQ0wsUUFBUSwwRkFBb0M7QUFDNUMsUUFBUSwwRUFBb0I7QUFDNUI7QUFDQTs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDakhBO0FBQUE7QUFBQTtBQUFhOztBQUViO0FBQ0E7O0FBRUE7QUFDQTtBQUNBOztBQUVBO0FBQ0EsV0FBVyxPQUFPO0FBQ2xCLFdBQVcsT0FBTztBQUNsQixXQUFXLE9BQU87QUFDbEIsWUFBWSxRQUFRO0FBQ3BCO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0EsV0FBVyxFQUFFO0FBQ2IsWUFBWTtBQUNaO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBLFdBQVcsT0FBTztBQUNsQixZQUFZLGdCQUFnQjtBQUM1QjtBQUNBO0FBQ0E7O0FBRUE7QUFDQTs7QUFFQTtBQUNBOztBQUVBO0FBQ0E7O0FBRUE7QUFDQTs7QUFFQTtBQUNBOztBQUVBO0FBQ0E7O0FBRUE7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQSxXQUFXLGdCQUFnQjtBQUMzQixZQUFZLE9BQU87QUFDbkI7QUFDQTtBQUNBO0FBQ0EsaUJBQWlCLHdCQUF3QjtBQUN6QztBQUNBO0FBQ0E7QUFDQSxLQUFLO0FBQ0w7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7OztBQUdBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsV0FBVyw2QkFBNkI7QUFDeEM7QUFDQTtBQUNBO0FBQ0EsYUFBYSxnQkFBZ0I7QUFDN0I7QUFDQTs7QUFFQTtBQUNBO0FBQ0EsY0FBYyxRQUFRO0FBQ3RCO0FBQ0E7QUFDQTtBQUNBLEdBQUc7O0FBRUg7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLGNBQWMsT0FBTztBQUNyQjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxJQUFJOztBQUVKO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxhQUFhLHlCQUF5QjtBQUN0QztBQUNBO0FBQ0E7QUFDQSw2QkFBNkIsZ0JBQWdCO0FBQzdDO0FBQ0E7QUFDQSxLQUFLO0FBQ0w7QUFDQTtBQUNBLEdBQUc7O0FBRUg7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLGFBQWEseUJBQXlCO0FBQ3RDO0FBQ0E7QUFDQTtBQUNBLDZCQUE2QixnQkFBZ0I7QUFDN0M7QUFDQTtBQUNBLEtBQUs7QUFDTDtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7O0FBRUE7O0FBRUE7QUFDQTs7QUFFQTtBQUNBLFdBQVcsUUFBUTtBQUNuQixXQUFXLFFBQVE7QUFDbkIsWUFBWSxPQUFPO0FBQ25CO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLGFBQWEsT0FBTztBQUNwQixhQUFhLE9BQU87QUFDcEIsY0FBYywwQkFBMEI7QUFDeEM7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLGFBQWEsT0FBTztBQUNwQixhQUFhLE9BQU87QUFDcEIsY0FBYyx5QkFBeUI7QUFDdkM7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTs7QUFFQTs7QUFFQTs7QUFFQTtBQUNBO0FBQ0EsV0FBVyxRQUFRO0FBQ25CO0FBQ0EsV0FBVyxRQUFRO0FBQ25CO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBLHNCQUFzQixRQUFRO0FBQzlCO0FBQ0Esc0JBQXNCLFFBQVE7QUFDOUI7QUFDQSxzQkFBc0IsU0FBUztBQUMvQjtBQUNBLHNCQUFzQixRQUFRO0FBQzlCO0FBQ0Esc0JBQXNCLFFBQVE7QUFDOUI7O0FBRUEsMkNBQTJDLGVBQWU7QUFDMUQsd0NBQXdDLG1CQUFtQjtBQUMzRCw0Q0FBNEMsdUJBQXVCO0FBQ25FOztBQUVBO0FBQ0E7QUFDQSxhQUFhLGlCQUFpQjtBQUM5QixhQUFhLFFBQVE7QUFDckIsY0FBYyxPQUFPO0FBQ3JCO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxLQUFLO0FBQ0w7QUFDQTtBQUNBO0FBQ0E7QUFDQSxLQUFLO0FBQ0w7QUFDQTs7QUFFQTs7QUFFQTtBQUNBLHVDQUF1QyxtQkFBbUI7QUFDMUQ7QUFDQTtBQUNBOztBQUVBOztBQUVBOztBQUVBLGVBQWUsMEJBQTBCO0FBQ3pDOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0Esc0RBQXNELGdCQUFnQjtBQUN0RTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0Esd0RBQXdELGdCQUFnQjtBQUN4RTtBQUNBO0FBQ0EsT0FBTztBQUNQO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxTQUFTO0FBQ1Q7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTs7QUFFQTs7QUFFQTtBQUNBO0FBQ0EsV0FBVyxRQUFRO0FBQ25CO0FBQ0EsV0FBVyxRQUFRO0FBQ25CO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQSxzQkFBc0IsUUFBUTtBQUM5QjtBQUNBLHNCQUFzQixTQUFTO0FBQy9CO0FBQ0EsdUJBQXVCLGdCQUFnQjtBQUN2QyxtQkFBbUI7O0FBRW5CLDJDQUEyQyxlQUFlO0FBQzFEOztBQUVBO0FBQ0E7QUFDQSxhQUFhLFFBQVE7QUFDckIsYUFBYSxRQUFRO0FBQ3JCLGNBQWMsV0FBVztBQUN6QjtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBLGVBQWUsMEJBQTBCO0FBQ3pDO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLDBDQUEwQyxnQkFBZ0I7QUFDMUQ7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsNENBQTRDLGdCQUFnQjtBQUM1RDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTs7QUFFQTs7QUFFQTtBQUNBO0FBQ0EsZ0JBQWdCO0FBQ2hCLFlBQVksZ0JBQWdCO0FBQzVCO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLGlCQUFpQixPQUFPO0FBQ3hCLGlCQUFpQixPQUFPO0FBQ3hCLGlCQUFpQixPQUFPO0FBQ3hCLGlCQUFpQixPQUFPO0FBQ3hCLGlCQUFpQixPQUFPOztBQUV4QjtBQUNBLGFBQWEsT0FBTztBQUNwQixhQUFhLE9BQU87QUFDcEIsY0FBYywwQkFBMEI7QUFDeEM7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBOztBQUVBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBLGdCQUFnQjtBQUNoQixZQUFZLGdCQUFnQjtBQUM1QjtBQUNBO0FBQ0E7QUFDQTtBQUNBLGFBQWEsT0FBTztBQUNwQixhQUFhLE9BQU87QUFDcEIsY0FBYyx5QkFBeUI7QUFDdkM7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBOztBQUVBO0FBQ0E7O0FBRUE7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7O0FBRWtDIiwiZmlsZSI6InN0YXRpYy9jaHVua3MvMi5qcyIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCAqIGFzIHdhc20gZnJvbSBcIi4vanNvbl90eXBlZ2VuX3dhc21fYmcud2FzbVwiO1xuZXhwb3J0ICogZnJvbSBcIi4vanNvbl90eXBlZ2VuX3dhc21fYmcuanNcIjsiLCJpbXBvcnQgKiBhcyB3YXNtIGZyb20gJy4vanNvbl90eXBlZ2VuX3dhc21fYmcud2FzbSc7XG5cbmxldCBXQVNNX1ZFQ1RPUl9MRU4gPSAwO1xuXG5sZXQgY2FjaGVnZXRVaW50OE1lbW9yeTAgPSBudWxsO1xuZnVuY3Rpb24gZ2V0VWludDhNZW1vcnkwKCkge1xuICAgIGlmIChjYWNoZWdldFVpbnQ4TWVtb3J5MCA9PT0gbnVsbCB8fCBjYWNoZWdldFVpbnQ4TWVtb3J5MC5idWZmZXIgIT09IHdhc20ubWVtb3J5LmJ1ZmZlcikge1xuICAgICAgICBjYWNoZWdldFVpbnQ4TWVtb3J5MCA9IG5ldyBVaW50OEFycmF5KHdhc20ubWVtb3J5LmJ1ZmZlcik7XG4gICAgfVxuICAgIHJldHVybiBjYWNoZWdldFVpbnQ4TWVtb3J5MDtcbn1cblxuY29uc3QgbFRleHRFbmNvZGVyID0gdHlwZW9mIFRleHRFbmNvZGVyID09PSAndW5kZWZpbmVkJyA/ICgwLCBtb2R1bGUucmVxdWlyZSkoJ3V0aWwnKS5UZXh0RW5jb2RlciA6IFRleHRFbmNvZGVyO1xuXG5sZXQgY2FjaGVkVGV4dEVuY29kZXIgPSBuZXcgbFRleHRFbmNvZGVyKCd1dGYtOCcpO1xuXG5pZiAoSU5fQlJPV1NFUiAmJiAhd2luZG93LlRleHRFbmNvZGVyKSB7XHJcbiAgICAgICAgY29uc3QgZW5jb2RpbmcgPSByZXF1aXJlKFwidGV4dC1lbmNvZGluZy11dGYtOFwiKTtcclxuICAgICAgICB3aW5kb3cuVGV4dEVuY29kZXIgPSBlbmNvZGluZy5UZXh0RW5jb2RlcjtcclxuICAgICAgICB3aW5kb3cuVGV4dERlY29kZXIgPSBlbmNvZGluZy5UZXh0RGVjb2RlcjtcclxuICAgIH1cclxuXHJcbmNvbnN0IGVuY29kZVN0cmluZyA9ICh0eXBlb2YgY2FjaGVkVGV4dEVuY29kZXIuZW5jb2RlSW50byA9PT0gJ2Z1bmN0aW9uJ1xuICAgID8gZnVuY3Rpb24gKGFyZywgdmlldykge1xuICAgIHJldHVybiBjYWNoZWRUZXh0RW5jb2Rlci5lbmNvZGVJbnRvKGFyZywgdmlldyk7XG59XG4gICAgOiBmdW5jdGlvbiAoYXJnLCB2aWV3KSB7XG4gICAgY29uc3QgYnVmID0gY2FjaGVkVGV4dEVuY29kZXIuZW5jb2RlKGFyZyk7XG4gICAgdmlldy5zZXQoYnVmKTtcbiAgICByZXR1cm4ge1xuICAgICAgICByZWFkOiBhcmcubGVuZ3RoLFxuICAgICAgICB3cml0dGVuOiBidWYubGVuZ3RoXG4gICAgfTtcbn0pO1xuXG5mdW5jdGlvbiBwYXNzU3RyaW5nVG9XYXNtMChhcmcsIG1hbGxvYywgcmVhbGxvYykge1xuXG4gICAgaWYgKHJlYWxsb2MgPT09IHVuZGVmaW5lZCkge1xuICAgICAgICBjb25zdCBidWYgPSBjYWNoZWRUZXh0RW5jb2Rlci5lbmNvZGUoYXJnKTtcbiAgICAgICAgY29uc3QgcHRyID0gbWFsbG9jKGJ1Zi5sZW5ndGgpO1xuICAgICAgICBnZXRVaW50OE1lbW9yeTAoKS5zdWJhcnJheShwdHIsIHB0ciArIGJ1Zi5sZW5ndGgpLnNldChidWYpO1xuICAgICAgICBXQVNNX1ZFQ1RPUl9MRU4gPSBidWYubGVuZ3RoO1xuICAgICAgICByZXR1cm4gcHRyO1xuICAgIH1cblxuICAgIGxldCBsZW4gPSBhcmcubGVuZ3RoO1xuICAgIGxldCBwdHIgPSBtYWxsb2MobGVuKTtcblxuICAgIGNvbnN0IG1lbSA9IGdldFVpbnQ4TWVtb3J5MCgpO1xuXG4gICAgbGV0IG9mZnNldCA9IDA7XG5cbiAgICBmb3IgKDsgb2Zmc2V0IDwgbGVuOyBvZmZzZXQrKykge1xuICAgICAgICBjb25zdCBjb2RlID0gYXJnLmNoYXJDb2RlQXQob2Zmc2V0KTtcbiAgICAgICAgaWYgKGNvZGUgPiAweDdGKSBicmVhaztcbiAgICAgICAgbWVtW3B0ciArIG9mZnNldF0gPSBjb2RlO1xuICAgIH1cblxuICAgIGlmIChvZmZzZXQgIT09IGxlbikge1xuICAgICAgICBpZiAob2Zmc2V0ICE9PSAwKSB7XG4gICAgICAgICAgICBhcmcgPSBhcmcuc2xpY2Uob2Zmc2V0KTtcbiAgICAgICAgfVxuICAgICAgICBwdHIgPSByZWFsbG9jKHB0ciwgbGVuLCBsZW4gPSBvZmZzZXQgKyBhcmcubGVuZ3RoICogMyk7XG4gICAgICAgIGNvbnN0IHZpZXcgPSBnZXRVaW50OE1lbW9yeTAoKS5zdWJhcnJheShwdHIgKyBvZmZzZXQsIHB0ciArIGxlbik7XG4gICAgICAgIGNvbnN0IHJldCA9IGVuY29kZVN0cmluZyhhcmcsIHZpZXcpO1xuXG4gICAgICAgIG9mZnNldCArPSByZXQud3JpdHRlbjtcbiAgICB9XG5cbiAgICBXQVNNX1ZFQ1RPUl9MRU4gPSBvZmZzZXQ7XG4gICAgcmV0dXJuIHB0cjtcbn1cblxubGV0IGNhY2hlZ2V0SW50MzJNZW1vcnkwID0gbnVsbDtcbmZ1bmN0aW9uIGdldEludDMyTWVtb3J5MCgpIHtcbiAgICBpZiAoY2FjaGVnZXRJbnQzMk1lbW9yeTAgPT09IG51bGwgfHwgY2FjaGVnZXRJbnQzMk1lbW9yeTAuYnVmZmVyICE9PSB3YXNtLm1lbW9yeS5idWZmZXIpIHtcbiAgICAgICAgY2FjaGVnZXRJbnQzMk1lbW9yeTAgPSBuZXcgSW50MzJBcnJheSh3YXNtLm1lbW9yeS5idWZmZXIpO1xuICAgIH1cbiAgICByZXR1cm4gY2FjaGVnZXRJbnQzMk1lbW9yeTA7XG59XG5cbmNvbnN0IGxUZXh0RGVjb2RlciA9IHR5cGVvZiBUZXh0RGVjb2RlciA9PT0gJ3VuZGVmaW5lZCcgPyAoMCwgbW9kdWxlLnJlcXVpcmUpKCd1dGlsJykuVGV4dERlY29kZXIgOiBUZXh0RGVjb2RlcjtcblxubGV0IGNhY2hlZFRleHREZWNvZGVyID0gbmV3IGxUZXh0RGVjb2RlcigndXRmLTgnLCB7IGlnbm9yZUJPTTogdHJ1ZSwgZmF0YWw6IHRydWUgfSk7XG5cbmNhY2hlZFRleHREZWNvZGVyLmRlY29kZSgpO1xuXG5mdW5jdGlvbiBnZXRTdHJpbmdGcm9tV2FzbTAocHRyLCBsZW4pIHtcbiAgICByZXR1cm4gY2FjaGVkVGV4dERlY29kZXIuZGVjb2RlKGdldFVpbnQ4TWVtb3J5MCgpLnN1YmFycmF5KHB0ciwgcHRyICsgbGVuKSk7XG59XG4vKipcbiogQHBhcmFtIHtzdHJpbmd9IG5hbWVcbiogQHBhcmFtIHtzdHJpbmd9IGlucHV0XG4qIEBwYXJhbSB7c3RyaW5nfSBvcHRpb25zXG4qIEByZXR1cm5zIHtzdHJpbmd9XG4qL1xuZXhwb3J0IGZ1bmN0aW9uIHJ1bihuYW1lLCBpbnB1dCwgb3B0aW9ucykge1xuICAgIHRyeSB7XG4gICAgICAgIGNvbnN0IHJldHB0ciA9IHdhc20uX193YmluZGdlbl9hZGRfdG9fc3RhY2tfcG9pbnRlcigtMTYpO1xuICAgICAgICB2YXIgcHRyMCA9IHBhc3NTdHJpbmdUb1dhc20wKG5hbWUsIHdhc20uX193YmluZGdlbl9tYWxsb2MsIHdhc20uX193YmluZGdlbl9yZWFsbG9jKTtcbiAgICAgICAgdmFyIGxlbjAgPSBXQVNNX1ZFQ1RPUl9MRU47XG4gICAgICAgIHZhciBwdHIxID0gcGFzc1N0cmluZ1RvV2FzbTAoaW5wdXQsIHdhc20uX193YmluZGdlbl9tYWxsb2MsIHdhc20uX193YmluZGdlbl9yZWFsbG9jKTtcbiAgICAgICAgdmFyIGxlbjEgPSBXQVNNX1ZFQ1RPUl9MRU47XG4gICAgICAgIHZhciBwdHIyID0gcGFzc1N0cmluZ1RvV2FzbTAob3B0aW9ucywgd2FzbS5fX3diaW5kZ2VuX21hbGxvYywgd2FzbS5fX3diaW5kZ2VuX3JlYWxsb2MpO1xuICAgICAgICB2YXIgbGVuMiA9IFdBU01fVkVDVE9SX0xFTjtcbiAgICAgICAgd2FzbS5ydW4ocmV0cHRyLCBwdHIwLCBsZW4wLCBwdHIxLCBsZW4xLCBwdHIyLCBsZW4yKTtcbiAgICAgICAgdmFyIHIwID0gZ2V0SW50MzJNZW1vcnkwKClbcmV0cHRyIC8gNCArIDBdO1xuICAgICAgICB2YXIgcjEgPSBnZXRJbnQzMk1lbW9yeTAoKVtyZXRwdHIgLyA0ICsgMV07XG4gICAgICAgIHJldHVybiBnZXRTdHJpbmdGcm9tV2FzbTAocjAsIHIxKTtcbiAgICB9IGZpbmFsbHkge1xuICAgICAgICB3YXNtLl9fd2JpbmRnZW5fYWRkX3RvX3N0YWNrX3BvaW50ZXIoMTYpO1xuICAgICAgICB3YXNtLl9fd2JpbmRnZW5fZnJlZShyMCwgcjEpO1xuICAgIH1cbn1cblxuIiwiJ3VzZSBzdHJpY3QnO1xuXG4vLyBUaGlzIGlzIGZyZWUgYW5kIHVuZW5jdW1iZXJlZCBzb2Z0d2FyZSByZWxlYXNlZCBpbnRvIHRoZSBwdWJsaWMgZG9tYWluLlxuLy8gU2VlIExJQ0VOU0UubWQgZm9yIG1vcmUgaW5mb3JtYXRpb24uXG5cbi8vXG4vLyBVdGlsaXRpZXNcbi8vXG5cbi8qKlxuICogQHBhcmFtIHtudW1iZXJ9IGEgVGhlIG51bWJlciB0byB0ZXN0LlxuICogQHBhcmFtIHtudW1iZXJ9IG1pbiBUaGUgbWluaW11bSB2YWx1ZSBpbiB0aGUgcmFuZ2UsIGluY2x1c2l2ZS5cbiAqIEBwYXJhbSB7bnVtYmVyfSBtYXggVGhlIG1heGltdW0gdmFsdWUgaW4gdGhlIHJhbmdlLCBpbmNsdXNpdmUuXG4gKiBAcmV0dXJuIHtib29sZWFufSBUcnVlIGlmIGEgPj0gbWluIGFuZCBhIDw9IG1heC5cbiAqL1xuZnVuY3Rpb24gaW5SYW5nZShhLCBtaW4sIG1heCkge1xuICByZXR1cm4gbWluIDw9IGEgJiYgYSA8PSBtYXg7XG59XG5cbi8qKlxuICogQHBhcmFtIHsqfSBvXG4gKiBAcmV0dXJuIHtPYmplY3R9XG4gKi9cbmZ1bmN0aW9uIFRvRGljdGlvbmFyeShvKSB7XG4gIGlmIChvID09PSB1bmRlZmluZWQpIHJldHVybiB7fTtcbiAgaWYgKG8gPT09IE9iamVjdChvKSkgcmV0dXJuIG87XG4gIHRocm93IFR5cGVFcnJvcignQ291bGQgbm90IGNvbnZlcnQgYXJndW1lbnQgdG8gZGljdGlvbmFyeScpO1xufVxuXG4vKipcbiAqIEBwYXJhbSB7c3RyaW5nfSBzdHJpbmcgSW5wdXQgc3RyaW5nIG9mIFVURi0xNiBjb2RlIHVuaXRzLlxuICogQHJldHVybiB7IUFycmF5LjxudW1iZXI+fSBDb2RlIHBvaW50cy5cbiAqL1xuZnVuY3Rpb24gc3RyaW5nVG9Db2RlUG9pbnRzKHN0cmluZykge1xuICAvLyBodHRwczovL2hleWNhbS5naXRodWIuaW8vd2ViaWRsLyNkZm4tb2J0YWluLXVuaWNvZGVcblxuICAvLyAxLiBMZXQgUyBiZSB0aGUgRE9NU3RyaW5nIHZhbHVlLlxuICB2YXIgcyA9IFN0cmluZyhzdHJpbmcpO1xuXG4gIC8vIDIuIExldCBuIGJlIHRoZSBsZW5ndGggb2YgUy5cbiAgdmFyIG4gPSBzLmxlbmd0aDtcblxuICAvLyAzLiBJbml0aWFsaXplIGkgdG8gMC5cbiAgdmFyIGkgPSAwO1xuXG4gIC8vIDQuIEluaXRpYWxpemUgVSB0byBiZSBhbiBlbXB0eSBzZXF1ZW5jZSBvZiBVbmljb2RlIGNoYXJhY3RlcnMuXG4gIHZhciB1ID0gW107XG5cbiAgLy8gNS4gV2hpbGUgaSA8IG46XG4gIHdoaWxlIChpIDwgbikge1xuXG4gICAgLy8gMS4gTGV0IGMgYmUgdGhlIGNvZGUgdW5pdCBpbiBTIGF0IGluZGV4IGkuXG4gICAgdmFyIGMgPSBzLmNoYXJDb2RlQXQoaSk7XG5cbiAgICAvLyAyLiBEZXBlbmRpbmcgb24gdGhlIHZhbHVlIG9mIGM6XG5cbiAgICAvLyBjIDwgMHhEODAwIG9yIGMgPiAweERGRkZcbiAgICBpZiAoYyA8IDB4RDgwMCB8fCBjID4gMHhERkZGKSB7XG4gICAgICAvLyBBcHBlbmQgdG8gVSB0aGUgVW5pY29kZSBjaGFyYWN0ZXIgd2l0aCBjb2RlIHBvaW50IGMuXG4gICAgICB1LnB1c2goYyk7XG4gICAgfVxuXG4gICAgLy8gMHhEQzAwIOKJpCBjIOKJpCAweERGRkZcbiAgICBlbHNlIGlmICgweERDMDAgPD0gYyAmJiBjIDw9IDB4REZGRikge1xuICAgICAgLy8gQXBwZW5kIHRvIFUgYSBVK0ZGRkQgUkVQTEFDRU1FTlQgQ0hBUkFDVEVSLlxuICAgICAgdS5wdXNoKDB4RkZGRCk7XG4gICAgfVxuXG4gICAgLy8gMHhEODAwIOKJpCBjIOKJpCAweERCRkZcbiAgICBlbHNlIGlmICgweEQ4MDAgPD0gYyAmJiBjIDw9IDB4REJGRikge1xuICAgICAgLy8gMS4gSWYgaSA9IG7iiJIxLCB0aGVuIGFwcGVuZCB0byBVIGEgVStGRkZEIFJFUExBQ0VNRU5UXG4gICAgICAvLyBDSEFSQUNURVIuXG4gICAgICBpZiAoaSA9PT0gbiAtIDEpIHtcbiAgICAgICAgdS5wdXNoKDB4RkZGRCk7XG4gICAgICB9XG4gICAgICAvLyAyLiBPdGhlcndpc2UsIGkgPCBu4oiSMTpcbiAgICAgIGVsc2Uge1xuICAgICAgICAvLyAxLiBMZXQgZCBiZSB0aGUgY29kZSB1bml0IGluIFMgYXQgaW5kZXggaSsxLlxuICAgICAgICB2YXIgZCA9IHN0cmluZy5jaGFyQ29kZUF0KGkgKyAxKTtcblxuICAgICAgICAvLyAyLiBJZiAweERDMDAg4omkIGQg4omkIDB4REZGRiwgdGhlbjpcbiAgICAgICAgaWYgKDB4REMwMCA8PSBkICYmIGQgPD0gMHhERkZGKSB7XG4gICAgICAgICAgLy8gMS4gTGV0IGEgYmUgYyAmIDB4M0ZGLlxuICAgICAgICAgIHZhciBhID0gYyAmIDB4M0ZGO1xuXG4gICAgICAgICAgLy8gMi4gTGV0IGIgYmUgZCAmIDB4M0ZGLlxuICAgICAgICAgIHZhciBiID0gZCAmIDB4M0ZGO1xuXG4gICAgICAgICAgLy8gMy4gQXBwZW5kIHRvIFUgdGhlIFVuaWNvZGUgY2hhcmFjdGVyIHdpdGggY29kZSBwb2ludFxuICAgICAgICAgIC8vIDJeMTYrMl4xMCphK2IuXG4gICAgICAgICAgdS5wdXNoKDB4MTAwMDAgKyAoYSA8PCAxMCkgKyBiKTtcblxuICAgICAgICAgIC8vIDQuIFNldCBpIHRvIGkrMS5cbiAgICAgICAgICBpICs9IDE7XG4gICAgICAgIH1cblxuICAgICAgICAvLyAzLiBPdGhlcndpc2UsIGQgPCAweERDMDAgb3IgZCA+IDB4REZGRi4gQXBwZW5kIHRvIFUgYVxuICAgICAgICAvLyBVK0ZGRkQgUkVQTEFDRU1FTlQgQ0hBUkFDVEVSLlxuICAgICAgICBlbHNlICB7XG4gICAgICAgICAgdS5wdXNoKDB4RkZGRCk7XG4gICAgICAgIH1cbiAgICAgIH1cbiAgICB9XG5cbiAgICAvLyAzLiBTZXQgaSB0byBpKzEuXG4gICAgaSArPSAxO1xuICB9XG5cbiAgLy8gNi4gUmV0dXJuIFUuXG4gIHJldHVybiB1O1xufVxuXG4vKipcbiAqIEBwYXJhbSB7IUFycmF5LjxudW1iZXI+fSBjb2RlX3BvaW50cyBBcnJheSBvZiBjb2RlIHBvaW50cy5cbiAqIEByZXR1cm4ge3N0cmluZ30gc3RyaW5nIFN0cmluZyBvZiBVVEYtMTYgY29kZSB1bml0cy5cbiAqL1xuZnVuY3Rpb24gY29kZVBvaW50c1RvU3RyaW5nKGNvZGVfcG9pbnRzKSB7XG4gIHZhciBzID0gJyc7XG4gIGZvciAodmFyIGkgPSAwOyBpIDwgY29kZV9wb2ludHMubGVuZ3RoOyArK2kpIHtcbiAgICB2YXIgY3AgPSBjb2RlX3BvaW50c1tpXTtcbiAgICBpZiAoY3AgPD0gMHhGRkZGKSB7XG4gICAgICBzICs9IFN0cmluZy5mcm9tQ2hhckNvZGUoY3ApO1xuICAgIH0gZWxzZSB7XG4gICAgICBjcCAtPSAweDEwMDAwO1xuICAgICAgcyArPSBTdHJpbmcuZnJvbUNoYXJDb2RlKChjcCA+PiAxMCkgKyAweEQ4MDAsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKGNwICYgMHgzRkYpICsgMHhEQzAwKTtcbiAgICB9XG4gIH1cbiAgcmV0dXJuIHM7XG59XG5cblxuLy9cbi8vIEltcGxlbWVudGF0aW9uIG9mIEVuY29kaW5nIHNwZWNpZmljYXRpb25cbi8vIGh0dHBzOi8vZW5jb2Rpbmcuc3BlYy53aGF0d2cub3JnL1xuLy9cblxuLy9cbi8vIDMuIFRlcm1pbm9sb2d5XG4vL1xuXG4vKipcbiAqIEVuZC1vZi1zdHJlYW0gaXMgYSBzcGVjaWFsIHRva2VuIHRoYXQgc2lnbmlmaWVzIG5vIG1vcmUgdG9rZW5zXG4gKiBhcmUgaW4gdGhlIHN0cmVhbS5cbiAqIEBjb25zdFxuICovIHZhciBlbmRfb2Zfc3RyZWFtID0gLTE7XG5cbi8qKlxuICogQSBzdHJlYW0gcmVwcmVzZW50cyBhbiBvcmRlcmVkIHNlcXVlbmNlIG9mIHRva2Vucy5cbiAqXG4gKiBAY29uc3RydWN0b3JcbiAqIEBwYXJhbSB7IShBcnJheS48bnVtYmVyPnxVaW50OEFycmF5KX0gdG9rZW5zIEFycmF5IG9mIHRva2VucyB0aGF0IHByb3ZpZGUgdGhlXG4gKiBzdHJlYW0uXG4gKi9cbmZ1bmN0aW9uIFN0cmVhbSh0b2tlbnMpIHtcbiAgLyoqIEB0eXBlIHshQXJyYXkuPG51bWJlcj59ICovXG4gIHRoaXMudG9rZW5zID0gW10uc2xpY2UuY2FsbCh0b2tlbnMpO1xufVxuXG5TdHJlYW0ucHJvdG90eXBlID0ge1xuICAvKipcbiAgICogQHJldHVybiB7Ym9vbGVhbn0gVHJ1ZSBpZiBlbmQtb2Ytc3RyZWFtIGhhcyBiZWVuIGhpdC5cbiAgICovXG4gIGVuZE9mU3RyZWFtOiBmdW5jdGlvbigpIHtcbiAgICByZXR1cm4gIXRoaXMudG9rZW5zLmxlbmd0aDtcbiAgfSxcblxuICAvKipcbiAgICogV2hlbiBhIHRva2VuIGlzIHJlYWQgZnJvbSBhIHN0cmVhbSwgdGhlIGZpcnN0IHRva2VuIGluIHRoZVxuICAgKiBzdHJlYW0gbXVzdCBiZSByZXR1cm5lZCBhbmQgc3Vic2VxdWVudGx5IHJlbW92ZWQsIGFuZFxuICAgKiBlbmQtb2Ytc3RyZWFtIG11c3QgYmUgcmV0dXJuZWQgb3RoZXJ3aXNlLlxuICAgKlxuICAgKiBAcmV0dXJuIHtudW1iZXJ9IEdldCB0aGUgbmV4dCB0b2tlbiBmcm9tIHRoZSBzdHJlYW0sIG9yXG4gICAqIGVuZF9vZl9zdHJlYW0uXG4gICAqL1xuICAgcmVhZDogZnVuY3Rpb24oKSB7XG4gICAgaWYgKCF0aGlzLnRva2Vucy5sZW5ndGgpXG4gICAgICByZXR1cm4gZW5kX29mX3N0cmVhbTtcbiAgICAgcmV0dXJuIHRoaXMudG9rZW5zLnNoaWZ0KCk7XG4gICB9LFxuXG4gIC8qKlxuICAgKiBXaGVuIG9uZSBvciBtb3JlIHRva2VucyBhcmUgcHJlcGVuZGVkIHRvIGEgc3RyZWFtLCB0aG9zZSB0b2tlbnNcbiAgICogbXVzdCBiZSBpbnNlcnRlZCwgaW4gZ2l2ZW4gb3JkZXIsIGJlZm9yZSB0aGUgZmlyc3QgdG9rZW4gaW4gdGhlXG4gICAqIHN0cmVhbS5cbiAgICpcbiAgICogQHBhcmFtIHsobnVtYmVyfCFBcnJheS48bnVtYmVyPil9IHRva2VuIFRoZSB0b2tlbihzKSB0byBwcmVwZW5kIHRvIHRoZSBzdHJlYW0uXG4gICAqL1xuICBwcmVwZW5kOiBmdW5jdGlvbih0b2tlbikge1xuICAgIGlmIChBcnJheS5pc0FycmF5KHRva2VuKSkge1xuICAgICAgdmFyIHRva2VucyA9IC8qKkB0eXBlIHshQXJyYXkuPG51bWJlcj59Ki8odG9rZW4pO1xuICAgICAgd2hpbGUgKHRva2Vucy5sZW5ndGgpXG4gICAgICAgIHRoaXMudG9rZW5zLnVuc2hpZnQodG9rZW5zLnBvcCgpKTtcbiAgICB9IGVsc2Uge1xuICAgICAgdGhpcy50b2tlbnMudW5zaGlmdCh0b2tlbik7XG4gICAgfVxuICB9LFxuXG4gIC8qKlxuICAgKiBXaGVuIG9uZSBvciBtb3JlIHRva2VucyBhcmUgcHVzaGVkIHRvIGEgc3RyZWFtLCB0aG9zZSB0b2tlbnNcbiAgICogbXVzdCBiZSBpbnNlcnRlZCwgaW4gZ2l2ZW4gb3JkZXIsIGFmdGVyIHRoZSBsYXN0IHRva2VuIGluIHRoZVxuICAgKiBzdHJlYW0uXG4gICAqXG4gICAqIEBwYXJhbSB7KG51bWJlcnwhQXJyYXkuPG51bWJlcj4pfSB0b2tlbiBUaGUgdG9rZW5zKHMpIHRvIHByZXBlbmQgdG8gdGhlIHN0cmVhbS5cbiAgICovXG4gIHB1c2g6IGZ1bmN0aW9uKHRva2VuKSB7XG4gICAgaWYgKEFycmF5LmlzQXJyYXkodG9rZW4pKSB7XG4gICAgICB2YXIgdG9rZW5zID0gLyoqQHR5cGUgeyFBcnJheS48bnVtYmVyPn0qLyh0b2tlbik7XG4gICAgICB3aGlsZSAodG9rZW5zLmxlbmd0aClcbiAgICAgICAgdGhpcy50b2tlbnMucHVzaCh0b2tlbnMuc2hpZnQoKSk7XG4gICAgfSBlbHNlIHtcbiAgICAgIHRoaXMudG9rZW5zLnB1c2godG9rZW4pO1xuICAgIH1cbiAgfVxufTtcblxuLy9cbi8vIDQuIEVuY29kaW5nc1xuLy9cblxuLy8gNC4xIEVuY29kZXJzIGFuZCBkZWNvZGVyc1xuXG4vKiogQGNvbnN0ICovXG52YXIgZmluaXNoZWQgPSAtMTtcblxuLyoqXG4gKiBAcGFyYW0ge2Jvb2xlYW59IGZhdGFsIElmIHRydWUsIGRlY29kaW5nIGVycm9ycyByYWlzZSBhbiBleGNlcHRpb24uXG4gKiBAcGFyYW0ge251bWJlcj19IG9wdF9jb2RlX3BvaW50IE92ZXJyaWRlIHRoZSBzdGFuZGFyZCBmYWxsYmFjayBjb2RlIHBvaW50LlxuICogQHJldHVybiB7bnVtYmVyfSBUaGUgY29kZSBwb2ludCB0byBpbnNlcnQgb24gYSBkZWNvZGluZyBlcnJvci5cbiAqL1xuZnVuY3Rpb24gZGVjb2RlckVycm9yKGZhdGFsLCBvcHRfY29kZV9wb2ludCkge1xuICBpZiAoZmF0YWwpXG4gICAgdGhyb3cgVHlwZUVycm9yKCdEZWNvZGVyIGVycm9yJyk7XG4gIHJldHVybiBvcHRfY29kZV9wb2ludCB8fCAweEZGRkQ7XG59XG5cbi8qKiBAaW50ZXJmYWNlICovXG5mdW5jdGlvbiBEZWNvZGVyKCkge31cbkRlY29kZXIucHJvdG90eXBlID0ge1xuICAvKipcbiAgICogQHBhcmFtIHtTdHJlYW19IHN0cmVhbSBUaGUgc3RyZWFtIG9mIGJ5dGVzIGJlaW5nIGRlY29kZWQuXG4gICAqIEBwYXJhbSB7bnVtYmVyfSBiaXRlIFRoZSBuZXh0IGJ5dGUgcmVhZCBmcm9tIHRoZSBzdHJlYW0uXG4gICAqIEByZXR1cm4gez8obnVtYmVyfCFBcnJheS48bnVtYmVyPil9IFRoZSBuZXh0IGNvZGUgcG9pbnQocylcbiAgICogICAgIGRlY29kZWQsIG9yIG51bGwgaWYgbm90IGVub3VnaCBkYXRhIGV4aXN0cyBpbiB0aGUgaW5wdXRcbiAgICogICAgIHN0cmVhbSB0byBkZWNvZGUgYSBjb21wbGV0ZSBjb2RlIHBvaW50LCBvciB8ZmluaXNoZWR8LlxuICAgKi9cbiAgaGFuZGxlcjogZnVuY3Rpb24oc3RyZWFtLCBiaXRlKSB7fVxufTtcblxuLyoqIEBpbnRlcmZhY2UgKi9cbmZ1bmN0aW9uIEVuY29kZXIoKSB7fVxuRW5jb2Rlci5wcm90b3R5cGUgPSB7XG4gIC8qKlxuICAgKiBAcGFyYW0ge1N0cmVhbX0gc3RyZWFtIFRoZSBzdHJlYW0gb2YgY29kZSBwb2ludHMgYmVpbmcgZW5jb2RlZC5cbiAgICogQHBhcmFtIHtudW1iZXJ9IGNvZGVfcG9pbnQgTmV4dCBjb2RlIHBvaW50IHJlYWQgZnJvbSB0aGUgc3RyZWFtLlxuICAgKiBAcmV0dXJuIHsobnVtYmVyfCFBcnJheS48bnVtYmVyPil9IEJ5dGUocykgdG8gZW1pdCwgb3IgfGZpbmlzaGVkfC5cbiAgICovXG4gIGhhbmRsZXI6IGZ1bmN0aW9uKHN0cmVhbSwgY29kZV9wb2ludCkge31cbn07XG5cbi8vXG4vLyA3LiBBUElcbi8vXG5cbi8qKiBAY29uc3QgKi8gdmFyIERFRkFVTFRfRU5DT0RJTkcgPSAndXRmLTgnO1xuXG4vLyA3LjEgSW50ZXJmYWNlIFRleHREZWNvZGVyXG5cbi8qKlxuICogQGNvbnN0cnVjdG9yXG4gKiBAcGFyYW0ge3N0cmluZz19IGVuY29kaW5nIFRoZSBsYWJlbCBvZiB0aGUgZW5jb2Rpbmc7XG4gKiAgICAgZGVmYXVsdHMgdG8gJ3V0Zi04Jy5cbiAqIEBwYXJhbSB7T2JqZWN0PX0gb3B0aW9uc1xuICovXG5mdW5jdGlvbiBUZXh0RGVjb2RlcihlbmNvZGluZywgb3B0aW9ucykge1xuICBpZiAoISh0aGlzIGluc3RhbmNlb2YgVGV4dERlY29kZXIpKSB7XG4gICAgcmV0dXJuIG5ldyBUZXh0RGVjb2RlcihlbmNvZGluZywgb3B0aW9ucyk7XG4gIH1cbiAgZW5jb2RpbmcgPSBlbmNvZGluZyAhPT0gdW5kZWZpbmVkID8gU3RyaW5nKGVuY29kaW5nKS50b0xvd2VyQ2FzZSgpIDogREVGQVVMVF9FTkNPRElORztcbiAgaWYgKGVuY29kaW5nICE9PSBERUZBVUxUX0VOQ09ESU5HKSB7XG4gICAgdGhyb3cgbmV3IEVycm9yKCdFbmNvZGluZyBub3Qgc3VwcG9ydGVkLiBPbmx5IHV0Zi04IGlzIHN1cHBvcnRlZCcpO1xuICB9XG4gIG9wdGlvbnMgPSBUb0RpY3Rpb25hcnkob3B0aW9ucyk7XG5cbiAgLyoqIEBwcml2YXRlIEB0eXBlIHtib29sZWFufSAqL1xuICB0aGlzLl9zdHJlYW1pbmcgPSBmYWxzZTtcbiAgLyoqIEBwcml2YXRlIEB0eXBlIHtib29sZWFufSAqL1xuICB0aGlzLl9CT01zZWVuID0gZmFsc2U7XG4gIC8qKiBAcHJpdmF0ZSBAdHlwZSB7P0RlY29kZXJ9ICovXG4gIHRoaXMuX2RlY29kZXIgPSBudWxsO1xuICAvKiogQHByaXZhdGUgQHR5cGUge2Jvb2xlYW59ICovXG4gIHRoaXMuX2ZhdGFsID0gQm9vbGVhbihvcHRpb25zWydmYXRhbCddKTtcbiAgLyoqIEBwcml2YXRlIEB0eXBlIHtib29sZWFufSAqL1xuICB0aGlzLl9pZ25vcmVCT00gPSBCb29sZWFuKG9wdGlvbnNbJ2lnbm9yZUJPTSddKTtcblxuICBPYmplY3QuZGVmaW5lUHJvcGVydHkodGhpcywgJ2VuY29kaW5nJywge3ZhbHVlOiAndXRmLTgnfSk7XG4gIE9iamVjdC5kZWZpbmVQcm9wZXJ0eSh0aGlzLCAnZmF0YWwnLCB7dmFsdWU6IHRoaXMuX2ZhdGFsfSk7XG4gIE9iamVjdC5kZWZpbmVQcm9wZXJ0eSh0aGlzLCAnaWdub3JlQk9NJywge3ZhbHVlOiB0aGlzLl9pZ25vcmVCT019KTtcbn1cblxuVGV4dERlY29kZXIucHJvdG90eXBlID0ge1xuICAvKipcbiAgICogQHBhcmFtIHtBcnJheUJ1ZmZlclZpZXc9fSBpbnB1dCBUaGUgYnVmZmVyIG9mIGJ5dGVzIHRvIGRlY29kZS5cbiAgICogQHBhcmFtIHtPYmplY3Q9fSBvcHRpb25zXG4gICAqIEByZXR1cm4ge3N0cmluZ30gVGhlIGRlY29kZWQgc3RyaW5nLlxuICAgKi9cbiAgZGVjb2RlOiBmdW5jdGlvbiBkZWNvZGUoaW5wdXQsIG9wdGlvbnMpIHtcbiAgICB2YXIgYnl0ZXM7XG4gICAgaWYgKHR5cGVvZiBpbnB1dCA9PT0gJ29iamVjdCcgJiYgaW5wdXQgaW5zdGFuY2VvZiBBcnJheUJ1ZmZlcikge1xuICAgICAgYnl0ZXMgPSBuZXcgVWludDhBcnJheShpbnB1dCk7XG4gICAgfSBlbHNlIGlmICh0eXBlb2YgaW5wdXQgPT09ICdvYmplY3QnICYmICdidWZmZXInIGluIGlucHV0ICYmXG4gICAgICAgICAgICAgICBpbnB1dC5idWZmZXIgaW5zdGFuY2VvZiBBcnJheUJ1ZmZlcikge1xuICAgICAgYnl0ZXMgPSBuZXcgVWludDhBcnJheShpbnB1dC5idWZmZXIsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlucHV0LmJ5dGVPZmZzZXQsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlucHV0LmJ5dGVMZW5ndGgpO1xuICAgIH0gZWxzZSB7XG4gICAgICBieXRlcyA9IG5ldyBVaW50OEFycmF5KDApO1xuICAgIH1cblxuICAgIG9wdGlvbnMgPSBUb0RpY3Rpb25hcnkob3B0aW9ucyk7XG5cbiAgICBpZiAoIXRoaXMuX3N0cmVhbWluZykge1xuICAgICAgdGhpcy5fZGVjb2RlciA9IG5ldyBVVEY4RGVjb2Rlcih7ZmF0YWw6IHRoaXMuX2ZhdGFsfSk7XG4gICAgICB0aGlzLl9CT01zZWVuID0gZmFsc2U7XG4gICAgfVxuICAgIHRoaXMuX3N0cmVhbWluZyA9IEJvb2xlYW4ob3B0aW9uc1snc3RyZWFtJ10pO1xuXG4gICAgdmFyIGlucHV0X3N0cmVhbSA9IG5ldyBTdHJlYW0oYnl0ZXMpO1xuXG4gICAgdmFyIGNvZGVfcG9pbnRzID0gW107XG5cbiAgICAvKiogQHR5cGUgez8obnVtYmVyfCFBcnJheS48bnVtYmVyPil9ICovXG4gICAgdmFyIHJlc3VsdDtcblxuICAgIHdoaWxlICghaW5wdXRfc3RyZWFtLmVuZE9mU3RyZWFtKCkpIHtcbiAgICAgIHJlc3VsdCA9IHRoaXMuX2RlY29kZXIuaGFuZGxlcihpbnB1dF9zdHJlYW0sIGlucHV0X3N0cmVhbS5yZWFkKCkpO1xuICAgICAgaWYgKHJlc3VsdCA9PT0gZmluaXNoZWQpXG4gICAgICAgIGJyZWFrO1xuICAgICAgaWYgKHJlc3VsdCA9PT0gbnVsbClcbiAgICAgICAgY29udGludWU7XG4gICAgICBpZiAoQXJyYXkuaXNBcnJheShyZXN1bHQpKVxuICAgICAgICBjb2RlX3BvaW50cy5wdXNoLmFwcGx5KGNvZGVfcG9pbnRzLCAvKipAdHlwZSB7IUFycmF5LjxudW1iZXI+fSovKHJlc3VsdCkpO1xuICAgICAgZWxzZVxuICAgICAgICBjb2RlX3BvaW50cy5wdXNoKHJlc3VsdCk7XG4gICAgfVxuICAgIGlmICghdGhpcy5fc3RyZWFtaW5nKSB7XG4gICAgICBkbyB7XG4gICAgICAgIHJlc3VsdCA9IHRoaXMuX2RlY29kZXIuaGFuZGxlcihpbnB1dF9zdHJlYW0sIGlucHV0X3N0cmVhbS5yZWFkKCkpO1xuICAgICAgICBpZiAocmVzdWx0ID09PSBmaW5pc2hlZClcbiAgICAgICAgICBicmVhaztcbiAgICAgICAgaWYgKHJlc3VsdCA9PT0gbnVsbClcbiAgICAgICAgICBjb250aW51ZTtcbiAgICAgICAgaWYgKEFycmF5LmlzQXJyYXkocmVzdWx0KSlcbiAgICAgICAgICBjb2RlX3BvaW50cy5wdXNoLmFwcGx5KGNvZGVfcG9pbnRzLCAvKipAdHlwZSB7IUFycmF5LjxudW1iZXI+fSovKHJlc3VsdCkpO1xuICAgICAgICBlbHNlXG4gICAgICAgICAgY29kZV9wb2ludHMucHVzaChyZXN1bHQpO1xuICAgICAgfSB3aGlsZSAoIWlucHV0X3N0cmVhbS5lbmRPZlN0cmVhbSgpKTtcbiAgICAgIHRoaXMuX2RlY29kZXIgPSBudWxsO1xuICAgIH1cblxuICAgIGlmIChjb2RlX3BvaW50cy5sZW5ndGgpIHtcbiAgICAgIC8vIElmIGVuY29kaW5nIGlzIG9uZSBvZiB1dGYtOCwgdXRmLTE2YmUsIGFuZCB1dGYtMTZsZSwgYW5kXG4gICAgICAvLyBpZ25vcmUgQk9NIGZsYWcgYW5kIEJPTSBzZWVuIGZsYWcgYXJlIHVuc2V0LCBydW4gdGhlc2VcbiAgICAgIC8vIHN1YnN1YnN0ZXBzOlxuICAgICAgaWYgKFsndXRmLTgnXS5pbmRleE9mKHRoaXMuZW5jb2RpbmcpICE9PSAtMSAmJlxuICAgICAgICAgICF0aGlzLl9pZ25vcmVCT00gJiYgIXRoaXMuX0JPTXNlZW4pIHtcbiAgICAgICAgLy8gSWYgdG9rZW4gaXMgVStGRUZGLCBzZXQgQk9NIHNlZW4gZmxhZy5cbiAgICAgICAgaWYgKGNvZGVfcG9pbnRzWzBdID09PSAweEZFRkYpIHtcbiAgICAgICAgICB0aGlzLl9CT01zZWVuID0gdHJ1ZTtcbiAgICAgICAgICBjb2RlX3BvaW50cy5zaGlmdCgpO1xuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgIC8vIE90aGVyd2lzZSwgaWYgdG9rZW4gaXMgbm90IGVuZC1vZi1zdHJlYW0sIHNldCBCT00gc2VlblxuICAgICAgICAgIC8vIGZsYWcgYW5kIGFwcGVuZCB0b2tlbiB0byBvdXRwdXQuXG4gICAgICAgICAgdGhpcy5fQk9Nc2VlbiA9IHRydWU7XG4gICAgICAgIH1cbiAgICAgIH1cbiAgICB9XG5cbiAgICByZXR1cm4gY29kZVBvaW50c1RvU3RyaW5nKGNvZGVfcG9pbnRzKTtcbiAgfVxufTtcblxuLy8gNy4yIEludGVyZmFjZSBUZXh0RW5jb2RlclxuXG4vKipcbiAqIEBjb25zdHJ1Y3RvclxuICogQHBhcmFtIHtzdHJpbmc9fSBlbmNvZGluZyBUaGUgbGFiZWwgb2YgdGhlIGVuY29kaW5nO1xuICogICAgIGRlZmF1bHRzIHRvICd1dGYtOCcuXG4gKiBAcGFyYW0ge09iamVjdD19IG9wdGlvbnNcbiAqL1xuZnVuY3Rpb24gVGV4dEVuY29kZXIoZW5jb2RpbmcsIG9wdGlvbnMpIHtcbiAgaWYgKCEodGhpcyBpbnN0YW5jZW9mIFRleHRFbmNvZGVyKSlcbiAgICByZXR1cm4gbmV3IFRleHRFbmNvZGVyKGVuY29kaW5nLCBvcHRpb25zKTtcbiAgZW5jb2RpbmcgPSBlbmNvZGluZyAhPT0gdW5kZWZpbmVkID8gU3RyaW5nKGVuY29kaW5nKS50b0xvd2VyQ2FzZSgpIDogREVGQVVMVF9FTkNPRElORztcbiAgaWYgKGVuY29kaW5nICE9PSBERUZBVUxUX0VOQ09ESU5HKSB7XG4gICAgdGhyb3cgbmV3IEVycm9yKCdFbmNvZGluZyBub3Qgc3VwcG9ydGVkLiBPbmx5IHV0Zi04IGlzIHN1cHBvcnRlZCcpO1xuICB9XG4gIG9wdGlvbnMgPSBUb0RpY3Rpb25hcnkob3B0aW9ucyk7XG5cbiAgLyoqIEBwcml2YXRlIEB0eXBlIHtib29sZWFufSAqL1xuICB0aGlzLl9zdHJlYW1pbmcgPSBmYWxzZTtcbiAgLyoqIEBwcml2YXRlIEB0eXBlIHs/RW5jb2Rlcn0gKi9cbiAgdGhpcy5fZW5jb2RlciA9IG51bGw7XG4gIC8qKiBAcHJpdmF0ZSBAdHlwZSB7e2ZhdGFsOiBib29sZWFufX0gKi9cbiAgdGhpcy5fb3B0aW9ucyA9IHtmYXRhbDogQm9vbGVhbihvcHRpb25zWydmYXRhbCddKX07XG5cbiAgT2JqZWN0LmRlZmluZVByb3BlcnR5KHRoaXMsICdlbmNvZGluZycsIHt2YWx1ZTogJ3V0Zi04J30pO1xufVxuXG5UZXh0RW5jb2Rlci5wcm90b3R5cGUgPSB7XG4gIC8qKlxuICAgKiBAcGFyYW0ge3N0cmluZz19IG9wdF9zdHJpbmcgVGhlIHN0cmluZyB0byBlbmNvZGUuXG4gICAqIEBwYXJhbSB7T2JqZWN0PX0gb3B0aW9uc1xuICAgKiBAcmV0dXJuIHtVaW50OEFycmF5fSBFbmNvZGVkIGJ5dGVzLCBhcyBhIFVpbnQ4QXJyYXkuXG4gICAqL1xuICBlbmNvZGU6IGZ1bmN0aW9uIGVuY29kZShvcHRfc3RyaW5nLCBvcHRpb25zKSB7XG4gICAgb3B0X3N0cmluZyA9IG9wdF9zdHJpbmcgPyBTdHJpbmcob3B0X3N0cmluZykgOiAnJztcbiAgICBvcHRpb25zID0gVG9EaWN0aW9uYXJ5KG9wdGlvbnMpO1xuXG4gICAgLy8gTk9URTogVGhpcyBvcHRpb24gaXMgbm9uc3RhbmRhcmQuIE5vbmUgb2YgdGhlIGVuY29kaW5nc1xuICAgIC8vIHBlcm1pdHRlZCBmb3IgZW5jb2RpbmcgKGkuZS4gVVRGLTgsIFVURi0xNikgYXJlIHN0YXRlZnVsLFxuICAgIC8vIHNvIHN0cmVhbWluZyBpcyBub3QgbmVjZXNzYXJ5LlxuICAgIGlmICghdGhpcy5fc3RyZWFtaW5nKVxuICAgICAgdGhpcy5fZW5jb2RlciA9IG5ldyBVVEY4RW5jb2Rlcih0aGlzLl9vcHRpb25zKTtcbiAgICB0aGlzLl9zdHJlYW1pbmcgPSBCb29sZWFuKG9wdGlvbnNbJ3N0cmVhbSddKTtcblxuICAgIHZhciBieXRlcyA9IFtdO1xuICAgIHZhciBpbnB1dF9zdHJlYW0gPSBuZXcgU3RyZWFtKHN0cmluZ1RvQ29kZVBvaW50cyhvcHRfc3RyaW5nKSk7XG4gICAgLyoqIEB0eXBlIHs/KG51bWJlcnwhQXJyYXkuPG51bWJlcj4pfSAqL1xuICAgIHZhciByZXN1bHQ7XG4gICAgd2hpbGUgKCFpbnB1dF9zdHJlYW0uZW5kT2ZTdHJlYW0oKSkge1xuICAgICAgcmVzdWx0ID0gdGhpcy5fZW5jb2Rlci5oYW5kbGVyKGlucHV0X3N0cmVhbSwgaW5wdXRfc3RyZWFtLnJlYWQoKSk7XG4gICAgICBpZiAocmVzdWx0ID09PSBmaW5pc2hlZClcbiAgICAgICAgYnJlYWs7XG4gICAgICBpZiAoQXJyYXkuaXNBcnJheShyZXN1bHQpKVxuICAgICAgICBieXRlcy5wdXNoLmFwcGx5KGJ5dGVzLCAvKipAdHlwZSB7IUFycmF5LjxudW1iZXI+fSovKHJlc3VsdCkpO1xuICAgICAgZWxzZVxuICAgICAgICBieXRlcy5wdXNoKHJlc3VsdCk7XG4gICAgfVxuICAgIGlmICghdGhpcy5fc3RyZWFtaW5nKSB7XG4gICAgICB3aGlsZSAodHJ1ZSkge1xuICAgICAgICByZXN1bHQgPSB0aGlzLl9lbmNvZGVyLmhhbmRsZXIoaW5wdXRfc3RyZWFtLCBpbnB1dF9zdHJlYW0ucmVhZCgpKTtcbiAgICAgICAgaWYgKHJlc3VsdCA9PT0gZmluaXNoZWQpXG4gICAgICAgICAgYnJlYWs7XG4gICAgICAgIGlmIChBcnJheS5pc0FycmF5KHJlc3VsdCkpXG4gICAgICAgICAgYnl0ZXMucHVzaC5hcHBseShieXRlcywgLyoqQHR5cGUgeyFBcnJheS48bnVtYmVyPn0qLyhyZXN1bHQpKTtcbiAgICAgICAgZWxzZVxuICAgICAgICAgIGJ5dGVzLnB1c2gocmVzdWx0KTtcbiAgICAgIH1cbiAgICAgIHRoaXMuX2VuY29kZXIgPSBudWxsO1xuICAgIH1cbiAgICByZXR1cm4gbmV3IFVpbnQ4QXJyYXkoYnl0ZXMpO1xuICB9XG59O1xuXG4vL1xuLy8gOC4gVGhlIGVuY29kaW5nXG4vL1xuXG4vLyA4LjEgdXRmLThcblxuLyoqXG4gKiBAY29uc3RydWN0b3JcbiAqIEBpbXBsZW1lbnRzIHtEZWNvZGVyfVxuICogQHBhcmFtIHt7ZmF0YWw6IGJvb2xlYW59fSBvcHRpb25zXG4gKi9cbmZ1bmN0aW9uIFVURjhEZWNvZGVyKG9wdGlvbnMpIHtcbiAgdmFyIGZhdGFsID0gb3B0aW9ucy5mYXRhbDtcblxuICAvLyB1dGYtOCdzIGRlY29kZXIncyBoYXMgYW4gYXNzb2NpYXRlZCB1dGYtOCBjb2RlIHBvaW50LCB1dGYtOFxuICAvLyBieXRlcyBzZWVuLCBhbmQgdXRmLTggYnl0ZXMgbmVlZGVkIChhbGwgaW5pdGlhbGx5IDApLCBhIHV0Zi04XG4gIC8vIGxvd2VyIGJvdW5kYXJ5IChpbml0aWFsbHkgMHg4MCksIGFuZCBhIHV0Zi04IHVwcGVyIGJvdW5kYXJ5XG4gIC8vIChpbml0aWFsbHkgMHhCRikuXG4gIHZhciAvKiogQHR5cGUge251bWJlcn0gKi8gdXRmOF9jb2RlX3BvaW50ID0gMCxcbiAgICAgIC8qKiBAdHlwZSB7bnVtYmVyfSAqLyB1dGY4X2J5dGVzX3NlZW4gPSAwLFxuICAgICAgLyoqIEB0eXBlIHtudW1iZXJ9ICovIHV0ZjhfYnl0ZXNfbmVlZGVkID0gMCxcbiAgICAgIC8qKiBAdHlwZSB7bnVtYmVyfSAqLyB1dGY4X2xvd2VyX2JvdW5kYXJ5ID0gMHg4MCxcbiAgICAgIC8qKiBAdHlwZSB7bnVtYmVyfSAqLyB1dGY4X3VwcGVyX2JvdW5kYXJ5ID0gMHhCRjtcblxuICAvKipcbiAgICogQHBhcmFtIHtTdHJlYW19IHN0cmVhbSBUaGUgc3RyZWFtIG9mIGJ5dGVzIGJlaW5nIGRlY29kZWQuXG4gICAqIEBwYXJhbSB7bnVtYmVyfSBiaXRlIFRoZSBuZXh0IGJ5dGUgcmVhZCBmcm9tIHRoZSBzdHJlYW0uXG4gICAqIEByZXR1cm4gez8obnVtYmVyfCFBcnJheS48bnVtYmVyPil9IFRoZSBuZXh0IGNvZGUgcG9pbnQocylcbiAgICogICAgIGRlY29kZWQsIG9yIG51bGwgaWYgbm90IGVub3VnaCBkYXRhIGV4aXN0cyBpbiB0aGUgaW5wdXRcbiAgICogICAgIHN0cmVhbSB0byBkZWNvZGUgYSBjb21wbGV0ZSBjb2RlIHBvaW50LlxuICAgKi9cbiAgdGhpcy5oYW5kbGVyID0gZnVuY3Rpb24oc3RyZWFtLCBiaXRlKSB7XG4gICAgLy8gMS4gSWYgYnl0ZSBpcyBlbmQtb2Ytc3RyZWFtIGFuZCB1dGYtOCBieXRlcyBuZWVkZWQgaXMgbm90IDAsXG4gICAgLy8gc2V0IHV0Zi04IGJ5dGVzIG5lZWRlZCB0byAwIGFuZCByZXR1cm4gZXJyb3IuXG4gICAgaWYgKGJpdGUgPT09IGVuZF9vZl9zdHJlYW0gJiYgdXRmOF9ieXRlc19uZWVkZWQgIT09IDApIHtcbiAgICAgIHV0ZjhfYnl0ZXNfbmVlZGVkID0gMDtcbiAgICAgIHJldHVybiBkZWNvZGVyRXJyb3IoZmF0YWwpO1xuICAgIH1cblxuICAgIC8vIDIuIElmIGJ5dGUgaXMgZW5kLW9mLXN0cmVhbSwgcmV0dXJuIGZpbmlzaGVkLlxuICAgIGlmIChiaXRlID09PSBlbmRfb2Zfc3RyZWFtKVxuICAgICAgcmV0dXJuIGZpbmlzaGVkO1xuXG4gICAgLy8gMy4gSWYgdXRmLTggYnl0ZXMgbmVlZGVkIGlzIDAsIGJhc2VkIG9uIGJ5dGU6XG4gICAgaWYgKHV0ZjhfYnl0ZXNfbmVlZGVkID09PSAwKSB7XG5cbiAgICAgIC8vIDB4MDAgdG8gMHg3RlxuICAgICAgaWYgKGluUmFuZ2UoYml0ZSwgMHgwMCwgMHg3RikpIHtcbiAgICAgICAgLy8gUmV0dXJuIGEgY29kZSBwb2ludCB3aG9zZSB2YWx1ZSBpcyBieXRlLlxuICAgICAgICByZXR1cm4gYml0ZTtcbiAgICAgIH1cblxuICAgICAgLy8gMHhDMiB0byAweERGXG4gICAgICBpZiAoaW5SYW5nZShiaXRlLCAweEMyLCAweERGKSkge1xuICAgICAgICAvLyBTZXQgdXRmLTggYnl0ZXMgbmVlZGVkIHRvIDEgYW5kIHV0Zi04IGNvZGUgcG9pbnQgdG8gYnl0ZVxuICAgICAgICAvLyDiiJIgMHhDMC5cbiAgICAgICAgdXRmOF9ieXRlc19uZWVkZWQgPSAxO1xuICAgICAgICB1dGY4X2NvZGVfcG9pbnQgPSBiaXRlIC0gMHhDMDtcbiAgICAgIH1cblxuICAgICAgLy8gMHhFMCB0byAweEVGXG4gICAgICBlbHNlIGlmIChpblJhbmdlKGJpdGUsIDB4RTAsIDB4RUYpKSB7XG4gICAgICAgIC8vIDEuIElmIGJ5dGUgaXMgMHhFMCwgc2V0IHV0Zi04IGxvd2VyIGJvdW5kYXJ5IHRvIDB4QTAuXG4gICAgICAgIGlmIChiaXRlID09PSAweEUwKVxuICAgICAgICAgIHV0ZjhfbG93ZXJfYm91bmRhcnkgPSAweEEwO1xuICAgICAgICAvLyAyLiBJZiBieXRlIGlzIDB4RUQsIHNldCB1dGYtOCB1cHBlciBib3VuZGFyeSB0byAweDlGLlxuICAgICAgICBpZiAoYml0ZSA9PT0gMHhFRClcbiAgICAgICAgICB1dGY4X3VwcGVyX2JvdW5kYXJ5ID0gMHg5RjtcbiAgICAgICAgLy8gMy4gU2V0IHV0Zi04IGJ5dGVzIG5lZWRlZCB0byAyIGFuZCB1dGYtOCBjb2RlIHBvaW50IHRvXG4gICAgICAgIC8vIGJ5dGUg4oiSIDB4RTAuXG4gICAgICAgIHV0ZjhfYnl0ZXNfbmVlZGVkID0gMjtcbiAgICAgICAgdXRmOF9jb2RlX3BvaW50ID0gYml0ZSAtIDB4RTA7XG4gICAgICB9XG5cbiAgICAgIC8vIDB4RjAgdG8gMHhGNFxuICAgICAgZWxzZSBpZiAoaW5SYW5nZShiaXRlLCAweEYwLCAweEY0KSkge1xuICAgICAgICAvLyAxLiBJZiBieXRlIGlzIDB4RjAsIHNldCB1dGYtOCBsb3dlciBib3VuZGFyeSB0byAweDkwLlxuICAgICAgICBpZiAoYml0ZSA9PT0gMHhGMClcbiAgICAgICAgICB1dGY4X2xvd2VyX2JvdW5kYXJ5ID0gMHg5MDtcbiAgICAgICAgLy8gMi4gSWYgYnl0ZSBpcyAweEY0LCBzZXQgdXRmLTggdXBwZXIgYm91bmRhcnkgdG8gMHg4Ri5cbiAgICAgICAgaWYgKGJpdGUgPT09IDB4RjQpXG4gICAgICAgICAgdXRmOF91cHBlcl9ib3VuZGFyeSA9IDB4OEY7XG4gICAgICAgIC8vIDMuIFNldCB1dGYtOCBieXRlcyBuZWVkZWQgdG8gMyBhbmQgdXRmLTggY29kZSBwb2ludCB0b1xuICAgICAgICAvLyBieXRlIOKIkiAweEYwLlxuICAgICAgICB1dGY4X2J5dGVzX25lZWRlZCA9IDM7XG4gICAgICAgIHV0ZjhfY29kZV9wb2ludCA9IGJpdGUgLSAweEYwO1xuICAgICAgfVxuXG4gICAgICAvLyBPdGhlcndpc2VcbiAgICAgIGVsc2Uge1xuICAgICAgICAvLyBSZXR1cm4gZXJyb3IuXG4gICAgICAgIHJldHVybiBkZWNvZGVyRXJyb3IoZmF0YWwpO1xuICAgICAgfVxuXG4gICAgICAvLyBUaGVuIChieXRlIGlzIGluIHRoZSByYW5nZSAweEMyIHRvIDB4RjQpIHNldCB1dGYtOCBjb2RlXG4gICAgICAvLyBwb2ludCB0byB1dGYtOCBjb2RlIHBvaW50IDw8ICg2IMOXIHV0Zi04IGJ5dGVzIG5lZWRlZCkgYW5kXG4gICAgICAvLyByZXR1cm4gY29udGludWUuXG4gICAgICB1dGY4X2NvZGVfcG9pbnQgPSB1dGY4X2NvZGVfcG9pbnQgPDwgKDYgKiB1dGY4X2J5dGVzX25lZWRlZCk7XG4gICAgICByZXR1cm4gbnVsbDtcbiAgICB9XG5cbiAgICAvLyA0LiBJZiBieXRlIGlzIG5vdCBpbiB0aGUgcmFuZ2UgdXRmLTggbG93ZXIgYm91bmRhcnkgdG8gdXRmLThcbiAgICAvLyB1cHBlciBib3VuZGFyeSwgcnVuIHRoZXNlIHN1YnN0ZXBzOlxuICAgIGlmICghaW5SYW5nZShiaXRlLCB1dGY4X2xvd2VyX2JvdW5kYXJ5LCB1dGY4X3VwcGVyX2JvdW5kYXJ5KSkge1xuXG4gICAgICAvLyAxLiBTZXQgdXRmLTggY29kZSBwb2ludCwgdXRmLTggYnl0ZXMgbmVlZGVkLCBhbmQgdXRmLThcbiAgICAgIC8vIGJ5dGVzIHNlZW4gdG8gMCwgc2V0IHV0Zi04IGxvd2VyIGJvdW5kYXJ5IHRvIDB4ODAsIGFuZCBzZXRcbiAgICAgIC8vIHV0Zi04IHVwcGVyIGJvdW5kYXJ5IHRvIDB4QkYuXG4gICAgICB1dGY4X2NvZGVfcG9pbnQgPSB1dGY4X2J5dGVzX25lZWRlZCA9IHV0ZjhfYnl0ZXNfc2VlbiA9IDA7XG4gICAgICB1dGY4X2xvd2VyX2JvdW5kYXJ5ID0gMHg4MDtcbiAgICAgIHV0ZjhfdXBwZXJfYm91bmRhcnkgPSAweEJGO1xuXG4gICAgICAvLyAyLiBQcmVwZW5kIGJ5dGUgdG8gc3RyZWFtLlxuICAgICAgc3RyZWFtLnByZXBlbmQoYml0ZSk7XG5cbiAgICAgIC8vIDMuIFJldHVybiBlcnJvci5cbiAgICAgIHJldHVybiBkZWNvZGVyRXJyb3IoZmF0YWwpO1xuICAgIH1cblxuICAgIC8vIDUuIFNldCB1dGYtOCBsb3dlciBib3VuZGFyeSB0byAweDgwIGFuZCB1dGYtOCB1cHBlciBib3VuZGFyeVxuICAgIC8vIHRvIDB4QkYuXG4gICAgdXRmOF9sb3dlcl9ib3VuZGFyeSA9IDB4ODA7XG4gICAgdXRmOF91cHBlcl9ib3VuZGFyeSA9IDB4QkY7XG5cbiAgICAvLyA2LiBJbmNyZWFzZSB1dGYtOCBieXRlcyBzZWVuIGJ5IG9uZSBhbmQgc2V0IHV0Zi04IGNvZGUgcG9pbnRcbiAgICAvLyB0byB1dGYtOCBjb2RlIHBvaW50ICsgKGJ5dGUg4oiSIDB4ODApIDw8ICg2IMOXICh1dGYtOCBieXRlc1xuICAgIC8vIG5lZWRlZCDiiJIgdXRmLTggYnl0ZXMgc2VlbikpLlxuICAgIHV0ZjhfYnl0ZXNfc2VlbiArPSAxO1xuICAgIHV0ZjhfY29kZV9wb2ludCArPSAoYml0ZSAtIDB4ODApIDw8ICg2ICogKHV0ZjhfYnl0ZXNfbmVlZGVkIC0gdXRmOF9ieXRlc19zZWVuKSk7XG5cbiAgICAvLyA3LiBJZiB1dGYtOCBieXRlcyBzZWVuIGlzIG5vdCBlcXVhbCB0byB1dGYtOCBieXRlcyBuZWVkZWQsXG4gICAgLy8gY29udGludWUuXG4gICAgaWYgKHV0ZjhfYnl0ZXNfc2VlbiAhPT0gdXRmOF9ieXRlc19uZWVkZWQpXG4gICAgICByZXR1cm4gbnVsbDtcblxuICAgIC8vIDguIExldCBjb2RlIHBvaW50IGJlIHV0Zi04IGNvZGUgcG9pbnQuXG4gICAgdmFyIGNvZGVfcG9pbnQgPSB1dGY4X2NvZGVfcG9pbnQ7XG5cbiAgICAvLyA5LiBTZXQgdXRmLTggY29kZSBwb2ludCwgdXRmLTggYnl0ZXMgbmVlZGVkLCBhbmQgdXRmLTggYnl0ZXNcbiAgICAvLyBzZWVuIHRvIDAuXG4gICAgdXRmOF9jb2RlX3BvaW50ID0gdXRmOF9ieXRlc19uZWVkZWQgPSB1dGY4X2J5dGVzX3NlZW4gPSAwO1xuXG4gICAgLy8gMTAuIFJldHVybiBhIGNvZGUgcG9pbnQgd2hvc2UgdmFsdWUgaXMgY29kZSBwb2ludC5cbiAgICByZXR1cm4gY29kZV9wb2ludDtcbiAgfTtcbn1cblxuLyoqXG4gKiBAY29uc3RydWN0b3JcbiAqIEBpbXBsZW1lbnRzIHtFbmNvZGVyfVxuICogQHBhcmFtIHt7ZmF0YWw6IGJvb2xlYW59fSBvcHRpb25zXG4gKi9cbmZ1bmN0aW9uIFVURjhFbmNvZGVyKG9wdGlvbnMpIHtcbiAgdmFyIGZhdGFsID0gb3B0aW9ucy5mYXRhbDtcbiAgLyoqXG4gICAqIEBwYXJhbSB7U3RyZWFtfSBzdHJlYW0gSW5wdXQgc3RyZWFtLlxuICAgKiBAcGFyYW0ge251bWJlcn0gY29kZV9wb2ludCBOZXh0IGNvZGUgcG9pbnQgcmVhZCBmcm9tIHRoZSBzdHJlYW0uXG4gICAqIEByZXR1cm4geyhudW1iZXJ8IUFycmF5LjxudW1iZXI+KX0gQnl0ZShzKSB0byBlbWl0LlxuICAgKi9cbiAgdGhpcy5oYW5kbGVyID0gZnVuY3Rpb24oc3RyZWFtLCBjb2RlX3BvaW50KSB7XG4gICAgLy8gMS4gSWYgY29kZSBwb2ludCBpcyBlbmQtb2Ytc3RyZWFtLCByZXR1cm4gZmluaXNoZWQuXG4gICAgaWYgKGNvZGVfcG9pbnQgPT09IGVuZF9vZl9zdHJlYW0pXG4gICAgICByZXR1cm4gZmluaXNoZWQ7XG5cbiAgICAvLyAyLiBJZiBjb2RlIHBvaW50IGlzIGluIHRoZSByYW5nZSBVKzAwMDAgdG8gVSswMDdGLCByZXR1cm4gYVxuICAgIC8vIGJ5dGUgd2hvc2UgdmFsdWUgaXMgY29kZSBwb2ludC5cbiAgICBpZiAoaW5SYW5nZShjb2RlX3BvaW50LCAweDAwMDAsIDB4MDA3ZikpXG4gICAgICByZXR1cm4gY29kZV9wb2ludDtcblxuICAgIC8vIDMuIFNldCBjb3VudCBhbmQgb2Zmc2V0IGJhc2VkIG9uIHRoZSByYW5nZSBjb2RlIHBvaW50IGlzIGluOlxuICAgIHZhciBjb3VudCwgb2Zmc2V0O1xuICAgIC8vIFUrMDA4MCB0byBVKzA3RkY6ICAgIDEgYW5kIDB4QzBcbiAgICBpZiAoaW5SYW5nZShjb2RlX3BvaW50LCAweDAwODAsIDB4MDdGRikpIHtcbiAgICAgIGNvdW50ID0gMTtcbiAgICAgIG9mZnNldCA9IDB4QzA7XG4gICAgfVxuICAgIC8vIFUrMDgwMCB0byBVK0ZGRkY6ICAgIDIgYW5kIDB4RTBcbiAgICBlbHNlIGlmIChpblJhbmdlKGNvZGVfcG9pbnQsIDB4MDgwMCwgMHhGRkZGKSkge1xuICAgICAgY291bnQgPSAyO1xuICAgICAgb2Zmc2V0ID0gMHhFMDtcbiAgICB9XG4gICAgLy8gVSsxMDAwMCB0byBVKzEwRkZGRjogMyBhbmQgMHhGMFxuICAgIGVsc2UgaWYgKGluUmFuZ2UoY29kZV9wb2ludCwgMHgxMDAwMCwgMHgxMEZGRkYpKSB7XG4gICAgICBjb3VudCA9IDM7XG4gICAgICBvZmZzZXQgPSAweEYwO1xuICAgIH1cblxuICAgIC8vIDQuTGV0IGJ5dGVzIGJlIGEgYnl0ZSBzZXF1ZW5jZSB3aG9zZSBmaXJzdCBieXRlIGlzIChjb2RlXG4gICAgLy8gcG9pbnQgPj4gKDYgw5cgY291bnQpKSArIG9mZnNldC5cbiAgICB2YXIgYnl0ZXMgPSBbKGNvZGVfcG9pbnQgPj4gKDYgKiBjb3VudCkpICsgb2Zmc2V0XTtcblxuICAgIC8vIDUuIFJ1biB0aGVzZSBzdWJzdGVwcyB3aGlsZSBjb3VudCBpcyBncmVhdGVyIHRoYW4gMDpcbiAgICB3aGlsZSAoY291bnQgPiAwKSB7XG5cbiAgICAgIC8vIDEuIFNldCB0ZW1wIHRvIGNvZGUgcG9pbnQgPj4gKDYgw5cgKGNvdW50IOKIkiAxKSkuXG4gICAgICB2YXIgdGVtcCA9IGNvZGVfcG9pbnQgPj4gKDYgKiAoY291bnQgLSAxKSk7XG5cbiAgICAgIC8vIDIuIEFwcGVuZCB0byBieXRlcyAweDgwIHwgKHRlbXAgJiAweDNGKS5cbiAgICAgIGJ5dGVzLnB1c2goMHg4MCB8ICh0ZW1wICYgMHgzRikpO1xuXG4gICAgICAvLyAzLiBEZWNyZWFzZSBjb3VudCBieSBvbmUuXG4gICAgICBjb3VudCAtPSAxO1xuICAgIH1cblxuICAgIC8vIDYuIFJldHVybiBieXRlcyBieXRlcywgaW4gb3JkZXIuXG4gICAgcmV0dXJuIGJ5dGVzO1xuICB9O1xufVxuXG5leHBvcnQge1RleHRFbmNvZGVyLCBUZXh0RGVjb2Rlcn07XG4iXSwic291cmNlUm9vdCI6IiJ9