# Installation
> `npm install --save @types/vinyl`

# Summary
This package contains type definitions for vinyl (https://github.com/gulpjs/vinyl).

# Details
Files were exported from https://github.com/DefinitelyTyped/DefinitelyTyped/tree/master/types/vinyl.

### Additional Details
 * Last updated: Mon, 15 Apr 2024 23:06:59 GMT
 * Dependencies: [@types/expect](https://npmjs.com/package/@types/expect), [@types/node](https://npmjs.com/package/@types/node)

# Credits
These definitions were written by [vvakame](https://github.com/vvakame), and [Georgii Dolzhykov](https://github.com/thorn0).
