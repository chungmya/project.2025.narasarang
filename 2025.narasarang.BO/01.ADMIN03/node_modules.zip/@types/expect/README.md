# Installation
> `npm install --save @types/expect`

# Summary
This package contains type definitions for Expect ( https://github.com/facebook/jest ).

# Details
Files were exported from https://github.com/DefinitelyTyped/DefinitelyTyped/tree/master/types/expect

Additional Details
 * Last updated: Wed, 13 Feb 2019 18:42:05 GMT
 * Dependencies: none
 * Global values: none

# Credits
These definitions were written by Justin Reidy <https://github.com/jmreidy>, Risto Keravuori <https://github.com/merrywhether>.
